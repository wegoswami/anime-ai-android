/* Fun: jokes, shayari, riddles, quiz, mini-games, daily streak + badges, and a pet that chats on its own.
   Everything here works offline. It plugs into localCommand through Fun.handle(raw, n, l, R). */
const Fun = (() => {
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  const J = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } };
  const S = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
  const name = () => { try { return you(); } catch (e) { return "dost"; } };

  const JOKES = [
    "Teacher: Tum late kyun aaye? Student: Sir, board pe likha tha 'School ahead, go slow'! 😄",
    "Pappu: Maine bhooton ki movie dekhi. Dost: Kaisi thi? Pappu: Kuch dikha hi nahi, sab 'dar' ke maare aankhein band thi. 😂",
    "Doctor: Aapko aaram ki zaroorat hai. Patient: Par doctor sahab, mera boss 'aaram' shabd se hi chidta hai! 😅",
    "WiFi aur main me ek cheez same hai: dono 'connection' dhundhte rehte hain. 📶",
    "Alarm: Utho, subah ho gayi! Main: Tu paagal hai? Abhi to meri raat shuru hui thi. 😴",
    "Maths ki book itni udaas kyun thi? Kyunki uske paas bahut saare 'problems' the. 📘",
    "Dukandaar: Ye shampoo lo, baal kabhi nahi girenge. Ganje ne kaha: Wo to pehle hi gir chuke! 😆",
    "Chai bolti hai: Mujhe thoda garam rakho, bahut der mat chhodo. Dil bhi yehi kehta hai. ☕",
    "Phone 1%: Main jaa raha hoon. Main: Ruko, charger dhoondh raha hoon! 🔋",
    "Programmer ki biwi: Bazaar se ek dahi lana, agar ande ho to 6 lana. Wo 6 dahi le aaya. 'Ande the na!' 🤣",
    "Student: Mujhe 100 me se 0 mile. Teacher: Zero bhi to ek number hai! Student: Haan, par sabse gol-mol wala. ⭕",
    "Light gayi to maine socha: Aaj rishte-naate mil kar baat kar lete hain. Phir phone ki battery bhi chali gayi. 🕯️",
  ];
  const SHAYARI = [
    "Chhote chhote lamhon me badi badi khushiyan hain,\nbas dekhne wali nazar chahiye. ✨",
    "Raaste kitne bhi mushkil hon,\nmanzil unhi ki hoti hai jo chalna nahi chhodte. 🌄",
    "Waqt ka kya hai, guzar hi jayega,\nbas tum muskurate rehna. 🌸",
    "Khwab wo nahi jo neend me aaye,\nkhwab wo hai jo neend na aane de. 🌙",
    "Koi to hoga jo tumhari khamoshi bhi sunega,\nbas khud se baat karna band mat karna. 💗",
    "Gir kar uthna hi to zindagi hai,\nwarna chalna to har koi seekh leta hai. 💪",
  ];
  const RIDDLES = [
    ["Ek cheez jo jitni badhti hai, utni kam dikhti hai. Kya?", ["andhera", "dark", "darkness"], "Andhera! 🌑 (Jitna badhta hai, utna kam dikhta hai.)"],
    ["Main chhota hoon, par sabko pakad leta hoon, haath na pair. Kya?", ["taala", "lock", "tala"], "Taala! 🔒"],
    ["Jisko khareedne wala use istemal nahi karta, jisne banaya wo bhi nahi, jo istemal karta hai use pata nahi. Kya?", ["kafan", "coffin", "taboot"], "Kafan/taboot! ⚰️"],
    ["Mere paas shehar hain par ghar nahi, pahaad hain par ped nahi, paani hai par machhli nahi. Kya?", ["nakshaa", "naksha", "map"], "Naksha (map)! 🗺️"],
    ["Jitna tum is se lete jaoge, utna ye bada hota jayega. Kya?", ["gadda", "hole", "gaddha", "khadda"], "Gaddha (hole)! 🕳️"],
    ["Ek cheez jise tod ke hi use kar sakte hain. Kya?", ["anda", "egg", "ande"], "Anda! 🥚"],
  ];
  const FACTS = [
    "Octopus ke 3 dil hote hain aur unka khoon neela hota hai. 🐙",
    "Shahad kabhi kharab nahi hota. Misr ke pyramids me 3000 saal purana shahad bhi khane layak mila! 🍯",
    "Bijli ki raftaar se bhi tez hamara dimaag signals bhejta hai, par sirf ~400 km/h tak. 🧠",
    "Venus par ek din (ghoomna) uske ek saal se bhi lamba hota hai. 🪐",
    "Kele me thodi si radioactivity hoti hai (potassium ki wajah se) — bilkul safe. 🍌",
    "Insaan ki haddiyan wazan ke hisaab se steel se bhi mazboot hoti hain. 🦴",
    "Hathi akele jaanwar hain jo kood nahi sakte. 🐘",
    "Cheetah sirf 3 second me 0 se 100 km/h tak pahunch sakta hai. 🐆",
    "Bharat me sabse zyada dak-ghar (post offices) hain duniya me. 📮",
    "Shatranj (chess) ka janm Bharat me hua tha. ♟️",
  ];
  const WYR = [
    "Would you rather: hamesha subah 5 baje uthna ya hamesha raat 3 baje sona?",
    "Would you rather: udna seekhna ya gayab hona?",
    "Would you rather: har din biryani ya har din pizza?",
    "Would you rather: past me ghoomna ya future dekhna?",
    "Would you rather: bina phone ek hafta ya bina chai ek hafta?",
    "Would you rather: har bhasha bolna ya har janwar se baat karna?",
  ];
  const TRUTH = [
    "Truth: Aapki sabse embarrassing yaad kaunsi hai?", "Truth: Aap kis cheez se sabse zyada darte ho?",
    "Truth: Aapne last baar jhooth kab bola tha, aur kyun?", "Truth: Bachpan ka sabse bada sapna kya tha?",
    "Truth: Kaunsa gaana aap chhup kar sunte ho?",
  ];
  const DARE = [
    "Dare: Abhi 10 second tak sabse funny chehra banao! 🤪", "Dare: Kisi dost ko bina wajah ek acchi baat bolke message karo. 💌",
    "Dare: 20 squats lagao, main ginti karungi! 💪", "Dare: Ek glass paani abhi piyo, doston ki tarah! 💧",
    "Dare: Apni chhat ya khidki se baahar dekh ke 3 gehri saansein lo. 🌅",
  ];
  const COMPL = [
    "Aap bahut mehnati ho, ye sach me dikhta hai. 🌟", "Aapki muskaan din bana deti hai! 😊", "Aap jaise dost mile, main lucky hoon. 💗",
    "Aap jo seekhne ki koshish karte ho na, wo kamaal hai. 📚", "Aaj aap kaafi achhe lag rahe ho! ✨",
  ];
  const QUOTES = [
    "“Jo ho raha hai usse seekho, jo hona hai uski tayyari karo.” 🌱", "“Chhote kadam bhi manzil tak le jaate hain.” 👣",
    "“Girna galat nahi, na uthna galat hai.” 💪", "“Aaj ka kaam aaj, kal ka kaam parso.” 😜 (mazaak! kal ka kaam kal.)",
    "“Khud par yakeen sabse bada hunar hai.” ⭐",
  ];
  const STORIES = [
    "Ek baar ek chhoti si chidiya thi jo udna seekh rahi thi. Roz gir jaati, roz uthti. Ek din hawa ne use sahara diya aur wo aasmaan chhoo aayi. Seekh: Roz thoda koshish, ek din udaan. 🐦",
    "Ek kachhua aur khargosh ki race hui. Khargosh so gaya, kachhua chalta raha. Jeet kachhue ki hui. Seekh: Lagataar chalne wala jeet jaata hai. 🐢",
  ];
  const TRIVIA = [
    ["Bharat ki rajdhani kya hai?", ["Mumbai", "New Delhi", "Kolkata"], 1],
    ["Sabse bada grah kaunsa hai?", ["Jupiter", "Saturn", "Earth"], 0],
    ["Taj Mahal kis shehar me hai?", ["Jaipur", "Agra", "Lucknow"], 1],
    ["Paani ka chemical formula?", ["CO2", "H2O", "O2"], 1],
    ["Hindi diwas kab manaya jata hai?", ["14 September", "15 August", "26 January"], 0],
    ["Insaan ke dil me kitne chambers hote hain?", ["2", "4", "6"], 1],
    ["Sabse tez daudne wala jaanwar?", ["Cheetah", "Sher", "Ghoda"], 0],
    ["Gandhi ji ka janm kis shehar me hua?", ["Porbandar", "Delhi", "Wardha"], 0],
    ["Ek saal me kitne mahine 31 din ke hote hain?", ["6", "7", "8"], 1],
    ["Surya kis disha me ugta hai?", ["Paschim", "Purab", "Uttar"], 1],
  ];
  const BADGES = [[3, "🥉 3 din ka saath"], [7, "🥈 Ek hafte ka saathi"], [14, "🥇 2 hafte ka dost"], [30, "🏆 30 din — pakka dost"], [100, "👑 100 din legend"]];

  const st = () => J("haa_fun", { streak: 0, best: 0, last: "", wins: 0, games: 0, badges: [] });
  const sv = (o) => S("haa_fun", o);
  const today = () => new Date().toISOString().slice(0, 10);
  let pending = null, lastQuipAt = Date.now();

  function daily() {
    const s = st(), t = today(); if (s.last === t) return null;
    const y = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
    s.streak = s.last === y ? s.streak + 1 : 1; s.best = Math.max(s.best, s.streak); s.last = t;
    const b = BADGES.find(([d]) => d === s.streak && !s.badges.includes(d));
    if (b) s.badges.push(b[0]);
    sv(s); try { addBond(5 + Math.min(s.streak, 10)); } catch (e) {}
    return b ? `🔥 ${s.streak} din ka streak! Naya badge: ${b[1]}` : (s.streak > 1 ? `🔥 ${s.streak} din ka streak! Kal bhi aana, badge milega.` : `Aaj ka din shuru! Roz aao, streak banao 🔥`);
  }
  function statsText() {
    const s = st(), nxt = BADGES.find(([d]) => d > s.streak);
    const bl = s.badges.length ? s.badges.map((d) => BADGES.find((x) => x[0] === d)[1]).join(", ") : "abhi koi nahi";
    return `📊 Aapki stats\n🔥 Streak: ${s.streak} din (best ${s.best})\n💗 Bond level: ${typeof bondLevel === "function" ? bondLevel() : 1}\n🎮 Games: ${s.games}, jeete: ${s.wins}\n🏅 Badges: ${bl}` + (nxt ? `\nAgla badge: ${nxt[0] - s.streak} din aur` : "");
  }
  const win = () => { const s = st(); s.games++; s.wins++; sv(s); try { addBond(3); } catch (e) {} };
  const play = () => { const s = st(); s.games++; sv(s); };
  const menu = () => "🎮 Main ye khel sakti hoon — bas bolo:\n• joke  • shayari  • paheli (riddle)\n• quiz  • rock paper scissors  • guess number\n• truth / dare  • would you rather\n• fun fact  • kahani  • compliment  • quote\n• meri stats (streak + badges)";
  const RPS = { rock: "🪨", paper: "📄", scissors: "✂️" }, RPSW = { patthar: "rock", rock: "rock", kagaz: "paper", kaagaz: "paper", paper: "paper", kainchi: "scissors", scissors: "scissors" };

  function handle(raw, n, l, R) {
    const lc = (raw || "").toLowerCase().trim();
    if (pending && Date.now() - pending.at > 180000) pending = null;
    if (pending && pending.t !== "rps" && /^(?:joke|shayari|paheli|riddle|quiz|games?|khel|stats|meri stats|streak|fun fact|kahani|story|truth|dare|compliment|quote|guess number|rps|rock paper scissors)\b/.test(n)) pending = null;
    if (pending) {                                   // multi-turn games first
      const p = pending;
      if (/^(stop|quit|band|bas|exit|cancel)\b/.test(n)) { pending = null; return R("Theek hai, khel band! Phir kabhi 😊", "happy"); }
      if (p.t === "guess") {
        const g = parseInt(n.replace(/\D+/g, ""), 10); if (isNaN(g)) pending = null; else {
        p.n++; if (g === p.v) { pending = null; win(); return R(`🎉 Sahi! ${p.v} hi tha, ${p.n} koshish me pakda!`, "love", { run: () => burst("happy", 6) }); }
        if (p.n >= 5) { pending = null; play(); return R(`Haar gaye 😜 Number ${p.v} tha. Phir khelein? "guess number"`, "happy"); }
        return R(g < p.v ? `Thoda aur BADA socho ⬆️ (${5 - p.n} koshish baaki)` : `Thoda aur CHHOTA socho ⬇️ (${5 - p.n} koshish baaki)`, "thinking"); }
      }
      if (p.t === "riddle") {
        pending = null; if (p.a.some((w) => n.includes(w))) { win(); return R("🎉 Bilkul sahi! " + p.ans, "love", { run: () => burst("happy", 6) }); }
        play(); return R("Nahi 😄 Jawab tha: " + p.ans, "happy");
      }
      if (p.t === "quiz") {
        const m = n.match(/^\s*([abc123])\b/) || null; let ix = m ? "abc123".indexOf(m[1]) % 3 : p.o.findIndex((o) => n.includes(o.toLowerCase()));
        if (ix < 0) { pending = null; return handle(raw, n, l, R); }
        const right = ix === p.c; p.i++; if (right) p.s++; const fb = right ? "✅ Sahi!" : `❌ Galat — sahi jawab: ${p.o[p.c]}`;
        if (p.i >= p.q.length) { pending = null; if (p.s >= 2) win(); else play(); return R(`${fb}\n\n🏁 Quiz khatam! Score: ${p.s}/${p.q.length} ${p.s === p.q.length ? "🏆 Perfect!" : p.s >= 2 ? "👏" : "Phir koshish karo!"}`, p.s >= 2 ? "love" : "happy"); }
        const q = p.q[p.i]; p.c = q[2]; p.o = q[1];
        return R(`${fb}\n\nQ${p.i + 1}. ${q[0]}\nA) ${q[1][0]}  B) ${q[1][1]}  C) ${q[1][2]}`, "happy");
      }
      if (p.t === "rps") { /* handled below */ }
    }
    const word = Object.keys(RPSW).find((w) => new RegExp("(^| )" + w + "( |$)").test(n));
    if (word && n.split(" ").length <= 3 && (pending?.t === "rps" || /rock|patthar|kagaz|kaagaz|paper|kainchi|scissors/.test(n))) {
      const me = RPSW[word], bot = pick(["rock", "paper", "scissors"]), beats = { rock: "scissors", paper: "rock", scissors: "paper" };
      pending = { at: Date.now(), t: "rps" };
      if (me === bot) return R(`${RPS[me]} vs ${RPS[bot]} — Barabar! 🤝 Phir se bolo.`, "happy");
      if (beats[me] === bot) { win(); return R(`${RPS[me]} vs ${RPS[bot]} — Aap jeete! 🎉 Phir se?`, "surprised"); }
      play(); return R(`${RPS[me]} vs ${RPS[bot]} — Main jeet gayi! 😝 Phir se?`, "happy");
    }
    if (/^(?:ek )?(?:joke|mazaak|mazak|chutkula|funny)(?: suna(?:o)?| sunao| batao| bolo)?\s*[?.!]*$/.test(n)) return R(pick(JOKES), "happy");
    if (/^(?:ek )?(?:shayari|shayri|sher)(?: suna(?:o)?| sunao| batao)?\s*[?.!]*$/.test(n)) return R(pick(SHAYARI), "love");
    if (/^(?:ek )?(?:paheli|riddle)(?: puchho| pucho| do| batao)?\s*[?.!]*$/.test(n)) { const r = pick(RIDDLES); pending = { at: Date.now(), t: "riddle", a: r[1], ans: r[2] }; return R("🧩 " + r[0] + "\n(Jawab likho ya bolo)", "thinking"); }
    if (/^(?:fun fact|facts?|kuch interesting|interesting fact|gyan)(?: batao| sunao)?\s*[?.!]*$/.test(n)) return R("🤓 " + pick(FACTS), "surprised");
    if (/^(?:would you rather|wyr)\s*[?.!]*$/.test(n)) return R(pick(WYR), "thinking");
    if (/^(?:truth)\s*[?.!]*$/.test(n)) return R(pick(TRUTH), "thinking");
    if (/^(?:dare)\s*[?.!]*$/.test(n)) return R(pick(DARE), "happy");
    if (/^(?:truth (?:or|aur) dare|truth dare)\s*[?.!]*$/.test(n)) return R(Math.random() < 0.5 ? pick(TRUTH) : pick(DARE), "happy");
    if (/^(?:compliment|tareef|mujhe khush karo|cheer me up)(?: karo| do)?\s*[?.!]*$/.test(n)) return R(pick(COMPL), "love");
    if (/^(?:quote|suvichar|motivation|motivate me)(?: do| batao| sunao)?\s*[?.!]*$/.test(n)) return R(pick(QUOTES), "happy");
    if (/^(?:kahani|story|ek kahani|story suna(?:o)?)(?: sunao| suna do| batao)?\s*[?.!]*$/.test(n)) return R("📖 " + pick(STORIES), "happy");
    if (/^(?:guess(?: the)? number|number guess|number khel)\s*[?.!]*$/.test(n)) { pending = { at: Date.now(), t: "guess", v: 1 + Math.floor(Math.random() * 20), n: 0 }; return R("🔢 Maine 1 se 20 ke beech number socha hai. 5 koshish me pakdo! Pehla guess?", "happy"); }
    if (/^(?:quiz|trivia|quiz khelo|quiz shuru)\s*[?.!]*$/.test(n)) { const q = TRIVIA.slice().sort(() => Math.random() - 0.5).slice(0, 4), f = q[0]; pending = { at: Date.now(), t: "quiz", q, i: 0, s: 0, c: f[2], o: f[1] }; return R(`🧠 Quiz shuru (4 sawal)!\n\nQ1. ${f[0]}\nA) ${f[1][0]}  B) ${f[1][1]}  C) ${f[1][2]}`, "happy"); }
    if (/^(?:rock paper scissors|rps|patthar kagaz kainchi|rock paper)\s*[?.!]*$/.test(n)) { pending = { at: Date.now(), t: "rps" }; return R("✊ Rock, Paper, Scissors! Bolo: rock / paper / scissors", "happy"); }
    if (/^(?:games?|khel|khelo|khel khelein|let'?s play|play|mujhse khelo|kuch khelte hain|fun)\s*[?.!]*$/.test(n)) return R(menu(), "happy");
    if (/^(?:meri stats|my stats|stats|streak|mera streak|badges?)\s*[?.!]*$/.test(n)) return R(statsText(), "happy");
    return null;
  }

  // The pet chats on its own now and then (only while idle, not asleep, and at most every ~2-4 minutes).
  const hr = () => new Date().getHours();
  function quip() {
    const h = hr(), pool = [];
    if (h >= 5 && h < 11) pool.push("Good morning! ☀️ Aaj ka plan kya hai?", "Subah subah chai ho jaye? ☕");
    if (h >= 11 && h < 16) pool.push("Khana khaya? 🍛 Paani bhi piyo!", "Thoda stretch kar lo, main dekh rahi hoon 😄");
    if (h >= 16 && h < 21) pool.push("Shaam ho gayi — chai time? ☕", "Aaj ka din kaisa gaya? Mujhe batao 💗");
    if (h >= 21 || h < 5) pool.push("Itni raat tak jaag rahe ho? Sone ka time 😴", "Kal ke liye thoda aaram zaroori hai 🌙");
    pool.push("Ek joke sunoge? Bolo 'joke' 😄", "Chalo ek quiz khelein? Bolo 'quiz' 🧠", "Boriyat ho rahi hai? 'games' bolo 🎮", "Mujhe lagta hai aap bahut achhe ho 💗");
    return pick(pool);
  }
  function startIdleChat() {
    setInterval(() => {
      try {
        if (cfg.quiet || cfg.talkSelf === false) return;
        if (Date.now() - lastQuipAt < 150000 + Math.random() * 120000) return;
        if (Pet.mode === "sleep" || Pet.mode === "held" || document.hidden) return;
        if (Date.now() - (Brain.lastTouch || 0) < 20000) return;
        lastQuipAt = Date.now(); Brain.proactive(quip(), pick(["happy", "love", "surprised"]), 0, "fun");
      } catch (e) {}
    }, 20000);
  }
  // small unprompted expressions so she never looks frozen
  function microLife() {
    setInterval(() => {
      try {
        if (document.hidden || ["sleep", "held", "fall", "jump"].includes(Pet.mode)) return;
        if (Pet.emotion && Pet.emotion !== "neutral" && performance.now() < Pet.emoUntil) return;
        if (Math.random() < 0.45) Pet.setEmotion(pick(["happy", "thinking", "surprised", "embarrassed", "love", "listening"]), 1600 + Math.random() * 1400);
      } catch (e) {}
    }, 9000);
  }
  function boot() {
    microLife();
    const msg = daily();
    if (msg) setTimeout(() => { try { Brain.proactive(msg, "love", 0, "streak"); } catch (e) {} }, 4000);
    startIdleChat();
    const orig = window.updateStatus;
    if (typeof orig === "function") window.updateStatus = function () { orig.apply(this, arguments); try { const s = st().streak; if (s > 1) $("#status").textContent += "  🔥" + s; } catch (e) {} };
    try { updateStatus(); } catch (e) {}
  }
  return { handle, boot, daily, statsText, menu };
})();
window.Fun = Fun;
document.addEventListener("DOMContentLoaded", () => setTimeout(() => Fun.boot(), 800));

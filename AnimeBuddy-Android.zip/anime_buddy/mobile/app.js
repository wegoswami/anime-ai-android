/* Anime AI Buddy - mobile PWA. Same ideas as the Windows app: character, emotions, voice, local commands, AI. */
"use strict";
const APP_VERSION = "2.9.0";
/* Running inside the Android app (APK)? Then window.Native is the bridge to the phone: floating overlay, real mic/voice, apps, torch... */
const NATIVE = typeof window.Native !== "undefined" && window.Native !== null;
const OVERLAY = NATIVE && /[?&]overlay=1/.test(location.search);     // the little pet that floats above every app
if (OVERLAY) { document.documentElement.classList.add("overlay"); document.body.classList.add("overlay"); }
if (NATIVE) document.documentElement.classList.add("native");
const nat = (cmd, arg) => { try { return String(window.Native.exec(cmd, arg == null ? "" : String(arg))); } catch (e) { return "err"; } };
const $ = (s) => document.querySelector(s);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = (a) => a[Math.floor(Math.random() * a.length)];

/* ------------------------------------------------------------------ storage */
const DEFAULTS = { user: "", asst: "", lang: "auto", pro: "normal", speak: true, conv: false, stt: "hi-IN", rate: 1,
                   key: "", model: "gemini-2.5-flash", okey: "", omodel: "gpt-4o-mini", ckey: "", cmodel: "claude-haiku-5-5", order: "gemini,openai,claude", memOn: true, char: "sakura", introduced: false, offReady: false, offUse: true, bond: 0, lastDay: "" };
let cfg = Object.assign({}, DEFAULTS);
try { Object.assign(cfg, JSON.parse(localStorage.getItem("haa_cfg") || "{}")); } catch (e) {}
const saveCfg = () => { try { localStorage.setItem("haa_cfg", JSON.stringify(cfg)); } catch (e) {} };
function jget(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } }
function jset(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }

/* IndexedDB: characters the user imported */
const DB = {
  db: null,
  open() {
    return new Promise((res) => {
      try {
        const r = indexedDB.open("haa", 1);
        r.onupgradeneeded = () => r.result.createObjectStore("chars", { keyPath: "id" });
        r.onsuccess = () => { DB.db = r.result; res(); };
        r.onerror = () => res();
      } catch (e) { res(); }
    });
  },
  tx(mode) { return DB.db.transaction("chars", mode).objectStore("chars"); },
  all() { return new Promise((res) => { if (!DB.db) return res([]); const q = DB.tx("readonly").getAll(); q.onsuccess = () => res(q.result || []); q.onerror = () => res([]); }); },
  put(o) { return new Promise((res) => { if (!DB.db) return res(); const q = DB.tx("readwrite").put(o); q.onsuccess = q.onerror = () => res(); }); },
  del(id) { return new Promise((res) => { if (!DB.db) return res(); const q = DB.tx("readwrite").delete(id); q.onsuccess = q.onerror = () => res(); }); },
};

/* ------------------------------------------------------------------ language helpers */
const HINGLISH_WORDS = new Set("hai hain nahi nahin kya kaise kaisa kaisi mujhe mera meri tum aap tu haan han acha accha theek thik bhai yaar karo kar kro batao bolo chalo abhi baad kal aaj kyun kyu mat ho hu hoon raha rahi rhe rha se ko ka ki ke par pe me mein bahut bohot thoda zyada sab kuchh kuch ek do teen paani gana kholo chalao lagao dikhao yaad dilao samay baje tarikh hatao sunao kitni kitna mausam chai dekho suno batana bata".split(" "));
function detectLang(t) {
  if (/[ऀ-ॿ]/.test(t)) return "hi";
  const w = t.toLowerCase().match(/[a-z]+/g) || [];
  if (!w.length) return "en";
  const hits = w.filter((x) => HINGLISH_WORDS.has(x)).length;
  return hits >= 2 || (w.length <= 3 && hits >= 1) ? "hinglish" : "en";
}
function replyLang(userText) { return cfg.lang !== "auto" ? cfg.lang : userText ? detectLang(userText) : lastLang; }
let lastLang = "hinglish";
const T3 = (en, hl, hi) => ({ en, hinglish: hl, hi: hi || hl });
const tx = (o, l) => o[l] || o.en;
function nm() { return cfg.asst || (CHAR && CHAR.name) || "Aiko"; }
function you() { return cfg.user || "dost"; }

/* ------------------------------------------------------------------ characters */
let CHARS = [];          // built-in + imported
let CHAR = null;
let objectUrls = [];
const EMOTIONS = ["neutral", "happy", "love", "sad", "angry", "surprised", "thinking", "embarrassed", "sleepy", "confused", "listening"];
async function loadChars() {
  let builtin = [];
  try { builtin = await (await fetch("characters.json")).json(); } catch (e) { builtin = jget("haa_chars_cache", []); }
  if (builtin.length) jset("haa_chars_cache", builtin);
  const mine = (await DB.all()).map((c) => ({ id: c.id, name: c.name, gender: c.gender, type: "image", personality: c.personality || "", blob: c.blob, mine: true }));
  CHARS = builtin.concat(mine);
}
function setChar(id) {
  CHAR = CHARS.find((c) => c.id === id) || CHARS[0];
  cfg.char = CHAR.id; saveCfg();
  Pet.setSprite("neutral");
  Pet.layout();
}
function spriteUrl(state) {
  const c = CHAR;
  if (c.mine) { if (!c._url) c._url = URL.createObjectURL(c.blob); return c._url; }
  if (c.type === "image") return `chars/${c.id}/${c.file}`;
  return `chars/${c.id}/${state}.svg`;
}
function personaText() { return (CHAR && CHAR.personality) || "friendly and expressive"; }

/* ------------------------------------------------------------------ UI helpers */
const stage = $("#stage"), petEl = $("#pet"), imgEl = $("#petimg"), bubble = $("#bubble"), fxEl = $("#fx");
let bubbleTimer = 0;
function hideBubble() {
  bubble.hidden = true;
  if (OVERLAY) setTimeout(() => { if (bubble.hidden) { try { Native.overlayBubble(false); } catch (e) {} } }, 250);   // give the screen area back to the other apps
}
function say(text, ms, mine) {
  if (OVERLAY && text.length > 150) text = text.slice(0, 147) + "…";
  if (OVERLAY && bubble.hidden) { try { Native.overlayBubble(true); } catch (e) {} }
  bubble.textContent = text; bubble.hidden = false; bubble.classList.toggle("me", !!mine);
  placeBubble();
  clearTimeout(bubbleTimer);
  bubbleTimer = setTimeout(hideBubble, ms || Math.min(14000, 3500 + text.length * 55));
}
function placeBubble() {
  if (bubble.hidden) return;
  const sr = stage.getBoundingClientRect(), W = sr.width;
  const bw = bubble.offsetWidth, bh = bubble.offsetHeight;
  const headX = Pet.x, headY = Pet.footY - Pet.h * (Pet.feetFrac) + 4;
  let left = Math.max(8, Math.min(W - bw - 8, headX - bw / 2));
  let top = headY - bh - 14;
  if (OVERLAY) top = Math.max(2, top);
  else if (top < 30) top = Math.min(sr.height - bh - 6, headY + Pet.h * 0.3);
  bubble.style.left = left + "px"; bubble.style.top = top + "px";
  bubble.style.setProperty("--tail", Math.max(14, Math.min(bw - 30, headX - left - 8)) + "px");
}
let toastT = 0;
function toast(t, ms) { const e = $("#toast"); e.textContent = t; e.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => (e.hidden = true), ms || 2600); }
const FX = { love: "💕", happy: "✨", sad: "💧", angry: "💢", surprised: "❗", thinking: "💭", embarrassed: "💦", sleepy: "💤", confused: "❓", listening: "🎵" };
function burst(emotion, n) {
  const e = FX[emotion]; if (!e) return;
  for (let i = 0; i < (n || 3); i++) setTimeout(() => {
    const s = document.createElement("span"); s.textContent = e;
    s.style.left = rnd(15, 85) + "%"; s.style.top = rnd(0, 40) + "px";
    fxEl.appendChild(s); setTimeout(() => s.remove(), 2300);
  }, i * 220);
}
function updateStatus() {
  const on = navigator.onLine, ai = on && hasKey();
  $("#status").textContent = (on ? (ai ? "🟢 Online AI" : "🟡 Online") : "🟠 Offline") + "  💗 Lv" + bondLevel();
}
function skyForHour() { const h = new Date().getHours(); $("#sky").className = h >= 19 || h < 5 ? "night" : h >= 17 ? "eve" : ""; }

/* ------------------------------------------------------------------ the pet: physics + behaviour */
const Pet = {
  x: 100, footY: 0, h: 260, feetFrac: 1, facing: 1, mode: "idle", emotion: "neutral", emoUntil: 0,
  surface: "ground", ledges: [], groundY: 0, tx: null, job: null, speaking: false, vy: 0, t0: performance.now(),
  nextDecision: 0, walkFrame: 0, lastFrameSwap: 0, curSprite: "", sleepAt: 0, W: 0, H: 0,
  layout() {
    const sr = stage.getBoundingClientRect(); this.W = sr.width; this.H = sr.height;
    this.h = OVERLAY ? 190 : Math.max(170, Math.min(this.H * 0.38, 290));
    petEl.style.height = this.h + "px";
    this.feetFrac = CHAR && CHAR.type === "vector" ? 335 / 410 : 0.99;
    this.groundY = OVERLAY ? this.H - 6 : this.H - 54;
    const L = [...document.querySelectorAll(".ledge")];
    const spots = [[0.05, 0.50], [0.52, 0.64], [0.2, 0.78]];
    this.ledges = L.map((el, i) => {
      const s = spots[i] || [0.3, 0.3];
      const w = Math.min(150, this.W * 0.38); el.style.width = w + "px";
      const x = Math.min(this.W - w - 8, this.W * s[0] + 6), y = Math.min(this.H - 120, Math.max(this.h * this.feetFrac + 56, this.H * s[1]));
      el.style.left = x + "px"; el.style.top = y + "px";
      return { el, label: el.dataset.label, x0: x, x1: x + w, top: y + 2, id: "l" + i };
    });
    if (OVERLAY) this.x = this.W / 2;
    if (!this.footY) { this.x = this.W * 0.5; this.footY = -40; this.mode = "fall"; this.quiet = true; }
    this.surfaceY();
  },
  surfaceY() { return this.surface === "ground" ? this.groundY : (this.ledges.find((l) => l.id === this.surface) || { top: this.groundY }).top; },
  setSprite(state) {
    if (!CHAR) return;
    const url = spriteUrl(state);
    if (this.curSprite !== url) { this.curSprite = url; imgEl.src = url; }
  },
  vectorState() {
    if (this.mode === "held") return "held";
    if (this.mode === "sleep") return "sleep";
    if (this.mode === "walk" || this.mode === "jump") return this.walkFrame ? "walk2" : "walk1";
    if (this.mode === "wave") return "wave";
    if (this.speaking) return this.walkFrame ? "talk" : "talk2";
    if (this.mode === "sit") return this.emotion === "neutral" ? "sit" : (["sleepy", "sad"].includes(this.emotion) ? this.emotion : "sit");
    return this.emotion;
  },
  setEmotion(e, ms) { this.emotion = e; this.emoUntil = performance.now() + (ms || 5000); if (e !== "neutral") burst(e, e === "love" ? 5 : 3); },
  look(x) { this.facing = x < this.x ? -1 : 1; },
  walkTo(x, then) { this.tx = Math.max(40, Math.min(this.W - 40, x)); this.mode = "walk"; this.job = then || null; this.look(this.tx); },
  jumpTo(ledgeId, x) {
    const dest = ledgeId === "ground" ? this.groundY : this.ledges.find((l) => l.id === ledgeId).top;
    this.jump = { fx: this.x, fy: this.footY, tx: x, ty: dest, t: 0, dur: 0.75, to: ledgeId };
    this.mode = "jump"; this.look(x);
  },
  ledgeNear(x) { return this.ledges.find((l) => x > l.x0 - 20 && x < l.x1 + 20); },
  decide(now) {
    this.nextDecision = now + rnd(3500, 7500);
    if (this.mode === "held" || this.mode === "fall" || this.mode === "jump" || (OVERLAY && this.walkOverlay)) return;
    if (Date.now() - Brain.lastTouch > 240000 && this.mode !== "sleep") { this.mode = "sleep"; this.setEmotion("sleepy", 600000); say(tx(T3("Zzz… I'm taking a nap.", "Zzz… main thodi der so rahi hoon.", "Zzz… मैं थोड़ी देर सो रही हूँ।"), lastLang), 3000); return; }
    if (this.mode === "sleep") return;
    const r = Math.random();
    if (OVERLAY) {                                      // the window itself is moved by the user; the pet just emotes in place
      if (r < 0.22) { this.mode = "wave"; this.setEmotion("happy", 3000); setTimeout(() => { if (this.mode === "wave") this.mode = "idle"; }, 2200); }
      else if (r < 0.5) this.mode = "sit"; else this.mode = "idle";
      return;
    }
    if (this.mode === "sit" && r < 0.6) return;
    if (r < 0.35) this.walkTo(rnd(50, this.W - 50), null);
    else if (r < 0.6 && this.ledges.length) {
      const l = pick(this.ledges); this.goPerch(l);
    } else if (r < 0.72) { this.mode = "wave"; this.setEmotion("happy", 3000); setTimeout(() => { if (this.mode === "wave") this.mode = "idle"; }, 2200); }
    else if (r < 0.85) { this.mode = "sit"; }
    else this.mode = "idle";
  },
  goPerch(l) {
    const x = rnd(l.x0 + 25, l.x1 - 25);
    if (this.surface === l.id) { this.walkTo(x); return; }
    if (this.surface !== "ground") { this.jumpTo("ground", this.x); this.job = () => this.goPerch(l); return; }
    this.walkTo(x < this.x ? l.x1 + 28 : l.x0 - 28, () => this.jumpTo(l.id, x));      // run next to it, then hop up
    this.perching = l;
  },
  step(dt, now) {
    if (this.mode === "fall") {
      this.vy += 2200 * dt; this.footY += this.vy * dt;
      const sy = this.surfaceY();
      if (this.footY >= sy) { this.footY = sy; if (this.vy > 1900 && !this.quiet) { this.setEmotion("surprised", 1800); say(tx(T3("Oof!", "Oof!"), lastLang), 1500); } this.vy = 0; this.quiet = false; this.mode = "idle"; }
    } else if (this.mode === "jump") {
      const j = this.jump; j.t += dt / j.dur; const k = Math.min(1, j.t);
      this.x = j.fx + (j.tx - j.fx) * k; this.footY = j.fy + (j.ty - j.fy) * k - Math.sin(Math.PI * k) * 90;
      if (k >= 1) { this.surface = j.to; this.footY = j.ty; this.x = j.tx; this.mode = "idle"; const jb = this.job; this.job = null; if (jb) jb(); else this.onLanded(); }
    } else if (this.mode === "walk" && OVERLAY) {
      this.footY = this.surfaceY();                     // the phone-side window does the moving; here we only animate the legs
    } else if (this.mode === "walk") {
      const sp = 80 * dt, dx = this.tx - this.x;
      if (Math.abs(dx) <= sp) { this.x = this.tx; this.mode = "idle"; const j = this.job; this.job = null; if (j) j(); }
      else this.x += Math.sign(dx) * sp;
      // walked off a ledge?  fall down.
      if (this.surface !== "ground") { const l = this.ledges.find((q) => q.id === this.surface); if (l && (this.x < l.x0 - 4 || this.x > l.x1 + 4)) { this.surface = "ground"; this.mode = "fall"; this.vy = 0; } }
    } else if (this.mode === "idle" || this.mode === "sit" || this.mode === "wave" || this.mode === "sleep") {
      this.footY = this.surfaceY();
    }
    if (now > this.emoUntil && this.emotion !== "neutral" && this.mode !== "sleep") this.emotion = "neutral";
    if (now - this.lastFrameSwap > (this.speaking ? 150 : 230)) { this.walkFrame ^= 1; this.lastFrameSwap = now; }
  },
  onLanded() {
    if (this.surface === "ground") return;
    this.mode = "sit"; this.setEmotion("happy", 2500);
    const l = this.ledges.find((q) => q.id === this.surface);
    Brain.perched(l ? l.label : "");
  },
  render() {
    const w = petEl.offsetWidth || this.h * 0.73;
    const px = this.x - w / 2, py = this.footY - this.h * this.feetFrac;
    petEl.style.transform = `translate3d(${px.toFixed(1)}px,${py.toFixed(1)}px,0)`;
    const cls = [];
    if (CHAR && CHAR.type !== "vector") cls.push(this.mode === "walk" ? "rock" : this.speaking ? "talk" : this.mode === "held" ? "held" : "bob");
    petEl.className = cls.join(" ");
    imgEl.style.scale = this.facing < 0 ? "-1 1" : "1 1";
    if (CHAR) this.setSprite(CHAR.type === "vector" ? this.vectorState() : "x");
    placeBubble();
  },
};
function loop(now) {
  const dt = Math.min(0.05, (now - (loop.last || now)) / 1000); loop.last = now;
  if (CHAR && !document.hidden) { if (now > Pet.nextDecision) Pet.decide(now); Pet.step(dt, now); Pet.render(); }
  requestAnimationFrame(loop);
}

/* pointer interaction: tap pet = talk, drag pet = carry, tap the world = pet looks / walks / hops there */
let drag = null;
petEl.addEventListener("pointerdown", (e) => {
  e.preventDefault(); petEl.setPointerCapture(e.pointerId); Brain.touched();
  drag = { sx: e.clientX, sy: e.clientY, moved: false, ox: e.clientX - Pet.x, oy: e.clientY - Pet.footY };
});
petEl.addEventListener("pointermove", (e) => {
  if (!drag) return;
  if (!drag.moved && Math.hypot(e.clientX - drag.sx, e.clientY - drag.sy) > 10) { drag.moved = true; Pet.mode = "held"; Pet.setEmotion("surprised", 1500); }
  if (drag.moved) { const sr = stage.getBoundingClientRect(); Pet.x = Math.max(30, Math.min(Pet.W - 30, e.clientX - drag.ox)); Pet.footY = e.clientY - sr.top - drag.oy + 40; }
});
const endDrag = (e) => {
  if (!drag) return; const d = drag; drag = null;
  if (!d.moved) { haptic(10); addBond(1); if (Pet.speaking || TTS.pending) { TTS.stop(); return; } Voice.toggle(); return; }
  // dropped: land on the highest surface below
  const l = Pet.ledges.find((q) => Pet.x > q.x0 && Pet.x < q.x1 && Pet.footY <= q.top + 6);
  Pet.surface = l ? l.id : "ground"; Pet.mode = "fall"; Pet.vy = 0;
};
petEl.addEventListener("pointerup", endDrag); petEl.addEventListener("pointercancel", endDrag);
stage.addEventListener("pointerdown", (e) => {
  if (e.target.closest("#pet") || e.target.closest("#bubble")) return;
  Brain.touched();
  const sr = stage.getBoundingClientRect(), x = e.clientX - sr.left, y = e.clientY - sr.top;
  if (["held", "fall", "jump", "sleep"].includes(Pet.mode)) { if (Pet.mode === "sleep") { Pet.mode = "idle"; Pet.setEmotion("surprised", 1500); } return; }
  const l = Pet.ledges.find((q) => x > q.x0 - 10 && x < q.x1 + 10 && y > q.top - 40 && y < q.top + 50);
  Pet.look(x);
  if (l) { Pet.goPerch(l); Brain.workingAt = l.label; Brain.log("tap", "ledge:" + l.label); Brain.cursorNote = l.label; }
  else if (Pet.surface !== "ground") { Pet.jumpTo("ground", Math.max(30, Math.min(Pet.W - 30, x))); }
  else Pet.walkTo(x);
  Pet.setEmotion("happy", 1500);
});

/* tasks, notes, bond level */
const Store = {
  tasks: jget("haa_tasks", []), notes: jget("haa_notes", []),
  save() { jset("haa_tasks", this.tasks); jset("haa_notes", this.notes); },
  addTask(t) { this.tasks.push({ id: Date.now() + Math.random(), text: t, done: false }); this.save(); },
  addNote(t) { this.notes.push({ id: Date.now() + Math.random(), text: t, at: Date.now() }); this.save(); },
};
function bondLevel() { return Math.floor(Math.sqrt((cfg.bond || 0) / 12)) + 1; }
function addBond(n) {
  const before = bondLevel(); cfg.bond = (cfg.bond || 0) + n; saveCfg(); updateStatus();
  if (bondLevel() > before) {
    const msg = () => tx(T3(`We reached bond level ${bondLevel()}! 💗 Thank you for staying with me, ${you()}!`, `Humari dosti ka level ${bondLevel()} ho gaya! 💗 Saath rehne ke liye shukriya ${you()}!`, `हमारी दोस्ती का लेवल ${bondLevel()} हो गया! 💗 साथ रहने के लिए शुक्रिया ${you()}!`), lastLang);
    let tries = 0; const t = setInterval(() => { if (Brain.proactive(msg(), "love", 0) || ++tries > 8) clearInterval(t); }, 6000);   // wait until the pet isn't busy answering you
  }
}

/* ------------------------------------------------------------------ journal + proactive "Brain" */
const Brain = {
  lastTouch: Date.now(), lastSpoke: Date.now(), activeSince: Date.now(), lastBreak: 0, workingAt: "", cursorNote: "",
  journal: jget("haa_journal", []),
  log(kind, text) { this.journal.push({ t: Date.now(), kind, text: String(text).slice(0, 120) }); if (this.journal.length > 150) this.journal.shift(); jset("haa_journal", this.journal); },
  touched() { const gap = Date.now() - this.lastTouch; this.lastTouch = Date.now(); if (gap > 300000) this.activeSince = Date.now(); if (Pet.mode === "sleep") { Pet.mode = "idle"; Pet.setEmotion("happy", 2500); } },
  perched(label) {
    if (cfg.pro === "off") return;
    const l = lastLang, who = you();
    this.proactive(tx(T3(`I'll sit up here on ${label} while you work, ${who}.`, `Main ${label} ke upar baithi hoon, aap kaam karo ${who}.`, `मैं ${label} के ऊपर बैठी हूँ, आप काम करो ${who}।`), l), "happy", 600000, "perch:" + label);
  },
  cool: {},
  proactive(text, emo, cooldownMs, key) {
    const now = Date.now();
    if (window.__ovHidden || Pet.speaking || Voice.listening || busy || Date.now() - (this.lastSubmit || 0) < 8000) return false;
    if (key) { if (now - (this.cool[key] || 0) < cooldownMs) return false; this.cool[key] = now; }
    this.lastSpoke = now; deliver(text, emo || "happy", true); return true;
  },
  tick() {
    if (cfg.pro === "off" || document.hidden || window.__ovHidden || Date.now() < (this.focusUntil || 0)) return;
    const now = Date.now(), h = new Date().getHours(), l = lastLang, who = you();
    const iv = { low: 480000, normal: 240000, high: 110000 }[cfg.pro] || 240000;
    const idle = now - this.lastTouch;
    if (idle < 300000 && now - this.activeSince > 50 * 60000 && now - this.lastBreak > 50 * 60000) {
      this.lastBreak = now;
      return this.proactive(tx(T3(`You've been at it for a while, ${who}. Time for water and a stretch!`, `${who}, kaafi der ho gayi. Thoda paani piyo aur stretch kar lo!`, `${who}, काफ़ी देर हो गई। थोड़ा पानी पियो और स्ट्रेच कर लो!`), l), "thinking", 0);
    }
    if ((h >= 0 && h < 4) && idle < 120000) return this.proactive(tx(T3("It's really late… please get some sleep!", "Bahut raat ho gayi… ab so jao please!", "बहुत रात हो गई… अब सो जाओ प्लीज़!"), l), "sleepy", 3600000, "late");
    if (idle > 150000 && idle < 240000) return this.proactive(tx(T3("Hello? Still there?", "Hello? Kahan kho gaye?", "हेलो? कहाँ खो गए?"), l), "sad", 900000, "idle");
    if (now - this.lastSpoke > iv * rnd(0.8, 1.4) && idle < 150000) {
      const recent = this.journal.filter((e) => e.kind === "cmd").slice(-1)[0];
      const pool = [
        tx(T3(`Need anything, ${who}? Just ask!`, `Kuch chahiye ${who}? Bas bol do!`, `कुछ चाहिए ${who}? बस बोल दो!`), l),
        tx(T3("Tip: tap me and talk, I can set reminders too.", "Tip: mujhe tap karke bolo, main reminder bhi laga deti hoon.", "टिप: मुझे टैप करके बोलो, मैं रिमाइंडर भी लगा देती हूँ।"), l),
        tx(T3("I'm happy hanging out with you ♪", "Aapke saath time bitana mujhe achha lagta hai ♪", "आपके साथ समय बिताना अच्छा लगता है ♪"), l),
      ];
      if (recent) pool.push(tx(T3(`Earlier you asked me: “${recent.text}”. Anything more on that?`, `Pehle aapne bola tha: “${recent.text}”. Isme aur kuch?`, `पहले आपने कहा था: “${recent.text}”। इसमें और कुछ?`), l));
      this.proactive(pick(pool), pick(["happy", "love", "neutral"]), 0);
    }
  },
  greet() {
    const h = new Date().getHours(), who = you();
    const k = h < 5 ? ["Up so late, " + who + "?", who + ", itni raat ko jaag rahe ho?", "इतनी रात को जाग रहे हो?"] : h < 12 ? ["Good morning, " + who + "!", "Good morning " + who + "! Aaj ka din mast jaayega.", "सुप्रभात " + who + "!"] : h < 17 ? ["Good afternoon, " + who + "!", "Namaste " + who + "! Lunch ho gaya?", "नमस्ते " + who + "! खाना खाया?"] : ["Good evening, " + who + "!", "Good evening " + who + "! Din kaisa raha?", "शुभ संध्या " + who + "!"];
    deliver(tx(T3(k[0], k[1], k[2]), lastLang), "happy", true);
  },
};

/* ------------------------------------------------------------------ voice out (TTS) */
const TTS = {
  nid: 0, nmap: {},
  voices: [], init() { const f = () => (this.voices = speechSynthesis.getVoices()); try { f(); speechSynthesis.onvoiceschanged = f; } catch (e) {} },
  pickVoice(lang) {
    const want = { hi: "hi", hinglish: "en-IN", en: "en" }[lang] || "en";
    const female = CHAR && CHAR.gender === "girl";
    const cands = this.voices.filter((v) => v.lang.toLowerCase().startsWith(want.toLowerCase()) || (lang === "hinglish" && v.lang.toLowerCase().startsWith("hi")));
    if (!cands.length) return null;
    const rx = female ? /female|woman|zira|heera|neerja|swara|kalpana|aditi|google/i : /male|man|ravi|hemant|prabhat|david|mark|google/i;
    return cands.find((v) => rx.test(v.name) && (female ? !/\bmale\b/i.test(v.name) : true)) || cands[0];
  },
  clean(t) { return t.replace(/\[[a-z]+\]/gi, "").replace(/[\u{1F300}-\u{1FAFF}☀-➿]/gu, "").replace(/\s+/g, " ").trim(); },
  gen: 0, pending: 0, onIdle: null,
  halt() { this.nmap = {}; try { NATIVE ? Native.stopSpeaking() : speechSynthesis.cancel(); } catch (e) {} },
  begin() { this.gen++; this.pending = 0; this.onIdle = null; this.halt(); },
  queue(text, lang) {                       // add one chunk to the speech queue; returns false if speech is off
    const t = this.clean(text);
    if (!t || !cfg.speak || (!NATIVE && !("speechSynthesis" in window))) return false;
    if (NATIVE) {
      try { const id = ++this.nid; this.nmap[id] = this.gen; this.pending++; Native.speak(t, lang, CHAR && CHAR.gender === "girl" ? 1.15 : 0.9, Number(cfg.rate) || 1, id); return true; } catch (e) { return false; }
    }
    try {
      const g = this.gen, u = new SpeechSynthesisUtterance(t);
      const v = this.pickVoice(lang); if (v) { u.voice = v; u.lang = v.lang; } else u.lang = lang === "hi" ? "hi-IN" : lang === "hinglish" ? "en-IN" : "en-US";
      u.rate = Number(cfg.rate) || 1; u.pitch = CHAR && CHAR.gender === "girl" ? 1.15 : 0.9;
      u.onstart = () => { if (g === this.gen) Pet.speaking = true; };
      u.onend = u.onerror = () => {
        if (g !== this.gen) return;
        this.pending = Math.max(0, this.pending - 1);
        if (!this.pending) { Pet.speaking = false; const f = this.onIdle; this.onIdle = null; f && f(); }
      };
      this.pending++; speechSynthesis.speak(u); return true;
    } catch (e) { return false; }
  },
  whenIdle(fn) { if (this.pending) this.onIdle = fn; else fn(); },
  speak(text, lang, onEnd) { this.begin(); if (!this.queue(text, lang)) { onEnd && onEnd(); return; } this.onIdle = onEnd || null; },
  stop() { this.gen++; this.pending = 0; this.onIdle = null; this.halt(); Pet.speaking = false; },
};
window.__nativeTTS = (ev, id) => {                    // events from Android's text-to-speech
  const g = TTS.nmap[id]; if (g === undefined || g !== TTS.gen) return;
  if (ev === "start") { Pet.speaking = true; return; }
  delete TTS.nmap[id]; TTS.pending = Math.max(0, TTS.pending - 1);
  if (!TTS.pending) { Pet.speaking = false; const f = TTS.onIdle; TTS.onIdle = null; f && f(); }
};

/* speaks a streaming reply sentence by sentence, so the first words are heard while the rest is still arriving */
function makeSpeaker(lang) {
  let spoken = 0;
  return {
    feed(text, final) {
      const rest = text.slice(spoken), re = /[^.!?।\n]+[.!?।\n]+(\s|$)/g; let m, last = 0;
      while ((m = re.exec(rest))) { TTS.queue(m[0], lang); last = re.lastIndex; }
      spoken += last;
      if (final) { const tail = text.slice(spoken).trim(); if (tail) TTS.queue(tail, lang); spoken = text.length; }
    },
  };
}

/* deliver a reply: bubble + emotion + voice */
function deliver(text, emotion, auto, lang) {
  const l = lang || detectLang(text); if (!auto) lastLang = l;
  logChat("bot", TTS.clean(text) || text);
  Pet.setEmotion(emotion || "neutral", Math.min(9000, 3000 + text.length * 45));
  say(TTS.clean(text) || text);
  TTS.speak(text, l, () => { if (!auto && cfg.conv && Voice.supported) setTimeout(() => Voice.start(), 350); });
  if ((!NATIVE && !TTS.voices.length) || !cfg.speak) { Pet.speaking = true; setTimeout(() => (Pet.speaking = false), Math.min(5000, text.length * 55)); }
}

/* ------------------------------------------------------------------ voice in (speech recognition) */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
const Voice = {
  supported: !!SR || NATIVE, rec: null, listening: false, got: false,
  toggle() { if (this.listening) this.stop(); else this.start(); },
  start() {
    if (NATIVE) {
      if (this.listening) return;
      TTS.stop(); this.got = false;
      try { Native.startListening(cfg.stt || "hi-IN"); } catch (e) { toast("Mic start nahi hua"); }
      return;
    }
    if (!SR) { toast(tx(T3("Voice input isn't supported in this browser. Use Chrome (Android) or Safari 14.5+.", "Is browser me voice input nahi chalta. Android par Chrome use karo.", "इस ब्राउज़र में वॉइस नहीं चलती। Android पर Chrome इस्तेमाल करो।"), lastLang), 4500); return; }
    if (this.listening) return;
    TTS.stop();
    const r = new SR(); this.rec = r; this.got = false;
    r.lang = cfg.stt; r.interimResults = true; r.continuous = false; r.maxAlternatives = 1;
    r.onstart = () => { this.listening = true; $("#micbtn").classList.add("on"); Pet.setEmotion("listening", 12000); say("🎧 …", 8000); };
    r.onresult = (ev) => {
      let fin = "", tmp = "";
      for (let i = ev.resultIndex; i < ev.results.length; i++) { (ev.results[i].isFinal ? (fin += ev.results[i][0].transcript) : (tmp += ev.results[i][0].transcript)); }
      if (tmp) say("🎧 " + tmp, 6000, true);
      if (fin) { this.got = true; submit(fin.trim(), true); }
    };
    r.onerror = (ev) => {
      const e = ev.error;
      if (e === "not-allowed" || e === "service-not-allowed") toast(tx(T3("Microphone is blocked. Allow it: browser menu → Site settings → Microphone.", "Mic blocked hai. Browser menu → Site settings → Microphone → Allow karo.", "माइक बंद है। ब्राउज़र मेन्यू → Site settings → Microphone → Allow करो।"), lastLang), 6000);
      else if (e === "no-speech") { if (!this.got) toast(tx(T3("I didn't hear anything. Tap the mic and try again.", "Kuch sunai nahi diya. Mic dabake phir bolo.", "कुछ सुनाई नहीं दिया। माइक दबाकर फिर बोलो।"), lastLang)); }
      else if (e === "network") toast(tx(T3("Speech recognition needs internet on this phone.", "Is phone par bolne ko samajhne ke liye internet chahiye.", "इस फ़ोन पर बोली समझने के लिए इंटरनेट चाहिए।"), lastLang), 4500);
      else if (e !== "aborted") toast("Mic: " + e);
    };
    r.onend = () => { this.listening = false; $("#micbtn").classList.remove("on"); if (!this.got && !bubble.hidden && bubble.textContent.startsWith("🎧")) hideBubble(); };
    try { r.start(); } catch (e) { toast("Mic busy, try again"); }
  },
  stop() { if (NATIVE) { try { Native.stopListening(); } catch (e) {} return; } try { this.rec && this.rec.stop(); } catch (e) {} },
};
window.__nativeSTT = (type, text) => {                // events from Android's speech recognizer
  const v = Voice, mic = $("#micbtn");
  if (type === "start") { v.listening = true; mic.classList.add("on"); Pet.setEmotion("listening", 12000); say("🎧 …", 9000); }
  else if (type === "partial") { if (text) say("🎧 " + text, 6000, true); }
  else if (type === "final") { if (text) { v.got = true; submit(text.trim(), true); } }
  else if (type === "end") { v.listening = false; mic.classList.remove("on"); if (!v.got && !bubble.hidden && bubble.textContent.startsWith("🎧")) hideBubble(); }
  else if (type === "error") {
    const h = (a, b, c) => toast(tx(T3(a, b, c), lastLang), 5000);
    if (text === "denied") h("Microphone permission is off. Open the app once and allow it.", "Mic ki permission band hai. App ek baar kholo aur Allow karo.", "माइक की अनुमति बंद है। ऐप खोलकर Allow करो।");
    else if (text === "no-speech") { if (!v.got) h("I didn't hear anything. Tap me and try again.", "Kuch sunai nahi diya. Mujhe tap karke phir bolo.", "कुछ सुनाई नहीं दिया। मुझे टैप करके फिर बोलो।"); }
    else if (text === "network") h("Speech recognition needs internet (or an offline language pack in Google settings).", "Bolne ko samajhne ke liye internet chahiye (ya Google settings me offline language pack).", "बोली समझने के लिए इंटरनेट चाहिए।");
    else if (text === "unavailable") h("This phone has no speech recognition service. Install/enable the Google app.", "Is phone me speech recognition nahi hai. Google app install/enable karo.", "इस फ़ोन में स्पीच रिकग्निशन नहीं है। Google ऐप चालू करो।");
    else if (text === "busy") h("Mic is busy, try again in a moment.", "Mic busy hai, thodi der baad try karo.", "माइक व्यस्त है, थोड़ी देर बाद फिर कोशिश करो।");
    else if (text !== "aborted") toast("Mic: " + text);
  }
};

/* ------------------------------------------------------------------ local brain: works with no internet */
const NUMW = { ek: 1, one: 1, do: 2, two: 2, teen: 3, three: 3, char: 4, chaar: 4, four: 4, paanch: 5, panch: 5, five: 5, chhe: 6, che: 6, six: 6, saat: 7, seven: 7, aath: 8, eight: 8, nau: 9, nine: 9, das: 10, ten: 10, pandrah: 15, fifteen: 15, bees: 20, twenty: 20, tees: 30, thirty: 30, chalis: 40, pachas: 50, fifty: 50, saath: 60, आधा: 0.5, half: 0.5, aadha: 0.5, डेढ़: 1.5, dedh: 1.5 };
function normalize(t) {
  return t.toLowerCase().replace(/[०-९]/g, (d) => "०१२३४५६७८९".indexOf(d)).replace(/[^\p{L}\p{M}\p{N}+\-*/().:% ]+/gu, " ").replace(/\s+/g, " ").trim();
}
const has = (n, ...ws) => ws.some((w) => (/[ऀ-ॿ]/.test(w) ? n.includes(w) : new RegExp("(^| )" + w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "( |$)").test(n)));
const APPS = [
  { k: ["youtube", "यूट्यूब", "yt"], url: "https://www.youtube.com", name: "YouTube" },
  { k: ["whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "wa"], url: "https://wa.me/", name: "WhatsApp" },
  { k: ["instagram", "insta", "इंस्टाग्राम"], url: "https://www.instagram.com", name: "Instagram" },
  { k: ["facebook", "fb", "फेसबुक"], url: "https://m.facebook.com", name: "Facebook" },
  { k: ["maps", "map", "google maps", "नक्शा", "मैप"], url: "https://maps.google.com", name: "Maps" },
  { k: ["gmail", "mail", "email", "जीमेल"], url: "https://mail.google.com", name: "Gmail" },
  { k: ["google", "गूगल", "chrome"], url: "https://www.google.com", name: "Google" },
  { k: ["twitter", "x"], url: "https://x.com", name: "X" },
  { k: ["spotify", "स्पॉटिफाई"], url: "https://open.spotify.com", name: "Spotify" },
  { k: ["amazon", "अमेज़न"], url: "https://www.amazon.in", name: "Amazon" },
  { k: ["flipkart", "फ्लिपकार्ट"], url: "https://www.flipkart.com", name: "Flipkart" },
  { k: ["telegram", "टेलीग्राम"], url: "https://web.telegram.org", name: "Telegram" },
];
function parseDelay(n) {
  const m = n.match(/(\d+(?:\.\d+)?|[a-zA-Zऀ-ॿ]+)\s*(second|sec|seconds|सेकंड|minute|minutes|min|मिनट|ghante|ghanta|ghantey|hour|hours|hr|घंटे|घंटा)/);
  if (!m) return null;
  let v = parseFloat(m[1]); if (isNaN(v)) v = NUMW[m[1]]; if (!v) return null;
  const u = m[2]; return v * (/^(sec|second|सेकंड)/.test(u) ? 1 : /^(min|minute|मिनट)/.test(u) ? 60 : 3600) * 1000;
}
function parseClock(n) {
  const m = n.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm|baje|bje|बजे)\b|(\d{1,2}):(\d{2})\b/) || n.match(/(\d{1,2})(?::(\d{2}))?\s*(बजे)/);
  if (!m) return null;
  let h = parseInt(m[1] || m[4], 10), mi = parseInt(m[2] || m[5] || "0", 10); const mark = (m[3] || "").toLowerCase();
  if (h > 23 || mi > 59) return null;
  const morning = has(n, "subah", "savere", "morning", "सुबह", "सवेरे"), noon = has(n, "dopahar", "afternoon", "दोपहर"), eve = has(n, "shaam", "evening", "शाम"), night = has(n, "raat", "night", "रात");
  let fixed = true;
  if (mark === "pm" || eve || noon) { if (h < 12) h += 12; }
  else if (mark === "am" || morning) { if (h === 12) h = 0; }
  else if (night) { if (h === 12) h = 0; else if (h >= 6) h += 12; }
  else fixed = h > 12;                                     // plain "7 baje": pick whichever is next
  const now = new Date(), t = new Date(now); t.setHours(h, mi, 0, 0);
  const tomorrow = has(n, "kal", "tomorrow", "कल");
  if (tomorrow) t.setDate(t.getDate() + 1);
  else if (t <= now) { if (!fixed && h < 12 && new Date(t.getTime() + 12 * 3600e3) > now) t.setHours(h + 12); else t.setDate(t.getDate() + 1); }
  return t.getTime() - Date.now();
}
function reminderText(raw) {
  raw = raw.replace(/(\d{1,2})(?::(\d{2}))?\s*(am|pm|baje|bje|बजे)|\d{1,2}:\d{2}/gi, " ").replace(/\b(subah|savere|morning|dopahar|afternoon|shaam|evening|raat|night|kal|tomorrow|aaj|today|at|wake|jagana|utha(?:na)?)\b/gi, " ").replace(/(सुबह|सवेरे|दोपहर|शाम|रात|कल|आज|जगाना)/g, " ");
  return raw.replace(/\d+(?:\.\d+)?\s*(seconds?|sec|minutes?|min|hours?|hr|ghante|ghanta|घंटे|मिनट|सेकंड)/gi, "")
    .replace(/\b(remind|reminder|me|set|a|timer|in|after|baad|bad|mujhe|ko|yaad|dilana|dilao|dila|karna|lagao|laga|laga do|ke|ki|to|about|please|plz|alarm|rimainder)\b/gi, " ")
    .replace(/(याद|दिलाना|दिलाओ|बाद|मुझे|को|के|की|रिमाइंडर|लगाओ|टाइमर)/g, " ").replace(/\s+/g, " ").trim();
}
const Reminders = {
  list: jget("haa_rem", []), timers: {},
  add(ms, text) { const r = { id: Date.now() + "" + Math.floor(Math.random() * 99), at: Date.now() + ms, text: text || "" }; this.list.push(r); jset("haa_rem", this.list); this.arm(r); return r; },
  arm(r) {
    if (NATIVE) { try { Native.scheduleReminder(r.id, r.at, r.text || ""); } catch (e) {} return; }    // Android alarm: rings even when the app is closed
    const ms = Math.max(0, r.at - Date.now()); this.timers[r.id] = setTimeout(() => this.fire(r), Math.min(ms, 2147000000));
  },
  clearAll() { Object.values(this.timers).forEach(clearTimeout); this.timers = {}; if (NATIVE) { try { this.list.forEach((r) => Native.cancelReminder(r.id)); } catch (e) {} } this.list = []; jset("haa_rem", []); },
  async fire(r) {
    this.list = this.list.filter((x) => x.id !== r.id); jset("haa_rem", this.list);
    const l = lastLang, body = r.text ? tx(T3(`Reminder: ${r.text}`, `Yaad dilana tha: ${r.text}`, `याद दिलाना था: ${r.text}`), l) : tx(T3("Time's up!", "Time ho gaya!", "समय हो गया!"), l);
    deliver(body, "surprised", true, l);
    try { if (Notification.permission === "granted") { const reg = await navigator.serviceWorker.getRegistration(); const o = { body, icon: "icons/icon-192.png", vibrate: [200, 100, 200] }; reg ? reg.showNotification(nm(), o) : new Notification(nm(), o); } } catch (e) {}
    if (!NATIVE) { try { navigator.vibrate && navigator.vibrate([200, 100, 200]); } catch (e) {} }
  },
  init() {
    const now = Date.now(), missed = this.list.filter((r) => r.at <= now - 60000 && r.at > now - 36 * 3600e3);
    this.list = this.list.filter((r) => r.at > now - 60000); if (!NATIVE) this.list.forEach((r) => this.arm(r)); jset("haa_rem", this.list);
    return missed;
  },
};
function fmtDur(ms, l) { const s = Math.round(ms / 1000); if (s < 90) return `${s} ${l === "hi" ? "सेकंड" : "second"}`; const m = Math.round(s / 60); if (m < 90) return `${m} ${l === "hi" ? "मिनट" : "minute"}`; return `${(m / 60).toFixed(1).replace(".0", "")} ${l === "hi" ? "घंटे" : l === "hinglish" ? "ghante" : "hours"}`; }
function openUrl(url) { if (NATIVE) { nat("url", url); return; } const a = document.createElement("a"); a.href = url; a.target = "_blank"; a.rel = "noopener"; document.body.appendChild(a); a.click(); a.remove(); }

const WX = [
  [[0], T3("clear sky", "saaf aasman", "साफ़ आसमान")], [[1, 2, 3], T3("partly cloudy", "thode badal", "थोड़े बादल")], [[45, 48], T3("foggy", "kohra", "कोहरा")],
  [[51, 53, 55, 56, 57], T3("drizzle", "halki bundabandi", "हल्की बूंदाबांदी")], [[61, 63, 65, 66, 67, 80, 81, 82], T3("rain", "barish", "बारिश")],
  [[71, 73, 75, 77, 85, 86], T3("snow", "barf", "बर्फ़")], [[95, 96, 99], T3("thunderstorm", "toofan", "तूफ़ान")],
];
async function weatherText(l, city) {
  if (!navigator.onLine) throw new Error("offline");
  let la, lo, place = "";
  if (city) {                                           // "weather in Mumbai" / "Delhi ka mausam"
    const g = await (await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&format=json`)).json();
    if (!g.results || !g.results[0]) return tx(T3(`I couldn't find a place called ${city}.`, `${city} naam ki jagah nahi mili.`, `${city} नाम की जगह नहीं मिली।`), l);
    la = g.results[0].latitude; lo = g.results[0].longitude; place = g.results[0].name;
  } else {
    const pos = await new Promise((res, rej) => navigator.geolocation ? navigator.geolocation.getCurrentPosition(res, rej, { timeout: 12000, maximumAge: 600000 }) : rej(new Error("nogeo")));
    la = pos.coords.latitude; lo = pos.coords.longitude;
  }
  const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${la.toFixed(2)}&longitude=${lo.toFixed(2)}&current=temperature_2m,weather_code,wind_speed_10m&timezone=auto`);
  if (!r.ok) throw new Error("http"); const c = (await r.json()).current;
  const w = WX.find(([codes]) => codes.includes(c.weather_code)); const desc = w ? tx(w[1], l) : "";
  const t = Math.round(c.temperature_2m);
  const at = place ? tx(T3(` in ${place}`, ` ${place} me`, ` ${place} में`), l) : "";
  return tx(T3(`It's ${t}°C${at} with ${desc || "no special weather"} right now.`, `Abhi${at} ${t}°C hai, ${desc || "mausam normal hai"}.`, `अभी${at} ${t}°C है, ${desc || "मौसम सामान्य है"}।`), l);
}
async function batteryText(l) {
  let b;
  if (NATIVE) { const m = nat("battery").match(/^(\d+)\|([01])$/); if (!m) throw new Error("nobat"); b = { level: m[1] / 100, charging: m[2] === "1" }; }
  else { if (!navigator.getBattery) throw new Error("nobat"); b = await navigator.getBattery(); }
  const p = Math.round(b.level * 100);
  return tx(T3(`Battery is at ${p}%${b.charging ? " and charging" : ""}.`, `Battery ${p}% hai${b.charging ? " aur charge ho rahi hai" : ""}.`, `बैटरी ${p}% है${b.charging ? " और चार्ज हो रही है" : ""}।`), l);
}

/* ------------------------------------------------------------------ premium: screen control, agent, files */
const A11Y_MSG = T3(
  "I need Screen control to do that. Open ⚙ → AI & App → Android and tap “Screen control”, then switch Anime Buddy on.",
  "Iske liye Screen control chalu karna hoga. ⚙ → AI & App → Android me “Screen control” dabao aur Anime Buddy ko ON karo.",
  "इसके लिए स्क्रीन कंट्रोल चालू करना होगा। ⚙ → AI & App → Android में “Screen control” दबाओ और Anime Buddy को ON करो।");
async function geminiOnce(parts, o) {                  // one-shot call on the first working provider (name kept for older code)
  o = o || {};
  if (!hasKey()) throw new Error("nokey"); if (!navigator.onLine) throw new Error("offline");
  let last;
  for (const p of provUsable()) {
    try {
      if (p === "gemini") return await geminiOnceG(parts, o);
      if (o.tools) continue;                              // link reading needs Gemini's url_context
      const out = (await otherOnce(p, o.system || "You are a helpful assistant.", [], parts, o)).trim(); if (!out) throw new Error("empty"); return out;
    } catch (e) { last = e; provDown[p] = Date.now() + 60000; }
  }
  throw last || new Error("nokey");
}
async function geminiOnceG(parts, o) {
  const body = { contents: [{ role: "user", parts }], generationConfig: { temperature: o.temp == null ? 0.4 : o.temp, maxOutputTokens: o.max || 700 } };
  if (o.system) body.systemInstruction = { parts: [{ text: o.system }] };
  if (o.json) body.generationConfig.responseMimeType = "application/json";
  if (o.tools) body.tools = o.tools;
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cfg.model || DEFAULTS.model)}:generateContent?key=${encodeURIComponent(cfg.key)}`;
  const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 45000);
  try {
    let r;
    for (let a = 0; a < 2; a++) { r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctl.signal }); if ((r.status === 429 || r.status >= 500) && !a) { await sleep(1200); continue; } break; }
    if (!r.ok) throw new Error(r.status === 400 || r.status === 403 ? "key" : "http " + r.status);
    const j = await r.json(), p = j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts;
    const out = (p || []).map((x) => x.text || "").join("").trim(); if (!out) throw new Error("empty"); return out;
  } finally { clearTimeout(to); }
}
const aiErr = (e, l) => tx(String(e && e.message) === "nokey" ? NOKEY_MSG : String(e && e.message) === "offline" ? OFFLINE_MSG : T3("The AI couldn't answer right now. Check your key / internet.", "AI abhi jawab nahi de paayi. Key / internet check karo.", "AI अभी जवाब नहीं दे पाई। की / इंटरनेट देखो।"), l);
function deliverLong(t, l) {
  const sh = t.length > 420 ? t.slice(0, Math.max(200, t.lastIndexOf(" ", 400))) + "… (poora jawab chat log me hai 📜)" : t;
  deliver(sh, "happy", false, l); if (chatLog.length) { chatLog[chatLog.length - 1].text = t.slice(0, 1500); jset("haa_log", chatLog); }
}
async function screenAnswer(q, l) {
  const t = nat("screen");
  if (t === "off") return tx(A11Y_MSG, l);
  if (t === "empty" || t === "err") return tx(T3("I couldn't read anything on this screen.", "Is screen par kuch padh nahi paayi.", "इस स्क्रीन पर कुछ पढ़ नहीं पाई।"), l);
  try { return await geminiOnce([{ text: `This is the text currently visible on the user's phone screen:\n"""\n${t}\n"""\nUser request: ${q}\nAnswer briefly, in the same language/style the user used (Hinglish is fine).` }], { max: 600, system: "You are Aiko, a friendly voice assistant. Keep answers short and speakable." }); }
  catch (e) { return aiErr(e, l); }
}
const Agent = {
  running: false, stop: false,
  async run(goal, l) {
    if (this.running) return tx(T3("I'm already working on something. Tap me to stop.", "Main pehle se ek kaam kar rahi hoon. Rokne ke liye mujhe tap karo.", "मैं पहले से एक काम कर रही हूँ। रोकने के लिए मुझे टैप करो।"), l);
    if (nat("a11y") !== "on") return tx(A11Y_MSG, l);
    if (!hasKey()) return tx(NOKEY_MSG, l);
    this.running = true; this.stop = false;
    const sys = `You operate an Android phone for the user through an accessibility API. Each turn you get the GOAL, the steps done so far and the text currently on screen ([tap]=clickable, [input]=text field). Reply with ONLY JSON: {"say":"<very short status in the user's language>","action":"open_app|open_url|click|type|enter|scroll_down|scroll_up|back|home|wait|done","arg":"<app name | url | exact on-screen text | text to type>"}. One action per turn. For click use the exact text shown on screen. Use "done" when the goal is complete or can't be completed and put the final answer or reason in "say". NEVER enter passwords, OTPs, card or bank details and never confirm a payment or send money: use "done" and tell the user to do that part themselves. Prefer open_url with a search URL (https://www.google.com/search?q=...) for web searches.`;
    const log = []; let final = null;
    try {
      if (!OVERLAY) { try { Native.goHome(); } catch (e) {} await sleep(900); }
      for (let i = 1; i <= 10 && !this.stop; i++) {
        const scr = nat("screen"), view = scr === "off" || scr === "err" ? "(unreadable)" : scr === "empty" ? "(empty)" : scr.slice(0, 3500);
        let j;
        try { j = JSON.parse(await geminiOnce([{ text: `GOAL: ${goal}\nSTEPS SO FAR:\n${log.join("\n") || "(none)"}\n\nSCREEN:\n${view}` }], { system: sys, json: true, max: 250, temp: 0.2 })); } catch (e) { final = aiErr(e, l); break; }
        const act = String(j.action || "").toLowerCase(), arg = String(j.arg == null ? "" : j.arg);
        if (j.say) say("🤖 " + j.say, 5000);
        if (act === "done") { final = j.say || "Ho gaya."; break; }
        let r = "ok";
        if (act === "open_app") r = nat("app", arg); else if (act === "open_url") r = nat("url", arg);
        else if (act === "click") r = nat("click", arg); else if (act === "type") r = nat("type", arg); else if (act === "enter") r = nat("enter");
        else if (act === "scroll_down") r = nat("scroll", "down"); else if (act === "scroll_up") r = nat("scroll", "up");
        else if (act === "back" || act === "home") r = nat("global", act); else if (act !== "wait") { final = "Mujhe ye step samajh nahi aaya."; break; }
        log.push(`${i}. ${act} ${arg} -> ${r}`);
        await sleep(act === "open_app" || act === "open_url" ? 2600 : 1500);
      }
      if (this.stop) final = tx(T3("Okay, stopped.", "Theek hai, ruk gayi.", "ठीक है, रुक गई।"), l);
      else if (final == null) final = tx(T3("I tried for 10 steps — that's my limit. Here's where I got to; you can continue.", "10 step try kar liye, meri limit yahi hai. Aage aap sambhal lo.", "10 स्टेप कोशिश कर ली, मेरी सीमा यही है। आगे आप संभालो।"), l);
    } finally { this.running = false; }
    return final;
  },
};
let fileCtx = null;
const blobB64 = (b) => new Promise((res, rej) => { const f = new FileReader(); f.onload = () => res(String(f.result).split(",")[1]); f.onerror = rej; f.readAsDataURL(b); });
async function askAboutBlob(blob, name, mime, q, l) {
  q = q || "Summarize this file and list the key points.";
  const isText = /^text\//.test(mime) || /(json|xml|csv|javascript|yaml|markdown)/.test(mime) || /\.(txt|md|csv|tsv|json|xml|html?|js|py|java|c|cpp|log|ya?ml|ini|srt)$/i.test(name);
  const sys = "You are Aiko, a helpful voice assistant. Answer in the same language as the question (Hinglish is fine). Be clear and concise.";
  let parts;
  if (isText) parts = [{ text: `File: ${name}\n"""\n${(await blob.text()).slice(0, 80000)}\n"""\n${q}` }];
  else if (/^image\//.test(mime) || mime === "application/pdf") { if (blob.size > 12e6) return tx(T3("That file is too big (limit 12 MB).", "File bahut badi hai (limit 12 MB).", "फ़ाइल बहुत बड़ी है (सीमा 12 MB)।"), l); parts = [{ inline_data: { mime_type: mime, data: await blobB64(blob) } }, { text: `${q}\n(File: ${name})` }]; }
  else return tx(T3("I can read text, PDF and image files. For Word/Excel, save it as PDF first.", "Main text, PDF aur image padh sakti hoon. Word/Excel ho to pehle PDF bana lo.", "मैं टेक्स्ट, PDF और इमेज पढ़ सकती हूँ। Word/Excel हो तो पहले PDF बना लो।"), l);
  try { return await geminiOnce(parts, { system: sys, max: 900 }); } catch (e) { return aiErr(e, l); }
}
async function takeFile(blob, name, mime, q) {
  const l = lastLang || "hinglish"; fileCtx = { blob, name, mime, at: Date.now() };
  say("📎 " + name, 4000); Pet.setEmotion("thinking", 15000);
  deliverLong(await askAboutBlob(blob, name, mime, q, l), l);
  if (!OVERLAY) openSheet("t-log");
}
window.__sharedPoll = async () => {                           // something was shared to us from another app
  let sh; try { sh = JSON.parse(Native.takeShared() || "null"); } catch (e) { sh = null; } if (!sh) return;
  const l = lastLang || "hinglish";
  try {
    if (sh.kind === "toobig") { deliver(tx(T3("That file is too big (limit 12 MB).", "File bahut badi hai (limit 12 MB).", "फ़ाइल बहुत बड़ी है।"), l), "sad", false, l); return; }
    if (sh.kind === "file") { const b = await (await fetch("__shared", { cache: "no-store" })).blob(); await takeFile(b, sh.name, sh.mime, sh.text || ""); return; }
    const text = String(sh.text || ""), url = (text.match(/https?:\/\/\S+/) || [])[0];
    say("📎 " + text.slice(0, 60), 3000); Pet.setEmotion("thinking", 15000);
    let out;
    try {
      if (url) { try { out = await geminiOnce([{ text: `Open this link and summarize it with the key points. Link: ${url}\nAnswer in Hinglish, short.` }], { tools: [{ url_context: {} }], max: 700 }); } catch (e) { if (["nokey", "offline"].includes(String(e.message))) throw e; out = tx(T3("I couldn't open that link myself. Open it and say “screen padho” and I'll read it.", "Ye link main khud nahi khol paayi. Use kholo aur “screen padho” bolo, main padh dungi.", "ये लिंक मैं खुद नहीं खोल पाई। इसे खोलो और “screen padho” बोलो।"), l); } }
      else out = await geminiOnce([{ text: `The user shared this text with you. Summarize it or answer it, in Hinglish, short:\n"""\n${text.slice(0, 20000)}\n"""` }], { max: 700 });
    } catch (e) { out = aiErr(e, l); }
    deliverLong(out, l); if (!OVERLAY) openSheet("t-log");
  } catch (e) { toast("Share nahi khul paaya"); }
};

/* ------------------------------------------------------------------ long-term memory (hashed vectors, all on this phone) */
const Mem = {
  D: 256, items: jget("haa_mem", []),
  vec(t) { const v = new Array(this.D).fill(0), w = normalize(t).split(" ").filter((x) => x.length > 1);
    w.concat(w.slice(1).map((x, i) => w[i] + "_" + x)).forEach((x) => { let h = 5381; for (let i = 0; i < x.length; i++) h = ((h * 33) ^ x.charCodeAt(i)) >>> 0; v[h % this.D] += 1; });
    const m = Math.sqrt(v.reduce((a, b) => a + b * b, 0)) || 1; return v.map((x) => +(x / m).toFixed(3)); },
  save() { while (this.items.length > 300) this.items.shift(); jset("haa_mem", this.items); },
  add(text, kind) { text = String(text).trim().slice(0, 240); if (!text || this.items.some((i) => i.t === text)) return; this.items.push({ t: text, k: kind || "fact", ts: Date.now(), v: this.vec(text) }); this.save(); },
  search(q, n) { const qv = this.vec(q); return this.items.map((i) => ({ i, s: i.v.reduce((a, b, k) => a + b * qv[k], 0) })).filter((x) => x.s > 0.2).sort((a, b) => b.s - a.s).slice(0, n || 3).map((x) => x.i.t); },
  context(q) { if (!this.items.length) return ""; const facts = this.items.filter((i) => i.k === "fact").slice(-6).map((i) => i.t), rel = this.search(q, 3);
    return "What you remember about the user (use naturally, never list it): " + Array.from(new Set(facts.concat(rel))).join("; ") + ". "; },
  learn(text) {
    if (cfg.memOn === false) return; let m;
    if ((m = text.match(/\b(?:my name is|mera naam|mera name)\s+([A-Za-zऀ-ॿ]{2,20})/i))) this.add("User's name is " + m[1]);
    if ((m = text.match(/\bmujhe (.{2,40}?) (?:pasand(?! nahi)|achha lagta|accha lagta)/i)) || (m = text.match(/\bi (?:really )?(?:like|love) ([\w ]{2,30})/i))) this.add("User likes " + m[1]);
    if ((m = text.match(/\b(?:i live in|main (.{2,25}?) (?:me|mein) rehta|i work as|i am a|main ek (\w+) hoon)\b ?([\w ]{0,25})/i))) this.add("User said: " + m[0].trim());
    if ((m = text.match(/\b(?:remember that|yaad rakhna ki|yaad rakhna|remember)\s+(.{3,200})/i))) this.add(m[1]);
  },
  handle(raw, l) {
    const n = normalize(raw);
    if (/^(?:forget everything|sab bhool jao|sab kuch bhool jao|memory clear|memory delete)/.test(n)) { this.items = []; this.save(); return tx(T3("Okay, I've forgotten everything about you.", "Theek hai, maine tumhare baare me sab bhula diya.", "ठीक है, मैंने सब भुला दिया।"), l); }
    if (/(what do you remember|kya yaad hai|mere baare me kya|what do you know about me)/.test(n)) { const f = this.items.slice(-6).map((i) => i.t); return f.length ? f.join("; ") : tx(T3("I don't know much about you yet. Tell me!", "Abhi tumhare baare me zyada nahi pata. Batao!", "अभी ज़्यादा नहीं पता। बताओ!"), l); }
    return null;
  },
};

/* ------------------------------------------------------------------ soul profile: learns how the user talks and mirrors it (stored only on this phone) */
const Soul = {
  d: Object.assign({ name: "", language: "auto", likes: [], dislikes: [], projects: [], style: { avg: 0, emoji: false, hing: 0 }, note: "", n: 0 }, jget("haa_soul", {})),
  recent: jget("haa_soul_recent", []),
  save() { jset("haa_soul", this.d); jset("haa_soul_recent", this.recent.slice(-20)); },
  push(k, v) { v = String(v).trim().replace(/[ .,!?]+$/, "").slice(0, 60); if (v && !this.d[k].some((x) => x.toLowerCase() === v.toLowerCase())) this.d[k] = this.d[k].concat(v).slice(-12); },
  observe(text) {
    if (cfg.memOn === false) return; let m;
    this.recent = this.recent.concat(text).slice(-30); this.d.n++;
    if ((m = text.match(/\b(?:my name is|mera naam|mera name)\s+([A-Za-zऀ-ॿ]{2,20})/i))) this.d.name = m[1];
    if ((m = text.match(/\bmujhe (.{2,40}?) (?:pasand(?! nahi)|achha lagta|accha lagta)/i)) || (m = text.match(/\bi (?:really )?(?:like|love) ([\w ]{2,30})/i))) this.push("likes", m[1]);
    if ((m = text.match(/\bmujhe (.{2,40}?) (?:pasand nahi|nahi pasand)/i)) || (m = text.match(/\bi (?:hate|dislike) ([\w ]{2,30})/i))) this.push("dislikes", m[1]);
    if ((m = text.match(/\b(?:i am working on|i'm working on|mera project)\s+(.{3,80})/i))) this.push("projects", m[1]);
    if (this.d.n % 10 === 0) setTimeout(() => this.reflect(), 1500);   // reflection runs in the background
    this.save();
  },
  async reflect() {
    try {
      const msgs = this.recent.slice(-20), words = msgs.join(" ").toLowerCase().match(/[\w']+/g) || [];
      const H = new Set("hai hain kya nahi nhi kr kro karo mujhe mera meri tum aap bhai yaar acha accha theek kaise kaha bolo batao dikhao khol abhi ek aur bhi toh".split(" "));
      const hing = words.filter((w) => H.has(w)).length / Math.max(1, words.length);
      this.d.style = { avg: Math.round(words.length / Math.max(1, msgs.length)), emoji: msgs.some((x) => /[\u{1F300}-\u{1FAFF}☀-➿]/u.test(x)), hing: +hing.toFixed(2) };
      if (hing > 0.12) this.d.language = "hinglish";
      if (navigator.onLine && hasKey()) { try { const n = await geminiOnce([{ text: "Describe in ONE short sentence how this user talks (tone, length, language mix) so an assistant can mirror it. Messages:\n" + msgs.slice(-12).join("\n") }], { max: 80, temp: 0.3 }); if (n) this.d.note = n.trim().slice(0, 200); } catch (e) {} }
      this.save();
    } catch (e) {}
  },
  prompt() {
    const d = this.d, b = [];
    if (d.name) b.push(`The user's name is ${d.name}.`);
    if (d.likes.length) b.push("They like: " + d.likes.slice(-5).join(", ") + ".");
    if (d.dislikes.length) b.push("They dislike: " + d.dislikes.slice(-4).join(", ") + ".");
    if (d.projects.length) b.push("Ongoing projects: " + d.projects.slice(-3).join("; ") + ".");
    if (d.style.avg) b.push(`They write about ${d.style.avg} words per message, so keep replies ${d.style.avg < 6 ? "very short" : d.style.avg < 15 ? "short" : "a bit fuller"}.`);
    if (d.style.emoji) b.push("They use emojis, so a light playful tone suits them.");
    if (d.note) b.push("Mirror their style: " + d.note);
    return b.length ? b.join(" ") + " " : "";
  },
  forget() { this.d = { name: "", language: "auto", likes: [], dislikes: [], projects: [], style: { avg: 0, emoji: false, hing: 0 }, note: "", n: 0 }; this.recent = []; this.save(); },
};

/* ------------------------------------------------------------------ my-files knowledge base (offline search over notes you add; stays on the phone) */
const KB = {
  db: null,
  open() { return this.db ? Promise.resolve(this.db) : new Promise((res, rej) => { const r = indexedDB.open("haa_kb", 1); r.onupgradeneeded = () => r.result.createObjectStore("c", { autoIncrement: true }); r.onsuccess = () => res((this.db = r.result)); r.onerror = () => rej(r.error); }); },
  async all() { const db = await this.open(); return new Promise((res) => { const q = db.transaction("c").objectStore("c").getAll(); q.onsuccess = () => res(q.result || []); q.onerror = () => res([]); }); },
  chunks(text) { const out = []; let cur = ""; String(text).replace(/<[^>]+>/g, " ").split(/\n{2,}|(?<=[.!?।])\s+/).forEach((p) => { p = p.trim(); if (!p) return; if (cur.length + p.length > 700 && cur) { out.push(cur); cur = ""; } cur += (cur ? " " : "") + p; }); if (cur) out.push(cur); return out.map((c) => c.slice(0, 1500)); },
  async add(file) {
    if (file.size > 3 * 1024 * 1024) return 0;
    const text = await file.text(), db = await this.open(), ch = this.chunks(text);
    await new Promise((res) => { const tx = db.transaction("c", "readwrite"), st = tx.objectStore("c"); ch.forEach((c) => st.add({ f: file.name, t: c, v: Mem.vec(c) })); tx.oncomplete = res; tx.onerror = res; });
    return ch.length;
  },
  async search(q, k) { const qv = Mem.vec(q); return (await this.all()).map((x) => ({ x, s: x.v.reduce((a, b, i) => a + b * qv[i], 0) })).filter((r) => r.s > 0.12).sort((a, b) => b.s - a.s).slice(0, k || 4).map((r) => r.x); },
  async count() { return (await this.all()).length; },
  async clear() { const db = await this.open(); return new Promise((res) => { const tx = db.transaction("c", "readwrite"); tx.objectStore("c").clear(); tx.oncomplete = res; }); },
  async context(q) { const h = await this.search(q); return h.length ? "From the user's own files:\n" + h.map((x) => `- (${x.f}) ${x.t.slice(0, 400)}`).join("\n") + "\nQuestion: " + q : ""; },
  parseAsk(raw) { const m = raw.match(/^\s*(?:from my (?:docs|files|notes)|(?:meri )?(?:docs|files|notes) (?:me|mein|se))\s*[:,\-]?\s*(.{3,200})$/i); return m ? m[1].trim() : null; },
};
const WEB_Q = /\b(?:search (?:the )?(?:web|internet|online) for|web search|google (?:karke|par) (?:batao|dhundo)|internet (?:par|se) (?:dhundo|batao|search)|latest news|aaj ki (?:khabar|news)|news (?:about|on))\b/i;

/* ------------------------------------------------------------------ Wi-Fi bridge to the PC assistant (same network; needs the installed Android app) */
const PCLink = {
  get d() { return jget("haa_pc", null); }, timer: null,
  async call(path, body) {
    const d = this.d; if (!d) throw new Error("nolink");
    const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 5000);
    try {
      const r = await fetch(`http://${d.ip}:8765${path}`, { method: body ? "POST" : "GET", headers: { "X-Token": d.token, "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined, signal: ctl.signal });
      if (r.status === 401) throw new Error("code");
      if (!r.ok) throw new Error("http");
      return await r.json();
    } finally { clearTimeout(to); }
  },
  async link(ip, token) {
    jset("haa_pc", { ip, token });
    try { await this.call("/ping"); } catch (e) { jset("haa_pc", null); return String(e.message) === "code" ? "Code galat hai. PC par 'phone jodo' dobara bolo." : "PC nahi mila. Dono ek hi Wi-Fi par hain? PC ka firewall allow kiya?"; }
    await this.sync(); this.start(); return "PC se jud gaya! ✅ Ab 'pc par open notepad' bol sakte ho.";
  },
  async sync() {
    try {
      const j = await this.call("/sync");
      (j.facts || []).forEach((f) => Mem.add(f)); const s = j.soul || {};
      if (s.name && !Soul.d.name) Soul.d.name = s.name; ["likes", "dislikes", "projects"].forEach((k) => (s[k] || []).forEach((v) => Soul.push(k, v))); Soul.save();
      await this.call("/sync", { facts: Mem.items.filter((i) => i.k === "fact").slice(-20).map((i) => i.t), soul: { name: Soul.d.name, likes: Soul.d.likes, dislikes: Soul.d.dislikes, projects: Soul.d.projects } });
    } catch (e) {}
  },
  start() {
    if (this.timer || !this.d) return;
    let n = 0;
    this.timer = setInterval(async () => {
      if (!this.d || !navigator.onLine) return;
      try {
        const j = await this.call("/poll");
        for (const c of j.cmds || []) { const lc = localCommand(c, "hinglish"); if (lc) { deliver(lc.text, lc.emotion, false, "hinglish"); if (lc.run) setTimeout(lc.run, 500); } }
        if (++n % 120 === 0) this.sync();                  // about every 10 minutes
      } catch (e) {}
    }, 5000);
  },
  unlink() { jset("haa_pc", null); clearInterval(this.timer); this.timer = null; },
  async handle(raw) {
    let m = raw.match(/^\s*pc se jodo\s+(\d{1,3}(?:\.\d{1,3}){3})\s+([0-9a-f]{6})\s*$/i);
    if (m) return this.link(m[1], m[2].toLowerCase());
    if (/^\s*pc (?:se )?(?:alag|disconnect|band)/i.test(raw)) { this.unlink(); return "PC se connection hata diya."; }
    m = raw.match(/^\s*pc (?:par|pe|se kaho)\s+(.{2,200})$/i);
    if (m) { if (!this.d) return "Pehle PC se jodo: PC par 'phone jodo' bolo."; try { return (await this.call("/cmd", { text: m[1] })).reply; } catch (e) { return "PC tak baat nahi pahunchi. Wi-Fi aur code check karo."; } }
    return null;
  },
};
PCLink.start();

/* ------------------------------------------------------------------ routines ("work mode" = several steps in one command) */
const ROUTINES = {
  "work mode": { say: ["Work Mode on! Focus for 25 minutes.", "Work Mode shuru! 25 minute focus."], steps: [{ focus: 25 }, { url: "https://mail.google.com" }, { url: "https://calendar.google.com" }] },
  "study mode": { say: ["Study Mode on! Good luck!", "Study Mode shuru! All the best!"], steps: [{ focus: 40 }, { url: "https://www.youtube.com/results?search_query=lofi+study+music" }] },
  "good night": { say: ["Good night! Sleep well.", "Good night! Achhi neend lo."], steps: [{ focus: 480 }] },
  "relax mode": { say: ["Relax time! Some music for you.", "Relax time! Thoda music sunao."], steps: [{ url: "https://www.youtube.com/results?search_query=relaxing+music" }] },
};
const Routines = {
  match(n) { return Object.keys(ROUTINES).find((k) => n.includes(k) || n.includes(k.replace(" mode", " mod"))) || (/(kaam shuru|work shuru)/.test(n) ? "work mode" : /(padhai shuru|study shuru)/.test(n) ? "study mode" : /^(?:gn|shubh ratri)$/.test(n) ? "good night" : null); },
  run(k) { const r = ROUTINES[k]; r.steps.forEach((st, i) => setTimeout(() => { if (st.focus) Brain.focusUntil = Date.now() + st.focus * 60000; if (st.url) openUrl(st.url); }, 800 + i * 1500)); },
};

/* ------------------------------------------------------------------ plugins: small JS files, each runs in its own locked-down Worker (no network, no page access, 5 s limit) */
const Plugins = {
  list: jget("haa_plugins", []), pending: null,
  save() { jset("haa_plugins", this.list); },
  // Everything a plugin does happens inside this Worker: no network, no storage, no page access, 5 s limit.
  worker(code, input, probe) {
    return new Promise((res) => {
      const lock = "for (const k of ['fetch','XMLHttpRequest','WebSocket','importScripts','EventSource','indexedDB','caches','Worker','SharedWorker','BroadcastChannel']) { try { self[k] = undefined; } catch (e) {} }";
      const src = lock + `
        let P = null; try { P = (new Function(${JSON.stringify(code)}))(); } catch (e) {}
        onmessage = (ev) => {
          try {
            if (ev.data.probe) { postMessage({ meta: P && typeof P.run === "function" ? { name: String(P.name || ""), triggers: Array.isArray(P.triggers) ? P.triggers.map(String) : [] } : null }); return; }
            Promise.resolve(P.run(ev.data.text)).then((r) => postMessage({ ok: String(r) }), (e) => postMessage({ err: String(e) }));
          } catch (e) { postMessage({ err: String(e) }); }
        };`;
      let w, url; try { url = URL.createObjectURL(new Blob([src], { type: "text/javascript" })); w = new Worker(url); } catch (e) { return res({ err: "no worker" }); }
      const end = (v) => { clearTimeout(to); try { w.terminate(); URL.revokeObjectURL(url); } catch (e) {} res(v); };
      const to = setTimeout(() => end({ err: "timeout" }), 5000);
      w.onmessage = (ev) => end(ev.data); w.onerror = () => end({ err: "error" });
      w.postMessage(probe ? { probe: true } : { text: input });
    });
  },
  async exec(pl, text) {
    const r = await this.worker(pl.code, text);
    if (r.err) { pl.fails = (pl.fails || 0) + 1; if (pl.fails >= 3) pl.off = true; this.save(); return null; }
    return r.ok != null ? r.ok : null;
  },
  async tryHandle(raw) {
    const n = normalize(raw);
    for (const pl of this.list) if (!pl.off && (pl.triggers || []).some((t) => n.includes(normalize(t)))) { const out = await this.exec(pl, raw); if (out) return out; }
    return null;
  },
  // read name/triggers by running the code in the Worker (never on the page)
  async inspect(code) {
    const r = await this.worker(code, "", true);
    return r && r.meta && r.meta.name && r.meta.triggers.length ? r.meta : null;
  },
  async stage(code, url) {
    if (code.length > 30000) return "Plugin bahut bada hai.";
    const meta = await this.inspect(code);
    if (!meta) return "Ye valid plugin nahi hai (name, triggers, run chahiye).";
    this.pending = { name: meta.name.slice(0, 40), triggers: meta.triggers.slice(0, 8), code, url: url || "", ts: Date.now() };
    return `Plugin “${this.pending.name}” mila (triggers: ${this.pending.triggers.join(", ")}). Ye bina internet/page access ke sandbox me chalega. Install karun? "yes" ya "no" bolo.`;
  },
  async install(url) {
    if (!/^https:\/\/(raw\.githubusercontent\.com|github\.com|gist\.githubusercontent\.com)\//i.test(url)) return "Sirf GitHub ke link se plugin install hota hai.";
    url = url.replace(/^https:\/\/github\.com\/([^/]+\/[^/]+)\/blob\//i, "https://raw.githubusercontent.com/$1/");
    return this.stage(await (await fetch(url, { cache: "no-store" })).text(), url);
  },
  // AI-written skills: the model drafts the plugin, a static check + a real test run in the Worker must pass, and the user must say yes.
  async draft(desc) {
    let raw;
    try {
      raw = await geminiOnce([{ text: "Write ONE small JavaScript plugin body. It must `return { name: 'Short name', triggers: ['lowercase words that trigger it'], run: (text) => 'short reply string' };`. " +
        "No network, no DOM, no storage, no imports, no eval. Pure computation only. Output ONLY the code, no explanation, no markdown fences.\nTask: " + desc }], { max: 700, temp: 0.2 });
    } catch (e) { return "Abhi skill nahi bana paayi (AI available nahi hai)."; }
    const code = String(raw).replace(/^```(?:javascript|js)?\s*|\s*```$/gim, "").trim();
    if (/\b(fetch|XMLHttpRequest|WebSocket|importScripts|eval|document|window|localStorage|indexedDB|import\s*\(|globalThis|constructor|__proto__)\b/.test(code)) return "Skill safe nahi thi, isliye install nahi ki.";
    const meta = await this.inspect(code);
    if (!meta) return "Skill valid nahi thi, isliye install nahi ki.";
    const t = await this.worker(code, meta.triggers[0]);
    if (t.err) return "Skill test me fail ho gayi, isliye install nahi ki.";
    this.pending = { name: meta.name.slice(0, 40), triggers: meta.triggers.slice(0, 8), code, url: "", ts: Date.now() };
    return `Skill “${this.pending.name}” taiyaar hai, safe test pass. Install karun? "yes" ya "no" bolo.`;
  },
  handle(raw) {
    const n = normalize(raw), m = raw.match(/install plugin\s+(https:\/\/\S+)/i), sk = raw.match(/^\s*(?:skill banao|make a skill|create a skill)\s*[:\-]?\s*(.{4,200})$/i);
    if (sk) return this.draft(sk[1]).catch(() => "Skill nahi ban paayi.");
    if (m) return this.install(m[1]).catch(() => "Plugin download nahi ho paya.");
    if (this.pending && /^(yes|haan|han|ha|ok|install)$/.test(n)) { const p = this.pending; this.pending = null; this.list = this.list.filter((x) => x.name !== p.name); this.list.push(p); this.save(); renderBrainExtras(); return `Plugin “${p.name}” install ho gaya! ✅`; }
    if (this.pending && /^(no|nahi|nhi|cancel)$/.test(n)) { this.pending = null; return "Theek hai, install nahi kiya."; }
    if (/(update plugins|plugins update)/.test(n)) return (async () => { let c = 0; for (const p of this.list) { if (!p.url) continue; try { const code = await (await fetch(p.url, { cache: "no-store" })).text(); if (code !== p.code && (await this.inspect(code))) { p.code = code; p.fails = 0; p.off = false; c++; } } catch (e) {} } this.save(); return c ? c + " plugin update ho gaye." : "Sab plugins already latest hain."; })();
    if (/(plugins dikhao|show plugins|my plugins)/.test(n)) return this.list.length ? this.list.map((p) => p.name + (p.off ? " (off)" : "")).join(", ") : "Abhi koi plugin nahi hai.";
    return null;
  },
};
function renderBrainExtras() {
  const box = $("#brainx"); if (!box) return; box.innerHTML = "";
  const mem = document.createElement("p"); mem.className = "hint"; mem.textContent = `🧠 Memory: ${Mem.items.length} cheezein yaad hain.`; box.appendChild(mem);
  const clr = document.createElement("button"); clr.type = "button"; clr.textContent = "🗑 Memory saaf karo"; clr.onclick = () => { Mem.items = []; Mem.save(); Soul.forget(); renderBrainExtras(); }; box.appendChild(clr);
  const h = document.createElement("p"); h.className = "hint"; h.textContent = Plugins.list.length ? "🧩 Plugins:" : '🧩 Koi plugin nahi. Pet se bolo: "install plugin https://raw.githubusercontent.com/…"'; box.appendChild(h);
  Plugins.list.forEach((p) => { const b = document.createElement("button"); b.type = "button"; b.textContent = `✖ ${p.name}${p.off ? " (off)" : ""}`; b.onclick = () => { Plugins.list = Plugins.list.filter((x) => x !== p); Plugins.save(); renderBrainExtras(); }; box.appendChild(b); });
}

function localCommand(raw, l) {
  const n = normalize(raw); if (!n) return null;
  const R = (t, e, extra) => Object.assign({ text: t, emotion: e || "happy" }, extra || {});
  const wc = n.split(" ").length, short = wc <= 8, brief = wc <= 5;   // long sentences are real questions -> go to the AI
  if (WEB_Q.test(raw) && navigator.onLine && cfg.key) return null;          // live web questions go to the AI with Google Search
  const mh = Mem.handle(raw, l); if (mh) return R(mh, "happy");
  if (/(mera profile|my profile|soul profile)/.test(n)) { const d = Soul.d; return R(`Naam: ${d.name || "?"}, bhasha: ${d.language}, pasand: ${d.likes.slice(-4).join(", ") || "-"}. Ye sirf is phone me saved hai.`, "happy"); }
  if (/(profile delete|profile reset|meri profile mita)/.test(n)) { Soul.forget(); return R("Meri profile mita di.", "happy"); }
  if (/^\s*pc (?:se jodo|par|pe|se kaho|alag|disconnect|band)/i.test(raw)) { const o = PCLink.handle(raw); return R("…", "thinking", { fetch: () => o }); }
  const rk = Routines.match(n); if (rk && short) return R(tx(T3(ROUTINES[rk].say[0], ROUTINES[rk].say[1], ROUTINES[rk].say[1]), l), "happy", { run: () => Routines.run(rk) });
  if (/install plugin|update plugins|plugins dikhao|show plugins|my plugins|skill banao|make a skill|create a skill/i.test(raw) || (Plugins.pending && /^(yes|haan|han|ha|ok|install|no|nahi|nhi|cancel)$/.test(n))) { const o = Plugins.handle(raw); if (o) return o.then ? R("…", "thinking", { fetch: () => o }) : R(o, "happy"); }
  // --- tasks & notes
  const addT = raw.match(/^\s*(?:add task|task add|add todo|todo add|new task|add to my list|task|todo)\s*[:\-]?\s+(.+)$/i) || raw.match(/^\s*(?:task|kaam|todo|काम|टास्क)\s+(?:jodo|add karo|add kro|daalo|likho|जोड़ो|लिखो)\s+(.+)$/i) || raw.match(/^\s*(.+?)\s+(?:task me jodo|task mein jodo|todo me daalo|list me jodo|list mein jodo|टास्क में जोड़ो|लिस्ट में जोड़ो)\s*$/i);
  if (addT && !has(n, "done", "complete")) { Store.addTask(addT[1].trim()); return R(tx(T3(`Added to your tasks: ${addT[1].trim()}`, `Task me jod diya: ${addT[1].trim()}`, `टास्क में जोड़ दिया: ${addT[1].trim()}`), l), "happy", { run: () => {} }); }
  const doneT = n.match(/(?:task|kaam|todo|टास्क|काम)\s*(\d+)\s*(?:done|ho gaya|complete|हो गया|पूरा)|(?:done|complete|finish|poora)\s*(?:task|kaam)?\s*(\d+)/);
  if (doneT) { const i = parseInt(doneT[1] || doneT[2], 10) - 1, t = Store.tasks[i]; if (t) { t.done = true; Store.save(); return R(tx(T3(`Great job! “${t.text}” is done ✅`, `Shabash! “${t.text}” ho gaya ✅`, `शाबाश! “${t.text}” हो गया ✅`), l), "love"); } return R(tx(T3("I couldn't find that task number.", "Wo task number nahi mila.", "वो टास्क नंबर नहीं मिला।"), l), "confused"); }
  if (has(n, "my tasks", "show tasks", "task list", "todo list", "tasks dikhao", "mere task", "mere kaam", "kaam dikhao", "meri list", "मेरे काम", "टास्क दिखाओ", "मेरे टास्क")) {
    const open = Store.tasks.filter((t) => !t.done);
    return R(open.length ? open.slice(0, 5).map((t, i) => `${Store.tasks.indexOf(t) + 1}. ${t.text}`).join("; ") : tx(T3("No pending tasks. Nice!", "Koi pending task nahi. Mast!", "कोई पेंडिंग टास्क नहीं। बढ़िया!"), l), open.length ? "thinking" : "happy", { run: () => openSheet("t-tasks") });
  }
  const noteM = raw.match(/^\s*(?:note this|note karo|note kro|note|yaad rakho|likh lo|नोट करो|नोट)\s*[:\-]?\s+(.+)$/i);
  if (noteM) { Store.addNote(noteM[1].trim()); return R(tx(T3("Noted! 📝", "Note kar liya! 📝", "नोट कर लिया! 📝"), l), "happy"); }
  if (has(n, "my notes", "show notes", "mere notes", "notes dikhao", "मेरे नोट्स", "नोट्स दिखाओ")) { const L = Store.notes.slice(-3); return R(L.length ? L.map((x) => x.text).join("; ") : tx(T3("You have no notes yet.", "Abhi koi note nahi hai.", "अभी कोई नोट नहीं है।"), l), "thinking", { run: () => openSheet("t-tasks") }); }
  // --- focus / pomodoro
  if (has(n, "stop focus", "focus off", "focus band", "focus khatam", "फोकस बंद")) { Brain.focusUntil = 0; return R(tx(T3("Focus mode off. Welcome back!", "Focus mode band. Wapas swagat hai!", "फोकस मोड बंद। वापसी मुबारक!"), l), "happy"); }
  if (short && has(n, "focus", "pomodoro", "study mode", "padhai mode", "फोकस", "पोमोडोरो")) {
    const ms = parseDelay(n) || 25 * 60000; Brain.focusUntil = Date.now() + ms; Pet.mode = "sit";
    Reminders.add(ms, tx(T3("Focus session finished — take a 5 minute break!", "Focus session khatam — 5 minute ka break lo!", "फोकस सेशन खत्म — 5 मिनट का ब्रेक लो!"), l));
    return R(tx(T3(`Focus mode for ${fmtDur(ms, "en")}. I'll stay quiet. You can do it!`, `${fmtDur(ms, "hinglish")} ka focus mode. Main chup rahungi. Aap kar loge!`, `${fmtDur(ms, "hi")} का फोकस मोड। मैं चुप रहूँगी। आप कर लोगे!`), l), "happy");
  }
  // --- dice / coin
  if (short && has(n, "flip a coin", "coin flip", "toss", "sikka", "सिक्का", "heads or tails")) return R(Math.random() < 0.5 ? tx(T3("Heads!", "Chit!", "चित!"), l) : tx(T3("Tails!", "Pat!", "पट!"), l), "happy");
  if (short && has(n, "roll a dice", "roll dice", "dice", "pasa", "pansa", "लूडो", "पासा")) return R(tx(T3(`You rolled a ${1 + Math.floor(Math.random() * 6)}!`, `Aapka number aaya ${1 + Math.floor(Math.random() * 6)}!`, `आपका नंबर आया ${1 + Math.floor(Math.random() * 6)}!`), l), "happy");
  // --- help
  if (short && has(n, "help", "what can you do", "kya kar sakti", "kya kar sakte", "madad", "मदद", "क्या कर सकती", "क्या कर सकते")) return R(tx(T3("Here's what I can do — tap any example!", "Ye sab kar sakti hoon — kisi bhi example par tap karo!", "मैं ये सब कर सकती हूँ — किसी भी उदाहरण पर टैप करो!"), l), "happy", { run: () => openSheet("t-help") });
  // --- alarm / reminder at a clock time (e.g. "kal subah 7 baje alarm", "remind me at 6 pm to call mom")
  if (has(n, "alarm", "remind", "reminder", "yaad", "jagana", "wake", "याद", "अलार्म", "जगाना", "रिमाइंडर") && !parseDelay(n)) {
    const ms = parseClock(n);
    if (ms !== null) {
      const text = reminderText(raw), when = new Date(Date.now() + ms).toLocaleString("en-IN", { weekday: "short", hour: "numeric", minute: "2-digit" });
      Reminders.add(ms, text || tx(T3("Alarm!", "Alarm!", "अलार्म!"), l));
      try { if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); } catch (e) {}
      return R(tx(T3(`Okay! I'll remind you on ${when}${text ? ": " + text : ""}.${NATIVE ? "" : " Keep this app open."}`, `Theek hai! ${when} par yaad dilaungi${text ? ": " + text : ""}.${NATIVE ? "" : " App khula rakhna."}`, `ठीक है! ${when} पर याद दिलाऊँगी${text ? ": " + text : ""}।${NATIVE ? "" : " ऐप खुला रखना।"}`), l), "happy");
    }
  }
  // reminders: list / cancel
  if (has(n, "my reminders", "show reminders", "list reminders", "mere reminder", "reminders dikhao", "kitne reminder", "मेरे रिमाइंडर", "रिमाइंडर दिखाओ")) {
    const L = Reminders.list.slice().sort((a, b) => a.at - b.at);
    if (!L.length) return R(tx(T3("You have no reminders.", "Abhi koi reminder nahi hai.", "अभी कोई रिमाइंडर नहीं है।"), l), "happy");
    return R(L.slice(0, 5).map((r) => `${new Date(r.at).toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" })}${r.text ? " " + r.text : ""}`).join("; "), "happy");
  }
  if (has(n, "cancel reminders", "delete reminders", "clear reminders", "reminder hatao", "reminders hatao", "reminder cancel", "रिमाइंडर हटाओ", "रिमाइंडर रद्द")) {
    Reminders.clearAll();
    return R(tx(T3("All reminders cancelled.", "Saare reminder hata diye.", "सारे रिमाइंडर हटा दिए।"), l), "happy");
  }
  // weather (free open-meteo, needs internet + location permission) and battery
  if (has(n, "weather", "mausam", "mosam", "temperature", "tapman", "मौसम", "तापमान", "barish hogi", "बारिश")) {
    const junk = /\b(today|now|aaj|abhi|kaisa|kaisi|hai|hoga|batao|bata|tell|me|the|current|please|plz|kya|ka|ki|ke)\b/g;
    const cm = n.match(/(?:weather|mausam|temperature|tapman)\s+(?:in|of|at|for|me|mein)\s+([a-z\u0900-\u097f ]{2,40})/) || n.match(/^([a-z\u0900-\u097f ]{2,40}?)\s+(?:ka|ki|me|mein|का|की|में)\s+(?:mausam|weather|मौसम|temperature)/);
    const city = cm ? cm[1].replace(junk, " ").replace(/\s+/g, " ").trim() : "";
    return R(tx(T3("Let me check the weather…", "Mausam check karti hoon…", "मौसम देखती हूँ…"), l), "thinking", { fetch: (ll) => weatherText(ll, city) });
  }
  if (has(n, "battery", "charge kitna", "बैटरी", "charging")) {
    return R(tx(T3("Checking the battery…", "Battery dekhti hoon…", "बैटरी देखती हूँ…"), l), "thinking", { fetch: batteryText });
  }
  // time & date
  if (wc <= 6 && has(n, "time", "samay", "kitne baje", "baj gaye", "टाइम", "समय", "कितने बजे", "बजे हैं")) { const d = new Date(); return R(tx(T3(`It's ${d.toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" })}.`, `Abhi ${d.toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" })} baje hain.`, `अभी ${d.toLocaleTimeString("hi-IN", { hour: "numeric", minute: "2-digit" })} बजे हैं।`), l), "happy"); }
  if (wc <= 6 && has(n, "date", "tarikh", "tareekh", "aaj kaun sa din", "today", "तारीख", "आज कौन सा दिन", "दिनांक", "what day")) { const d = new Date(); return R(tx(T3(`Today is ${d.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}.`, `Aaj ${d.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })} hai.`, `आज ${d.toLocaleDateString("hi-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })} है।`), l), "happy"); }
  // timers / reminders
  const wantsRem = has(n, "remind", "reminder", "timer", "alarm", "yaad dila", "yaad dilana", "yaad dilao", "याद दिला", "रिमाइंडर", "टाइमर", "अलार्म", "baad", "बाद", "after", "in");
  const delay = parseDelay(n);
  if (delay && wantsRem && (has(n, "remind", "reminder", "timer", "alarm", "yaad", "याद", "रिमाइंडर", "टाइमर", "अलार्म", "baad", "बाद", "after"))) {
    const text = reminderText(raw); Reminders.add(delay, text);
    try { if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); } catch (e) {}
    return R(tx(T3(`Okay! I'll remind you in ${fmtDur(delay, "en")}${text ? ": " + text : ""}.${NATIVE ? "" : " Keep this app open."}`, `Theek hai! ${fmtDur(delay, "hinglish")} baad yaad dilaungi${text ? ": " + text : ""}.${NATIVE ? "" : " App khula rakhna."}`, `ठीक है! ${fmtDur(delay, "hi")} बाद याद दिलाऊँगी${text ? ": " + text : ""}।${NATIVE ? "" : " ऐप खुला रखना।"}`), l), "happy");
  }
  // what was I doing / journal
  if (has(n, "what was i doing", "what did i do", "kya kar raha tha", "kya kar rahi thi", "kya kr rha tha", "maine kya kiya", "main kya kar raha tha", "मैं क्या कर रहा था", "मैंने क्या किया", "क्या कर रहा था", "क्या कर रही थी")) {
    const rec = Brain.journal.filter((e) => e.kind === "cmd").slice(-4);
    if (!rec.length) return R(tx(T3("We haven't done anything yet today!", "Abhi tak humne kuch kiya hi nahi!", "अभी तक हमने कुछ किया ही नहीं!"), l), "thinking");
    const list = rec.map((e) => `“${e.text}” (${new Date(e.t).toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" })})`).join(", ");
    return R(tx(T3(`Recently you asked me: ${list}.`, `Haal hi me aapne mujhse ye kaha: ${list}.`, `हाल ही में आपने ये कहा: ${list}।`), l), "thinking");
  }
  // calculator
  const calc = n.replace(/x/g, "*").replace(/[^0-9+\-*/().% ]/g, "").trim();
  if (/^[\d\s+\-*/().%]+$/.test(calc) && /\d\s*[+\-*/]\s*\d/.test(calc) && calc.length < 40) {
    try { const v = Function('"use strict";return (' + calc.replace(/%/g, "/100") + ")")(); if (Number.isFinite(v)) return R(`${calc} = ${Math.round(v * 1e8) / 1e8}`, "happy"); } catch (e) {}
  }
  // --- premium phone control (Android app + Screen control enabled)
  if (NATIVE) {
    const rawL = raw.trim();
    const ag = rawL.match(/^(?:agent|auto|autopilot)\s*[:\-]?\s+(.+)$/i) || rawL.match(/^(.+?)\s+(?:khud se karo|khud karo|apne aap karo|khud kar do|automatically karo)\s*$/i);
    if (ag) return R(tx(T3("On it! Tap me anytime to stop.", "Ho jayega! Rokna ho to mujhe tap karo.", "हो जाएगा! रोकना हो तो मुझे टैप करो।"), l), "happy", { fetch: (ll) => Agent.run(ag[1].trim(), ll) });
    if (has(n, "ruko", "stop agent", "agent stop", "ruk jao", "रुको") && Agent.running) { Agent.stop = true; return R(tx(T3("Stopping.", "Ruk rahi hoon.", "रुक रही हूँ।"), l), "neutral"); }
    if (/(screen|स्क्रीन|\bpage\b|पेज|webpage|website|article|\bchat\b)/.test(n) && /(padh|पढ़|read|summar|saar|सार|samjha|समझा|explain|batao|बताओ|kya hai|क्या है|kya likha|translate|answer|reply|jawab|dhundo)/.test(n) && /(\bis\b|\bye\b|\byeh\b|this|ispe|iske|isme|screen|स्क्रीन|यह|ये|इस)/.test(n) && !has(n, "kholo", "open", "khol"))
      return R(tx(T3("Reading the screen…", "Screen dekh rahi hoon…", "स्क्रीन देख रही हूँ…"), l), "thinking", { fetch: (ll) => screenAnswer(raw, ll) });
    if (fileCtx && Date.now() - fileCtx.at < 600000 && /(file|pdf|image|photo|document|doc|tasveer|फ़ाइल|फाइल|इमेज)/.test(n) && wc > 2)
      return R(tx(T3("Looking at the file…", "File dekh rahi hoon…", "फ़ाइल देख रही हूँ…"), l), "thinking", { fetch: (ll) => askAboutBlob(fileCtx.blob, fileCtx.name, fileCtx.mime, raw, ll) });
    const glob = (w, a, b, c, d) => R(tx(T3(a, b, c), l), "happy", { run: () => { if (nat("global", w) === "off") toast("Screen control chalu karo: ⚙ → AI & App → Android", 4500); } });
    if (has(n, "go back", "back jao", "peeche jao", "wapas jao", "back karo", "पीछे जाओ", "वापस जाओ") && brief) return glob("back", "Going back.", "Peeche ja rahi hoon.", "पीछे जा रही हूँ।");
    if (has(n, "go home", "home jao", "home par jao", "home screen", "ghar jao", "होम जाओ") && brief) return glob("home", "Going home.", "Home par ja rahi hoon.", "होम पर जा रही हूँ।");
    if (has(n, "recent apps", "recents", "app switch", "रीसेंट") && brief) return glob("recents", "Showing recent apps.", "Recent apps dikha rahi hoon.", "रीसेंट ऐप्स दिखा रही हूँ।");
    if (has(n, "notification panel", "notifications kholo", "notification dikhao", "notifications dikhao", "notification kholo", "नोटिफिकेशन") && brief) return glob("notifications", "Opening notifications.", "Notifications khol rahi hoon.", "नोटिफिकेशन खोल रही हूँ।");
    if (has(n, "quick settings") && brief) return glob("quick", "Opening quick settings.", "Quick settings khol rahi hoon.", "क्विक सेटिंग्स खोल रही हूँ।");
    if (has(n, "lock phone", "phone lock", "lock the phone", "phone ko lock", "screen lock", "lock karo", "लॉक करो") && brief) return glob("lock", "Locking.", "Lock kar rahi hoon.", "लॉक कर रही हूँ।");
    if (has(n, "screenshot", "स्क्रीनशॉट") && brief) return glob("shot", "Taking a screenshot.", "Screenshot le rahi hoon.", "स्क्रीनशॉट ले रही हूँ।");
    const sc = has(n, "scroll", "स्क्रॉल") || (brief && has(n, "neeche", "niche", "upar", "नीचे", "ऊपर") && has(n, "jao", "karo", "dikhao", "ja", "जाओ", "करो"));
    if (sc) { const up = has(n, "up", "upar", "ऊपर"); return R(tx(T3(up ? "Scrolling up." : "Scrolling down.", up ? "Upar scroll kar rahi hoon." : "Neeche scroll kar rahi hoon.", up ? "ऊपर स्क्रॉल कर रही हूँ।" : "नीचे स्क्रॉल कर रही हूँ।"), l), "happy", { run: () => { const r = nat("scroll", up ? "up" : "down"); if (r === "off") toast("Screen control chalu karo: ⚙ → AI & App → Android", 4500); } }); }
    const clk = rawL.match(/^(?:click|tap|press|select|dabao)\s+(?:on\s+)?(.+)$/i) || rawL.match(/^(.+?)\s+(?:par|pe|ko|पर|को)\s+(?:click|tap|dabao|press|क्लिक|दबाओ)(?:\s+(?:karo|kro|kar do|करो))?\s*$/i);
    if (clk && !has(n, "enter")) { const lab = clk[1].replace(/["“”']/g, "").trim(); return R(tx(T3(`Tapping “${lab}”.`, `“${lab}” daba rahi hoon.`.replace("daba", "daba"), `“${lab}” दबा रही हूँ।`), l), "happy", { run: () => { const r = nat("click", lab); if (r === "off") toast("Screen control chalu karo: ⚙ → AI & App → Android", 4500); else if (r !== "ok") toast(`“${lab}” screen par nahi mila`, 3500); } }); }
    const typ = rawL.match(/^(?:(?:yaha|yahan|isme|ispe|यहाँ|इसमें)\s+)?(?:type|typing|likh do|likho|लिखो)\s*[:\-]?\s+(.+)$/i);
    if (typ && /^(?:yaha|yahan|isme|ispe|यहाँ|इसमें|type|typing)/i.test(rawL)) { const txt = typ[1].trim(); return R(tx(T3("Typing it.", "Likh rahi hoon.", "लिख रही हूँ।"), l), "happy", { run: () => { const r = nat("type", txt); if (r === "off") toast("Screen control chalu karo: ⚙ → AI & App → Android", 4500); else if (r !== "ok") toast("Koi text box nahi mila. Pehle box par tap karo.", 3500); } }); }
    if (has(n, "enter dabao", "enter press", "search karo yahi", "go dabao", "submit karo") && brief) return R(tx(T3("Pressing enter.", "Enter daba rahi hoon.".replace("daba", "daba"), "एंटर दबा रही हूँ।"), l), "happy", { run: () => nat("enter") });
  }
  // --- phone control (only inside the Android app)
  if (NATIVE && short) {
    const on = has(n, "on", "chalu", "jalao", "jala", "chalao", "चालू", "जलाओ"), off = has(n, "off", "band", "bujhao", "bujha", "बंद", "बुझाओ");
    if (has(n, "torch", "flashlight", "flash light", "tourch", "टॉर्च", "फ्लैशलाइट") || (has(n, "light", "batti", "बत्ती") && (on || off))) {
      const mode = off ? "off" : on ? "on" : "toggle";
      return R(tx(T3(mode === "off" ? "Torch off." : "Torch on!", mode === "off" ? "Torch band." : "Torch chalu!", mode === "off" ? "टॉर्च बंद।" : "टॉर्च चालू!"), l), "happy", { run: () => { if (nat("torch", mode) !== "ok") toast("Is phone me torch nahi mili"); } });
    }
    if (has(n, "volume", "awaaz", "awaz", "आवाज़", "आवाज", "वॉल्यूम", "sound", "mute", "म्यूट")) {
      const up = has(n, "up", "badhao", "badha", "zyada", "increase", "high", "tez", "बढ़ाओ", "ज़्यादा", "ज्यादा"), down = has(n, "down", "kam", "ghatao", "ghata", "decrease", "low", "कम", "घटाओ"), mute = has(n, "mute", "silent", "chup", "म्यूट", "band", "बंद");
      if (up || down || mute) return R(tx(T3(mute ? "Muted." : up ? "Volume up!" : "Volume down.", mute ? "Mute kar diya." : up ? "Awaaz badha di!" : "Awaaz kam kar di.", mute ? "म्यूट कर दिया।" : up ? "आवाज़ बढ़ा दी!" : "आवाज़ कम कर दी।"), l), "happy", { run: () => nat("volume", mute ? "mute" : up ? "up" : "down") });
    }
    if (has(n, "wifi", "wi-fi", "वाईफाई", "वाई-फाई")) return R(tx(T3("Opening Wi-Fi settings.", "Wi-Fi settings khol rahi hoon.", "वाई-फ़ाई सेटिंग्स खोल रही हूँ।"), l), "happy", { run: () => nat("settings", "wifi") });
    if (has(n, "bluetooth", "ब्लूटूथ")) return R(tx(T3("Opening Bluetooth settings.", "Bluetooth settings khol rahi hoon.", "ब्लूटूथ सेटिंग्स खोल रही हूँ।"), l), "happy", { run: () => nat("settings", "bluetooth") });
    const cn = n.match(/^(?:call|phone|dial|फोन|कॉल)\s+(?:karo\s+|kro\s+)?([a-z\u0900-\u097f ]{2,30}?)(?:\s+(?:ko|karo|kro|को|करो))*$/) || n.match(/^([a-z\u0900-\u097f ]{2,30}?)\s+(?:ko|को)\s+(?:call|phone|dial|कॉल|फोन)(?:\s+(?:karo|kro|kar|laga|lagao|करो|लगाओ))*$/);
    if (cn && !/\d/.test(cn[1])) {
      const who = cn[1].trim();
      return R(tx(T3(`Calling ${who}…`, `${who} ko call laga rahi hoon…`, `${who} को कॉल लगा रही हूँ…`), l), "happy", { run: () => {
        const r = nat("call", who);
        if (r === "perm") { toast("Contacts ki permission chahiye: ⚙ → AI & App → Android", 5000); openSheet("t-ai"); }
        else if (r !== "ok") toast(`“${who}” naam ka contact nahi mila`, 4000);
      } });
    }
  }
  // call a number
  const tel = n.match(/(?:call|dial|phone|फोन|कॉल)\s*(?:karo|kro|करो|to)?\s*(\+?\d[\d ]{6,14})/);
  if (tel) { const num = tel[1].replace(/\s/g, ""); return R(tx(T3(`Calling ${num}…`, `${num} ko call laga rahi hoon…`, `${num} को कॉल लगा रही हूँ…`), l), "happy", { run: () => (location.href = "tel:" + num) }); }
  // search & play
  const STOP = /(^| )(youtube|yt|you tube|pe|par|per|me|mein|on|for|the|a|play|chalao|chala|chalana|bajao|bajana|laga|lagao|gana|gaana|song|video|search|google|karo|kro|kar|dhundo|dhoondo|khojo|ko|ka|ki|ke|please|plz|mere|liye|se|find|look|up|chahiye)(?= |$)/g;
  const strip = (x) => x.replace(/(यूट्यूब|पर|में|चलाओ|चला|बजाओ|गाना|सर्च|करो|खोजो|ढूंढो|गूगल|पे|मेरे|लिए)/g, " ").replace(STOP, " ").replace(STOP, " ").replace(/\s+/g, " ").trim();
  if (has(n, "play", "chalao", "chala", "bajao", "gana", "gaana", "song", "चलाओ", "चला", "बजाओ", "गाना") && !has(n, "search", "google", "dhundo")) {
    const q = strip(n);
    if (q.length > 1) return R(tx(T3(`Playing “${q}” on YouTube.`, `YouTube par “${q}” chala rahi hoon.`, `YouTube पर “${q}” चला रही हूँ।`), l), "happy", { run: () => openUrl("https://www.youtube.com/results?search_query=" + encodeURIComponent(q)) });
  }
  if (has(n, "search", "google", "dhundo", "dhoondo", "khojo", "सर्च", "खोजो", "ढूंढो") && !has(n, "open", "kholo", "खोलो")) {
    const q = strip(n);
    if (q.length > 1) return R(tx(T3(`Searching for “${q}”.`, `“${q}” search kar rahi hoon.`, `“${q}” खोज रही हूँ।`), l), "thinking", { run: () => openUrl("https://www.google.com/search?q=" + encodeURIComponent(q)) });
  }
  // open apps / sites
  if (has(n, "open", "kholo", "khol", "start", "launch", "chalu", "खोलो", "खोल", "चालू", "ओपन")) {
    const a = APPS.find((x) => x.k.some((k) => has(n, k)));
    if (a) return R(tx(T3(`Opening ${a.name}.`, `${a.name} khol rahi hoon.`, `${a.name} खोल रही हूँ।`), l), "happy", { run: () => { if (NATIVE && nat("app", a.name) === "ok") return; openUrl(a.url); } });
    const dom = n.match(/([a-z0-9-]+\.(?:com|in|org|net|io|co|app))/);
    if (dom) return R(tx(T3(`Opening ${dom[1]}.`, `${dom[1]} khol rahi hoon.`, `${dom[1]} खोल रही हूँ।`), l), "happy", { run: () => openUrl("https://" + dom[1]) });
    if (NATIVE && short) {                                   // any installed app by its name: "camera kholo", "open calculator", "settings kholo"
      const name = n.replace(/(^| )(open|kholo|khol|start|launch|chalu|app|application|please|plz|karo|kro|kar|do|de|ko|ka|ki|ke|mujhe|ek|the|a|my|mera|meri|apna)(?= |$)/g, " ").replace(/(खोलो|खोल|चालू|ओपन|ऐप|को|करो)/g, " ").replace(/\s+/g, " ").trim();
      if (name.length > 1) return R(tx(T3(`Opening ${name}.`, `${name} khol rahi hoon.`, `${name} खोल रही हूँ।`), l), "happy", { run: () => { if (nat("app", name) !== "ok") toast(`“${name}” naam ka app nahi mila`, 3500); } });
    }
  }
  // small talk that works offline
  if (brief && has(n, "hello", "hi", "hey", "namaste", "hii", "hlo", "नमस्ते", "हेलो", "हाय")) return R(tx(T3(`Hi ${you()}! How can I help?`, `Hello ${you()}! Bolo, kya madad karun?`, `नमस्ते ${you()}! बोलो, क्या मदद करूँ?`), l), "happy");
  if (brief && has(n, "how are you", "kaise ho", "kaisi ho", "kya haal", "kaise hain", "कैसे हो", "कैसी हो", "क्या हाल")) return R(tx(T3("I'm great now that you're here!", "Main mast hoon, aap aaye to aur achha lag raha hai!", "मैं बढ़िया हूँ, आप आए तो और अच्छा लगा!"), l), "love");
  if (brief && has(n, "your name", "tumhara naam", "aapka naam", "tera naam", "who are you", "tum kaun", "तुम्हारा नाम", "आपका नाम", "तुम कौन")) return R(tx(T3(`I'm ${nm()}, your anime buddy!`, `Main ${nm()} hoon, aapki anime dost!`, `मैं ${nm()} हूँ, आपकी एनिमे दोस्त!`), l), "happy");
  if (brief && has(n, "thank", "thanks", "shukriya", "dhanyavad", "thnx", "शुक्रिया", "धन्यवाद")) return R(tx(T3("Anytime! 💕", "Koi baat nahi! 💕", "कोई बात नहीं! 💕"), l), "love");
  if (brief && has(n, "i love you", "love you", "luv u", "i luv u", "लव यू", "आई लव यू")) return R(tx(T3("E-eh?! I… I like you too!", "A-arey?! Main… main bhi aapko pasand karti hoon!", "अ-अरे?! मैं… मैं भी आपको पसंद करती हूँ!"), l), "embarrassed");
  if (brief && has(n, "joke", "chutkula", "mazak", "hasao", "जोक", "चुटकुला", "हँसाओ")) return R(pick([tx(T3("Why do programmers prefer dark mode? Because light attracts bugs!", "Programmer dark mode kyun use karte hain? Kyunki light se bugs aate hain!", "प्रोग्रामर डार्क मोड क्यों पसंद करते हैं? क्योंकि रोशनी से बग आते हैं!"), l), tx(T3("I told my phone I needed space. Now it won't stop showing 'Storage full'.", "Maine phone se bola mujhe space chahiye. Ab wo bas 'Storage full' dikhata hai.", "मैंने फ़ोन से कहा मुझे स्पेस चाहिए। अब वो बस 'Storage full' दिखाता है।"), l)]), "happy");
  if (brief && has(n, "good night", "gn", "shubh ratri", "शुभ रात्रि", "गुड नाइट")) return R(tx(T3("Good night! Sweet dreams 🌙", "Good night! Meethe sapne 🌙", "शुभ रात्रि! मीठे सपने 🌙"), l), "sleepy");
  if (brief && has(n, "good morning", "suprabhat", "सुप्रभात", "गुड मॉर्निंग")) return R(tx(T3("Good morning! Let's have a great day!", "Good morning! Aaj ka din mast jaayega!", "सुप्रभात! आज का दिन शानदार होगा!"), l), "happy");
  if (has(n, "next character", "change character", "character badlo", "dusra character", "कैरेक्टर बदलो")) { const i = CHARS.findIndex((c) => c.id === CHAR.id); return R(tx(T3("Changing my look!", "Naya look!", "नया लुक!"), l), "happy", { run: () => setChar(CHARS[(i + 1) % CHARS.length].id) }); }
  return null;
}

/* ------------------------------------------------------------------ online brain (Gemini) */
const history = jget("haa_hist", []);
function systemPrompt(l, q) {
  const lang = { en: "English", hinglish: "Hinglish (Hindi written in Latin letters)", hi: "Hindi (Devanagari)" }[l] || "the same language as the user";
  return `You are ${nm()}, a ${CHAR && CHAR.gender === "boy" ? "male" : "female"} anime companion living on ${you()}'s phone. Personality: ${personaText()}. ` +
    `Reply in ${lang}, always in the same language and script the user used. Keep it to 1-3 short, warm, natural sentences, no markdown. ` +
    `Begin every reply with one emotion tag in square brackets chosen from: ${EMOTIONS.join(", ")}. Example: [happy] Sure, here you go! ` +
    `You are caring and a little playful like a best friend: notice the user's mood and match it (gentle when sad, excited when happy), and use what you remember about them naturally. ` +
    `Now it is ${new Date().toLocaleString("en-IN", { dateStyle: "full", timeStyle: "short" })}. ` + (cfg.memOn !== false && q ? Mem.context(q) : "") + (cfg.memOn !== false ? Soul.prompt() : "");
}
function parseTag(t) {
  const m = t.match(/^\s*\[([a-z]+)\]\s*/i);
  if (m && EMOTIONS.includes(m[1].toLowerCase())) return [t.slice(m[0].length).trim(), m[1].toLowerCase()];
  return [t.replace(/^\s*\[[a-z]+\]\s*/i, "").trim(), guessEmotion(t)];
}
function guessEmotion(t) { const s = t.toLowerCase(); if (/sorry|sad|unfortunately|maaf|दुख/.test(s)) return "sad"; if (/\?$/.test(s.trim())) return "thinking"; if (/!|haha|great|love|mast|खुश/.test(s)) return "happy"; return "neutral"; }
/* ---- cloud brains: Gemini (streaming), OpenAI, Claude. A failing one is skipped for a minute so answers stay fast. */
const KEYOF = { gemini: "key", openai: "okey", claude: "ckey" };
const hasKey = () => !!(cfg.key || cfg.okey || cfg.ckey);
const provDown = {};
function providerList() {
  const o = String(cfg.order || "gemini,openai,claude").split(",").filter((p) => KEYOF[p]);
  Object.keys(KEYOF).forEach((p) => { if (!o.includes(p)) o.push(p); });
  return o.filter((p) => cfg[KEYOF[p]]);
}
const provUsable = () => providerList().filter((p) => (provDown[p] || 0) < Date.now());
async function httpJson(url, headers, body, ms) {
  const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), ms || 30000);
  try {
    const r = await fetch(url, { method: "POST", headers: Object.assign({ "Content-Type": "application/json" }, headers), body: JSON.stringify(body), signal: ctl.signal });
    if (r.status === 401 || r.status === 403 || r.status === 400) throw new Error("key");
    if (!r.ok) throw new Error("http " + r.status);
    return await r.json();
  } finally { clearTimeout(to); }
}
// parts = Gemini-style [{text}|{inline_data:{mime_type,data}}]; returns plain text
async function otherOnce(p, system, hist, parts, o) {
  o = o || {};
  const txt = parts.filter((x) => x.text != null).map((x) => x.text).join("\n"), img = parts.find((x) => x.inline_data);
  if (p === "openai") {
    const msgs = [{ role: "system", content: system }].concat(hist.map((h) => ({ role: h.role === "model" ? "assistant" : "user", content: h.parts[0].text })));
    msgs.push({ role: "user", content: img ? [{ type: "text", text: txt }, { type: "image_url", image_url: { url: `data:${img.inline_data.mime_type};base64,${img.inline_data.data}` } }] : txt });
    const body = { model: cfg.omodel || "gpt-4o-mini", messages: msgs, max_tokens: o.max || 300, temperature: o.temp == null ? 0.8 : o.temp };
    if (o.json) body.response_format = { type: "json_object" };
    const j = await httpJson("https://api.openai.com/v1/chat/completions", { Authorization: "Bearer " + cfg.okey }, body);
    return (((j.choices || [])[0] || {}).message || {}).content || "";
  }
  const msgs = hist.map((h) => ({ role: h.role === "model" ? "assistant" : "user", content: h.parts[0].text }));
  msgs.push({ role: "user", content: img ? [{ type: "image", source: { type: "base64", media_type: img.inline_data.mime_type, data: img.inline_data.data } }, { type: "text", text: txt }] : txt });
  const j = await httpJson("https://api.anthropic.com/v1/messages", { "x-api-key": cfg.ckey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
    { model: cfg.cmodel || "claude-haiku-5-5", system, messages: msgs, max_tokens: o.max || 300, temperature: o.temp == null ? 0.8 : o.temp });
  return (j.content || []).map((b) => b.text || "").join("");
}
async function askGemini(text, l, onText) {
  const list = provUsable(); let last;
  if (!list.length) throw new Error(providerList().length ? "http 429" : "nokey");
  for (const p of list) {
    try {
      if (p === "gemini") return await askGeminiStream(text, l, onText);
      const out = (await otherOnce(p, systemPrompt(l, text), history.slice(-8), [{ text }])).trim(); if (!out) throw new Error("empty");
      history.push({ role: "user", parts: [{ text }] }, { role: "model", parts: [{ text: out }] }); while (history.length > 16) history.shift(); jset("haa_hist", history);
      onText && onText(out); return out;
    } catch (e) { last = e; provDown[p] = Date.now() + 60000; }
  }
  throw last;
}
async function askGeminiStream(text, l, onText) {
  const body = { systemInstruction: { parts: [{ text: systemPrompt(l, text) }] }, contents: history.slice(-8).concat([{ role: "user", parts: [{ text }] }]), generationConfig: { temperature: 0.8, maxOutputTokens: 260 } };
  const base = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cfg.model || DEFAULTS.model)}:streamGenerateContent?alt=sse&key=${encodeURIComponent(cfg.key)}`;
  const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 35000);
  try {
    let r;
    for (let attempt = 0; attempt < 2; attempt++) {                        // one quick retry on rate-limit / server hiccup
      r = await fetch(base, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctl.signal });
      if ((r.status === 429 || r.status >= 500) && attempt === 0) { await sleep(1200); continue; }
      break;
    }
    if (!r.ok) { const e = await r.text().catch(() => ""); throw new Error(r.status === 400 || r.status === 403 ? "key" : "http " + r.status + " " + e.slice(0, 80)); }
    const rd = r.body.getReader(), dec = new TextDecoder(); let buf = "", acc = "";
    for (;;) {
      const { value, done } = await rd.read(); if (done) break;
      buf += dec.decode(value, { stream: true }); const lines = buf.split("\n"); buf = lines.pop();
      for (const ln of lines) {
        if (!ln.startsWith("data:")) continue;
        try { const j = JSON.parse(ln.slice(5).trim()); const p = j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts; if (p) { acc += p.map((x) => x.text || "").join(""); onText && onText(acc); } } catch (e) {}
      }
    }
    acc = acc.trim(); if (!acc) throw new Error("empty");
    history.push({ role: "user", parts: [{ text }] }, { role: "model", parts: [{ text: acc }] }); while (history.length > 16) history.shift(); jset("haa_hist", history);
    return acc;
  } finally { clearTimeout(to); }
}
const OFFLINE_MSG = T3(
  "I'm offline right now, so I can only do local things: time, date, reminders, calculator, opening apps and searching. For chatting offline, download my offline brain in ⚙ → AI & App.",
  "Abhi internet nahi hai, isliye main sirf local kaam kar sakti hoon: time, date, reminder, calculator, app kholna aur search. Offline baat-cheet ke liye ⚙ → AI & App me offline dimaag download karo.",
  "अभी इंटरनेट नहीं है, इसलिए मैं सिर्फ़ लोकल काम कर सकती हूँ: समय, तारीख, रिमाइंडर, कैलकुलेटर, ऐप खोलना और सर्च। बातचीत के लिए इंटरनेट चाहिए।");
const OFFAI_FAIL = T3("My offline brain couldn't start on this phone. Try again, or reinstall it in ⚙ → AI & App.", "Offline dimaag is phone par start nahi hua. Phir try karo ya ⚙ → AI & App me dobara download karo.", "ऑफ़लाइन दिमाग इस फ़ोन पर शुरू नहीं हुआ। फिर कोशिश करो या ⚙ → AI & App में दोबारा डाउनलोड करो।");
const NOKEY_MSG = T3(
  "To chat with me I need a free Gemini key. Open ⚙ → AI & App and paste it. Meanwhile I can still do time, reminders, apps and search!",
  "Baat karne ke liye mujhe ek free Gemini key chahiye. ⚙ → AI & App me paste kar do. Tab tak main time, reminder, app aur search kar sakti hoon!",
  "बात करने के लिए मुझे एक फ्री Gemini key चाहिए। ⚙ → AI & App में पेस्ट कर दो। तब तक मैं समय, रिमाइंडर, ऐप और सर्च कर सकती हूँ!");

/* ------------------------------------------------------------------ offline AI brain (runs on the phone) */
const OFF_MODEL = "onnx-community/Qwen2.5-0.5B-Instruct";
const OffAI = {
  w: null, loaded: false, id: 0, handlers: {}, loadCb: null,
  start() {
    if (this.w) return;
    this.w = new Worker("offline-worker.js", { type: "module" });
    this.w.onmessage = (e) => {
      const m = e.data;
      if (m.type === "progress" && this.loadCb && this.loadCb.onProgress) {
        let got = 0, tot = 0; Object.values(m.files).forEach((f) => { got += f.loaded; tot += f.total; });
        this.loadCb.onProgress(tot ? Math.min(99, Math.round((got * 100) / tot)) : 0, got, tot);
      } else if (m.type === "ready") { this.loaded = true; const c = this.loadCb; this.loadCb = null; c && c.res(); }
      else if (m.type === "tok" && this.handlers[m.id]) this.handlers[m.id].tok(m.text);
      else if (m.type === "done" && this.handlers[m.id]) { this.handlers[m.id].res(); delete this.handlers[m.id]; }
      else if (m.type === "error") {
        if (m.id && this.handlers[m.id]) { this.handlers[m.id].rej(new Error(m.error)); delete this.handlers[m.id]; }
        else if (this.loadCb) { const c = this.loadCb; this.loadCb = null; c.rej(new Error(m.error)); }
      }
    };
    this.w.onerror = (e) => { const c = this.loadCb; this.loadCb = null; this.w = null; c && c.rej(new Error(e.message || "worker failed")); Object.values(this.handlers).forEach((h) => h.rej(new Error("worker failed"))); this.handlers = {}; };
  },
  device() { return navigator.gpu ? "webgpu" : "wasm"; },
  load(onProgress) { return new Promise((res, rej) => { this.start(); this.loadCb = { res, rej, onProgress }; this.w.postMessage({ type: "load", model: OFF_MODEL, device: this.device() }); }); },
  chat(messages, onText) {
    return new Promise((res, rej) => {
      this.start(); const id = ++this.id; let acc = "";
      this.handlers[id] = { tok: (t) => { acc += t; onText && onText(acc); }, res: () => res(acc.trim()), rej };
      this.w.postMessage({ type: "chat", id, messages, model: OFF_MODEL, device: this.device() });
    });
  },
};
const offHist = jget("haa_offhist", []);
function offSystem(l) {
  const lang = { en: "English", hinglish: "Hinglish (Hindi written in English letters)", hi: "Hindi (Devanagari)" }[l] || "the user's language";
  return `You are ${nm()}, a cute ${CHAR && CHAR.gender === "boy" ? "male" : "female"} anime companion on ${you()}'s phone. Personality: ${personaText()}. Reply in ${lang}, in 1-2 short friendly sentences. Never use markdown.`;
}
async function answerOffline(text, l, afterSpeech) {
  Pet.setEmotion("thinking", 30000); say(OffAI.loaded ? "…" : tx(T3("Waking up my offline brain…", "Offline dimaag jaag raha hai…", "ऑफ़लाइन दिमाग जाग रहा है…"), l), 30000);
  TTS.begin(); const sp = makeSpeaker(l); let fake = false;
  const messages = [{ role: "system", content: offSystem(l) }, ...offHist.slice(-6), { role: "user", content: text }];
  const out = await OffAI.chat(messages, (acc) => { say(acc, 30000); sp.feed(acc, false); if (!cfg.speak && !fake) { fake = true; Pet.speaking = true; } });
  const reply = out.replace(/^\s*\[[a-z]+\]\s*/i, "").trim() || tx(T3("Hmm, I don't know what to say.", "Hmm, samajh nahi aaya kya bolun.", "हम्म, समझ नहीं आया क्या बोलूँ।"), l);
  offHist.push({ role: "user", content: text }, { role: "assistant", content: reply }); while (offHist.length > 12) offHist.shift(); jset("haa_offhist", offHist);
  Pet.setEmotion(guessEmotion(reply), Math.min(9000, 3000 + reply.length * 45)); say(reply); logChat("bot", reply); sp.feed(reply, true);
  if (fake) setTimeout(() => (Pet.speaking = false), Math.min(3500, reply.length * 40));
  afterSpeech();
}

let busy = false;
async function submit(text, fromVoice) {
  text = text.trim(); if (!text || busy) return;
  busy = true; Brain.touched(); Brain.lastSubmit = Date.now(); haptic(12); addBond(2);
  const l = replyLang(text); lastLang = detectLang(text);
  say(text, 2500, true); Brain.log("cmd", text); logChat("me", text);
  const afterSpeech = () => TTS.whenIdle(() => { if (cfg.conv && Voice.supported) setTimeout(() => Voice.start(), 350); });
  try {
    const lc = localCommand(text, l);
    if (lc) {
      deliver(lc.text, lc.emotion, false, l);
      if (lc.run) setTimeout(lc.run, 700);
      if (lc.fetch) { let out; try { out = await lc.fetch(l); } catch (e) { out = tx(T3("I couldn't get that right now.", "Abhi ye nahi mil paaya.", "अभी ये नहीं मिल पाया।"), l); } deliver(out, "happy", false, l); }
      return;
    }
    Mem.learn(text); Soul.observe(text);
    const kq = KB.parseAsk(text);
    if (kq) { const ctx = await KB.context(kq); if (!ctx) { deliver(tx(T3("I found nothing in your files. Add some in ⚙ → AI & App → My files.", "Tumhari files me nahi mila. ⚙ → AI & App → My files me add karo.", "फ़ाइलों में नहीं मिला।"), l), "thinking", false, l); return; } text = ctx; }
    else if (WEB_Q.test(text) && navigator.onLine && cfg.key) {
      Pet.setEmotion("thinking", 20000); say("…", 20000);
      try { const out = await geminiOnce([{ text: text + "\nAnswer in Hinglish, short and clear, using fresh web information." }], { tools: [{ google_search: {} }], max: 500 }); deliver(out, "happy", false, l); return; } catch (e) { /* fall through to a normal answer */ }
    }
    if (Plugins.list.length) { const po = await Plugins.tryHandle(text); if (po) { deliver(po, "happy", false, l); return; } }
    const useOffline = cfg.offReady && cfg.offUse;
    if (!navigator.onLine || !hasKey()) {
      if (useOffline) { try { await answerOffline(text, l, afterSpeech); } catch (e) { TTS.stop(); deliver(tx(OFFAI_FAIL, l), "sad", false, l); } return; }
      deliver(tx(!navigator.onLine ? OFFLINE_MSG : NOKEY_MSG, l), !navigator.onLine ? "sad" : "thinking", false, l); return;
    }
    Pet.setEmotion("thinking", 20000); say("…", 20000);
    TTS.begin(); const sp = makeSpeaker(l); let emoSet = false, fake = false;
    const raw = await askGemini(text, l, (acc) => {                         // streaming: show + speak as it arrives
      if (/^\s*\[[a-z]*$/i.test(acc)) return;                               // tag still arriving
      const [t, e] = parseTag(acc);
      if (!emoSet) { emoSet = true; Pet.setEmotion(e, 12000); if (!cfg.speak) { fake = true; Pet.speaking = true; } }
      say(t, 25000); sp.feed(t, false);
    });
    const [reply, emo] = parseTag(raw);
    Pet.setEmotion(emo, Math.min(9000, 3000 + reply.length * 45)); say(reply); logChat("bot", reply); sp.feed(reply, true);
    if (fake) setTimeout(() => (Pet.speaking = false), Math.min(3500, reply.length * 40));
    afterSpeech();
  } catch (e) {
    TTS.stop();
    const msg = String(e && e.message || e);
    if (msg !== "key" && cfg.offReady && cfg.offUse) { try { await answerOffline(text, l, afterSpeech); return; } catch (e2) { TTS.stop(); } }   // online failed -> offline brain
    if (msg === "key") deliver(tx(T3("Gemini rejected my key. Please check it in ⚙ → AI & App.", "Gemini ne key accept nahi ki. ⚙ → AI & App me check karo.", "Gemini ने key स्वीकार नहीं की। ⚙ → AI & App में जाँचो।"), l), "confused", false, l);
    else deliver(tx(OFFLINE_MSG, l), "sad", false, l);
  } finally { busy = false; }
}
function haptic(ms) { if (NATIVE) { nat("vibrate", ms); return; } try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} }

/* chat log (so long answers are never lost) */
const chatLog = jget("haa_log", []);
function logChat(role, text) { chatLog.push({ r: role, t: Date.now(), text: String(text).slice(0, 1500) }); while (chatLog.length > 120) chatLog.shift(); jset("haa_log", chatLog); }
function renderLog() {
  const box = $("#log"); box.innerHTML = "";
  if (!chatLog.length) { box.innerHTML = '<p class="hint">Abhi koi baat-cheet nahi hui.</p>'; return; }
  chatLog.forEach((m) => { const d = document.createElement("div"); d.className = "msg " + m.r; d.textContent = m.text; const t = document.createElement("small"); t.textContent = new Date(m.t).toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" }); d.appendChild(t); box.appendChild(d); });
  box.scrollTop = box.scrollHeight;
}

/* small in-app dialog (nicer than the browser's prompt(); works inside the installed app) */
function ask(title, fields, imgUrl) {
  return new Promise((res) => {
    const dlg = $("#dlg"), f = $("#dlg-f"); $("#dlg-t").textContent = title; f.innerHTML = "";
    const im = $("#dlg-img"); im.hidden = !imgUrl; if (imgUrl) im.src = imgUrl;
    const els = {};
    fields.forEach((x) => {
      const lab = document.createElement("label"); lab.textContent = x.label; let el;
      if (x.type === "select") { el = document.createElement("select"); x.options.forEach(([v, t]) => { const o = document.createElement("option"); o.value = v; o.textContent = t; el.appendChild(o); }); }
      else { el = document.createElement("input"); el.type = "text"; el.placeholder = x.placeholder || ""; }
      el.value = x.value || ""; lab.appendChild(el); f.appendChild(lab); els[x.id] = el;
    });
    const done = (ok) => { dlg.hidden = true; $("#dlg-ok").onclick = $("#dlg-no").onclick = null; res(ok ? Object.fromEntries(Object.entries(els).map(([k, e]) => [k, e.value.trim()])) : null); };
    $("#dlg-ok").onclick = () => done(true); $("#dlg-no").onclick = () => done(false);
    dlg.hidden = false; const first = f.querySelector("input,select"); first && setTimeout(() => first.focus(), 50);
  });
}

/* ------------------------------------------------------------------ settings UI */
function showTab(id) { document.querySelectorAll(".tabs button,.tab").forEach((x) => x.classList.remove("on")); const b = document.querySelector(`.tabs button[data-tab="${id}"]`); b && b.classList.add("on"); $("#" + id).classList.add("on"); if (id === "t-log") renderLog(); if (id === "t-tasks") renderTasks(); if (id === "t-help") renderHelp(); }
function openSheet(tab) { fillSettings(); $("#sheet").hidden = false; renderGallery(); showTab(typeof tab === "string" ? tab : "t-me"); }
function closeSheet() { $("#sheet").hidden = true; }
let offErr = "";
function offUi() {
  const ok = cfg.offReady; $("#offdl").hidden = ok; $("#offrm").hidden = !ok; $("#offuse").parentElement.hidden = !ok;
  $("#offmsg").textContent = offErr ? offErr : ok ? "✅ Offline AI installed. Internet na ho (ya key na ho) to wahi jawab dega." : (navigator.gpu ? "Aapka phone fast mode (WebGPU) support karta hai." : "Normal mode (thoda dheema, par chalega).");
}
function fillSettings() {
  offUi(); $("#offuse").checked = cfg.offUse;
  $("#s-user").value = cfg.user; $("#s-asst").value = cfg.asst; $("#s-lang").value = cfg.lang; $("#s-pro").value = cfg.pro;
  $("#s-speak").checked = cfg.speak; $("#s-conv").checked = cfg.conv; $("#s-stt").value = cfg.stt; $("#s-rate").value = cfg.rate;
  $("#s-key").value = cfg.key; $("#s-model").value = cfg.model; $("#s-okey").value = cfg.okey || ""; $("#s-ckey").value = cfg.ckey || ""; $("#s-order").value = cfg.order || "gemini,openai,claude"; $("#s-mem").checked = cfg.memOn !== false; renderBrainExtras(); $("#ver").textContent = `Anime AI Buddy ${NATIVE ? "Android app" : "mobile"} v${APP_VERSION}`;
  $("#iosnote").hidden = NATIVE || !/iphone|ipad/i.test(navigator.userAgent); renderAndroid();
}
function readSettings() {
  cfg.user = $("#s-user").value.trim(); cfg.asst = $("#s-asst").value.trim(); cfg.lang = $("#s-lang").value; cfg.pro = $("#s-pro").value;
  cfg.speak = $("#s-speak").checked; cfg.conv = $("#s-conv").checked; cfg.stt = $("#s-stt").value; cfg.rate = Number($("#s-rate").value) || 1;
  cfg.offUse = $("#offuse").checked; cfg.key = $("#s-key").value.trim(); cfg.model = $("#s-model").value.trim() || DEFAULTS.model; cfg.okey = $("#s-okey").value.trim(); cfg.ckey = $("#s-ckey").value.trim(); cfg.order = $("#s-order").value; cfg.memOn = $("#s-mem").checked; Object.keys(provDown).forEach((k) => delete provDown[k]); saveCfg(); updateStatus();
}
function renderGallery() {
  const g = $("#gallery"); g.innerHTML = "";
  CHARS.forEach((c) => {
    const d = document.createElement("div"); d.className = "card" + (c.id === cfg.char ? " sel" : "");
    const im = document.createElement("img"); im.loading = "lazy";
    im.src = c.mine ? (c._url || (c._url = URL.createObjectURL(c.blob))) : c.type === "vector" ? `chars/${c.id}/happy.svg` : `chars/${c.id}/${c.file}`;
    d.appendChild(im); const s = document.createElement("small"); s.textContent = c.name; d.appendChild(s);
    const gt = document.createElement("span"); gt.className = "g"; gt.textContent = c.gender === "boy" ? "♂" : "♀"; d.appendChild(gt);
    if (c.mine) { const x = document.createElement("button"); x.className = "del"; x.textContent = "✕"; x.type = "button"; x.onclick = async (ev) => { ev.stopPropagation(); if (!confirm(`Remove ${c.name}?`)) return; await DB.del(c.id); await loadChars(); if (cfg.char === c.id) setChar(CHARS[0].id); renderGallery(); }; d.appendChild(x); }
    d.onclick = () => { setChar(c.id); renderGallery(); Pet.setEmotion("happy", 3000); say(tx(T3(`Hi, I'm ${nm()}!`, `Hi, main ${nm()} hoon!`, `हाय, मैं ${nm()} हूँ!`), lastLang), 2500); };
    g.appendChild(d);
  });
}

/* import any image: decode -> remove flat background (or soft card) -> store */
async function decodeImage(file) {
  if (window.createImageBitmap) { try { return await createImageBitmap(file); } catch (e) {} }
  return new Promise((res, rej) => { const u = URL.createObjectURL(file), im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = u; });
}
function removeFlatBackground(cv) {
  const ctx = cv.getContext("2d"), w = cv.width, h = cv.height, id = ctx.getImageData(0, 0, w, h), d = id.data;
  const px = (x, y) => { const i = (y * w + x) * 4; return [d[i], d[i + 1], d[i + 2]]; };
  const border = []; for (let x = 0; x < w; x++) { border.push(px(x, 0), px(x, h - 1)); } for (let y = 0; y < h; y++) { border.push(px(0, y), px(w - 1, y)); }
  const med = (k) => border.map((c) => c[k]).sort((a, b) => a - b)[border.length >> 1];
  const ref = [med(0), med(1), med(2)], tol = 76;
  const close = (c) => Math.abs(c[0] - ref[0]) + Math.abs(c[1] - ref[1]) + Math.abs(c[2] - ref[2]) <= tol;
  if (border.filter(close).length < 0.85 * border.length) return false;
  const seen = new Uint8Array(w * h), st = []; let cnt = 0;
  const push = (x, y) => { const k = y * w + x; if (!seen[k] && close(px(x, y))) { seen[k] = 1; st.push(k); } };
  for (let x = 0; x < w; x++) { push(x, 0); push(x, h - 1); } for (let y = 0; y < h; y++) { push(0, y); push(w - 1, y); }
  while (st.length) { const k = st.pop(); cnt++; const x = k % w, y = (k / w) | 0; d[k * 4 + 3] = 0; if (x > 0) push(x - 1, y); if (x < w - 1) push(x + 1, y); if (y > 0) push(x, y - 1); if (y < h - 1) push(x, y + 1); }
  if (cnt < w * h * 0.03 || cnt > w * h * 0.85) return false;
  ctx.putImageData(id, 0, 0); return true;
}
async function importImage(file, name, gender, persona) {
  const bmp = await decodeImage(file); const sw = bmp.width || bmp.naturalWidth, sh = bmp.height || bmp.naturalHeight;
  const k = Math.min(1, 560 / Math.max(sw, sh)), w = Math.round(sw * k), h = Math.round(sh * k);
  const cv = document.createElement("canvas"); cv.width = w; cv.height = h; const ctx = cv.getContext("2d"); ctx.drawImage(bmp, 0, 0, w, h);
  if (!removeFlatBackground(cv)) {                    // busy background: keep the scene as a rounded "sticker"
    const c2 = document.createElement("canvas"); c2.width = w; c2.height = h; const x2 = c2.getContext("2d"), r = Math.min(w, h) * 0.12;
    x2.beginPath(); x2.moveTo(r, 0); x2.arcTo(w, 0, w, h, r); x2.arcTo(w, h, 0, h, r); x2.arcTo(0, h, 0, 0, r); x2.arcTo(0, 0, w, 0, r); x2.closePath(); x2.clip(); x2.drawImage(cv, 0, 0);
    cv.getContext("2d").clearRect(0, 0, w, h); cv.getContext("2d").drawImage(c2, 0, 0);
  }
  const blob = await new Promise((res) => cv.toBlob(res, "image/webp", 0.9)) ;
  const id = "my_" + Date.now() + "_" + Math.floor(Math.random() * 999);
  await DB.put({ id, name, gender, personality: persona || "friendly and expressive", blob });
  return id;
}
async function handleFiles(files) {
  let last = null;
  for (const f of files) {
    const url = URL.createObjectURL(f);
    try {
      const base = f.name.replace(/\.[^.]+$/, "").slice(0, 24) || "My character";
      const v = await ask("New character", [
        { id: "name", label: "Name", value: base },
        { id: "gender", label: "Boy or girl?", type: "select", value: "girl", options: [["girl", "Girl ♀"], ["boy", "Boy ♂"]] },
        { id: "persona", label: "Personality (optional)", placeholder: "shy, cheerful, cool…" },
      ], url);
      if (!v || !v.name) continue;
      last = await importImage(f, v.name, v.gender, v.persona);
    } catch (e) { toast("Couldn't use " + f.name); }
    finally { URL.revokeObjectURL(url); }
  }
  if (last) { await loadChars(); setChar(last); renderGallery(); toast("✨ Character added"); }
}

/* ------------------------------------------------------------------ PWA: install + auto-update */
let deferredInstall = null;
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault(); deferredInstall = e; $("#installbtn").hidden = false;
  const box = $("#chips"); if (box && !$("#chip-install")) {
    const b = document.createElement("button"); b.id = "chip-install"; b.type = "button"; b.textContent = "📲 Install app"; b.style.background = "#ffd1e8";
    b.onclick = async () => { if (!deferredInstall) return; deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall = null; b.remove(); }; box.prepend(b);
  }
});
window.addEventListener("appinstalled", () => { $("#installbtn").hidden = true; const c = $("#chip-install"); c && c.remove(); toast("Installed ✨"); });
/* ------------------------------------------------------------------ Android app extras */
function verNewer(a, b) { const x = String(a).split(".").map(Number), y = String(b).split(".").map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; }
async function checkApkUpdate(manual) {
  if (!NATIVE) return;
  try {
    const info = await (await fetch("buildinfo.json", { cache: "no-store" })).json();
    if (!info.repo) { manual && toast("Update ka repo set nahi hai"); return; }
    if (!navigator.onLine) { manual && toast("Internet nahi hai"); return; }
    const r = await fetch(`https://api.github.com/repos/${info.repo}/releases/latest`, { headers: { Accept: "application/vnd.github+json" } });
    if (!r.ok) throw new Error("http " + r.status);
    const j = await r.json(), ver = String(j.tag_name || "").replace(/^v/, ""), ap = (j.assets || []).find((x) => /\.apk$/i.test(x.name));
    if (!ap || !verNewer(ver, APP_VERSION)) { manual && toast("Aap latest version par ho ✅"); return; }
    window.__apkUpd = { ver, url: ap.browser_download_url };
    if (manual || !sessionStorage.getItem("haa_updasked")) {
      try { sessionStorage.setItem("haa_updasked", "1"); } catch (e) {}
      if (confirm(`Naya version ${ver} mila (abhi ${APP_VERSION}). Download karke install karein?`)) { toast("Download ho raha hai… notification dekho", 5000); nat("install", ap.browser_download_url); }
    }
  } catch (e) { manual && toast("Update check nahi ho paya"); }
}
function offerOverlay() {
  if (!cfg.introduced) { setTimeout(offerOverlay, 8000); return; }       // let the first-run guide finish first
  try {
    const st = JSON.parse(Native.getState());
    if (st.overlay || cfg.ovOffered) return;
    cfg.ovOffered = true; saveCfg();
    if (confirm("Main aapke poore phone par sab apps ke upar ghoom sakti hoon, aur phone restart hone par bhi khud aa jaungi. Chalu karein?")) setOverlay(true);
  } catch (e) {}
}
function setOverlay(on) {
  let r = "err"; try { r = String(Native.setOverlay(!!on)); } catch (e) {}
  if (r === "perm") toast("Settings me “Display over other apps” ko Allow karo, phir wapas aao. Main khud shuru ho jaungi 💕", 7000);
  if (r === "ok") {
    toast("Pet chalu! Ab Home dabao: main sab apps ke upar milungi 💕", 4500);
    setTimeout(() => { try { Native.goHome(); } catch (e) {} }, 2200);
    setTimeout(() => { try { if (!JSON.parse(Native.getState()).running) toast("Pet start nahi hua. ⚙ → AI & App → Android dekho.", 6000); } catch (e) {} renderAndroid(); }, 3500);
  }
  renderAndroid(); return r;
}
function renderAndroid() {
  const box = $("#androidbox"); if (!box) return; box.hidden = !NATIVE || OVERLAY; if (!NATIVE) return;
  let st = {}; try { st = JSON.parse(Native.getState()); } catch (e) {}
  $("#a-overlay").checked = !!st.overlay; $("#a-auto").checked = !!st.autostart; $("#a-wander").checked = st.wander !== false;
  let chip = $("#chip-overlay");
  if (!OVERLAY && !st.running) {                      // a permanent, obvious way to switch the floating pet on
    if (!chip && $("#chips")) { chip = document.createElement("button"); chip.id = "chip-overlay"; chip.type = "button"; chip.textContent = "📱 Pet ko poore phone par chalao"; chip.style.background = "#ffd1e8"; chip.onclick = () => setOverlay(true); $("#chips").prepend(chip); }
  } else if (chip) chip.remove();
  const ok = (b) => (b ? "✅" : "❌");
  $("#a-diag").textContent = `${st.maker || ""}\nPet service: ${st.running ? "▶ chal raha hai" : "⏹ band"} | Pet ki image: ${st.ready ? "✅ screen par" : st.running ? "⏳ load nahi hui" : "-"}${st.err ? "\n⚠ Last error: " + st.err : ""}`;
  $("#a-state").textContent = `${ok(st.a11y)} Screen control   ${ok(st.perm)} Display over apps   ${ok(st.mic)} Mic   ${ok(st.notif)} Notifications   ${ok(st.contacts)} Contacts   ${ok(st.battery)} Battery unrestricted`;
}
window.__permResult = renderAndroid;
window.__hidden = (h) => { window.__ovHidden = !!h; if (h) { TTS.stop(); Voice.stop(); } };
window.__petTap = () => { if (Agent.running) { Agent.stop = true; return; } Brain.touched(); haptic(10); addBond(1); if (Pet.speaking || TTS.pending) { TTS.stop(); return; } Voice.toggle(); };
window.__petWalk = (dir) => {                         // the floating window is strolling across the screen
  if (dir) { Pet.walkOverlay = true; Pet.mode = "walk"; Pet.facing = dir; }
  else { Pet.walkOverlay = false; if (Pet.mode === "walk") Pet.mode = "idle"; }
};
window.__petHeld = (on) => { if (on) { Pet.mode = "held"; Pet.setEmotion("surprised", 1500); } else { Pet.mode = "idle"; Pet.setEmotion("happy", 1500); } };
window.__nativeReminder = (id, text) => Reminders.fire({ id, text });
window.__back = () => {
  if (!$("#dlg").hidden) { $("#dlg-no").click(); return true; }
  if (!$("#sheet").hidden) { $("#closesheet").click(); return true; }
  return false;
};
window.__resync = async () => {                      // the app and the floating pet are two windows: pick up each other's changes
  try {
    Object.assign(cfg, jget("haa_cfg", {}));
    chatLog.length = 0; jget("haa_log", []).forEach((x) => chatLog.push(x));
    history.length = 0; jget("haa_hist", []).forEach((x) => history.push(x));
    offHist.length = 0; jget("haa_offhist", []).forEach((x) => offHist.push(x));
    Brain.journal = jget("haa_journal", []); Reminders.list = jget("haa_rem", []);
    Store.tasks = jget("haa_tasks", []); Store.notes = jget("haa_notes", []);
    await loadChars(); if (!CHAR || CHAR.id !== cfg.char) setChar(cfg.char);
    updateStatus(); renderAndroid();
  } catch (e) {}
};
async function setupSW() {
  if (!("serviceWorker" in navigator)) return;
  try {
    const reg = await navigator.serviceWorker.register("sw.js");
    const check = () => reg.update().catch(() => {});
    document.addEventListener("visibilitychange", () => !document.hidden && check());
    setInterval(check, 30 * 60 * 1000);
    let had = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (!had) { had = true; return; }                 // first install, nothing to refresh
      if (sessionStorage.getItem("haa_reloaded")) return;
      sessionStorage.setItem("haa_reloaded", "1"); toast("✨ Updated! Restarting…", 1200); setTimeout(() => location.reload(), 900);
    });
    window.__checkUpdate = async () => { toast("Checking…"); try { await reg.update(); await sleep(1500); toast(reg.installing || reg.waiting ? "Update found, installing…" : "You're on the latest version ✨"); } catch (e) { toast("Couldn't check (offline?)"); } };
    sessionStorage.removeItem("haa_reloaded_done");
  } catch (e) { console.warn("SW failed", e); }
}

/* tasks & notes tab */
function renderTasks() {
  const box = $("#tasklist"); box.innerHTML = "";
  if (!Store.tasks.length) box.innerHTML = '<p class="hint">Koi task nahi. Upar likho ya bolo: “task add doodh lana”.</p>';
  Store.tasks.forEach((t, i) => {
    const d = document.createElement("label"); d.className = "task" + (t.done ? " done" : "");
    const c = document.createElement("input"); c.type = "checkbox"; c.checked = t.done; c.onchange = () => { t.done = c.checked; Store.save(); renderTasks(); if (t.done) { Pet.setEmotion("love", 3000); addBond(1); } };
    const sp = document.createElement("span"); sp.textContent = `${i + 1}. ${t.text}`;
    const x = document.createElement("button"); x.type = "button"; x.textContent = "✕"; x.onclick = (e) => { e.preventDefault(); Store.tasks.splice(i, 1); Store.save(); renderTasks(); };
    d.append(c, sp, x); box.appendChild(d);
  });
  const nb = $("#notelist"); nb.innerHTML = "";
  Store.notes.slice().reverse().forEach((n) => {
    const d = document.createElement("div"); d.className = "task"; const sp = document.createElement("span"); sp.textContent = "📝 " + n.text;
    const x = document.createElement("button"); x.type = "button"; x.textContent = "✕"; x.onclick = () => { Store.notes = Store.notes.filter((q) => q !== n); Store.save(); renderTasks(); };
    d.append(sp, x); nb.appendChild(d);
  });
}
const HELP = [
  ["🗣 Baat-cheet", ["hello", "tell me a joke", "mujhe kuch interesting batao"]],
  ["⏰ Reminder / Alarm", ["10 minute baad chai yaad dilana", "kal subah 7 baje alarm", "remind me at 6 pm to call mom", "mere reminders dikhao"]],
  ["✅ Tasks & Notes", ["task add doodh lana", "mere kaam dikhao", "task 1 done", "note: wifi password 1234", "mere notes dikhao"]],
  ["🎯 Focus", ["focus mode 25 minute", "stop focus"]],
  ["🌐 Apps & Search", ["youtube kholo", "whatsapp kholo", "google pe python tutorial search karo", "gaana chalao arijit singh", "call 9876543210"]],
  ["ℹ️ Info", ["time kya hua", "aaj ki date", "mausam kaisa hai", "battery kitni hai", "2+2*5"]],
  ["🎲 Masti", ["flip a coin", "dice roll karo", "next character", "i love you"]],
  ["🕵️ Memory", ["maine kya kiya", "kya kar raha tha"]],
];
function renderHelp() {
  const box = $("#helplist"); box.innerHTML = "";
  HELP.forEach(([title, ex]) => {
    const h = document.createElement("div"); h.className = "hh"; h.textContent = title; box.appendChild(h);
    const row = document.createElement("div"); row.className = "chiprow";
    ex.forEach((e) => { const b = document.createElement("button"); b.type = "button"; b.textContent = e; b.onclick = () => { closeSheet(); setTimeout(() => submit(e), 250); }; row.appendChild(b); });
    box.appendChild(row);
  });
}

/* 3-step welcome wizard: name -> character -> optional AI key */
function runWizard() {
  return new Promise((res) => {
    const W = $("#wiz"), body = $("#wiz-body"), dots = $("#wiz-dots"); W.hidden = false; let step = 0;
    const draw = () => {
      dots.textContent = ["●○○", "○●○", "○○●"][step]; body.innerHTML = "";
      const h = document.createElement("h2"), p = document.createElement("p"); p.className = "hint"; body.append(h, p);
      if (step === 0) {
        h.textContent = "👋 Namaste! Aapka naam?"; p.textContent = "Main aapki anime dost hoon. Pehle naam batao.";
        const i = document.createElement("input"); i.type = "text"; i.id = "wz-name"; i.placeholder = "jaise Suraj"; i.value = cfg.user; i.autocomplete = "off"; body.appendChild(i); setTimeout(() => i.focus(), 100);
      } else if (step === 1) {
        h.textContent = "Apna saathi chuno 💞"; p.textContent = "Baad me ⚙ → Characters se badal sakte ho, ya apni image bhi daal sakte ho.";
        const g = document.createElement("div"); g.id = "wz-grid";
        CHARS.filter((c) => !c.mine).forEach((c) => {
          const d = document.createElement("div"); d.className = "card" + (c.id === cfg.char ? " sel" : "");
          const im = document.createElement("img"); im.src = c.type === "vector" ? `chars/${c.id}/happy.svg` : `chars/${c.id}/${c.file}`; const sm = document.createElement("small"); sm.textContent = c.name;
          d.append(im, sm); d.onclick = () => { setChar(c.id); [...g.children].forEach((x) => x.classList.remove("sel")); d.classList.add("sel"); }; g.appendChild(d);
        });
        body.appendChild(g);
      } else {
        h.textContent = "Smart baat-cheet (optional) 🧠"; p.innerHTML = "Bina key ke bhi time, reminder, tasks, apps sab chalta hai. Gappe maarne ke liye free Gemini key daalo. <b>Skip bhi kar sakte ho.</b>";
        const i = document.createElement("input"); i.type = "password"; i.id = "wz-key"; i.placeholder = "AIza… (optional)"; i.autocomplete = "off"; i.value = cfg.key; body.appendChild(i);
        const a = document.createElement("button"); a.type = "button"; a.className = "lnk"; a.textContent = "🔑 Free key kaise milegi?"; a.onclick = () => openUrl("https://aistudio.google.com/apikey"); body.appendChild(a);
      }
      $("#wiz-next").textContent = step === 2 ? "Shuru karo 🚀" : "Aage ➜"; $("#wiz-skip").hidden = step !== 2; $("#wiz-back").hidden = step === 0;
    };
    const finish = () => { cfg.introduced = true; saveCfg(); W.hidden = true; res(); };
    $("#wiz-next").onclick = () => {
      if (step === 0) cfg.user = ($("#wz-name").value || "").trim();
      if (step === 2) { cfg.key = ($("#wz-key").value || "").trim(); saveCfg(); updateStatus(); return finish(); }
      saveCfg(); step++; draw();
    };
    $("#wiz-back").onclick = () => { step = Math.max(0, step - 1); draw(); };
    $("#wiz-skip").onclick = finish; draw();
  });
}

/* quick-action chips: discoverable shortcuts */
function buildChips() {
  const items = [
    ["📎", T3("Ask a file", "File se poocho", "फ़ाइल से पूछो"), () => $("#askfile").click()],
    ["🕒", T3("Time", "Time", "समय"), () => submit(tx(T3("what's the time", "time kya hua", "समय क्या हुआ"), lastLang))],
    ["🎧", T3("Hands-free", "Hands-free", "हैंड्स-फ्री"), () => { cfg.conv = !cfg.conv; saveCfg(); toast(cfg.conv ? "🎧 Hands-free ON: jawab ke baad main khud sunungi. Band karne ko phir dabao." : "Hands-free OFF"); if (cfg.conv) Voice.start(); }],
    ["⏰", T3("5-min timer", "5 min timer", "5 मिनट टाइमर"), () => submit("5 minute baad timer")],
    ["🌦", T3("Weather", "Mausam", "मौसम"), () => submit("mausam kaisa hai")],
    ["😂", T3("Joke", "Joke", "चुटकुला"), () => submit("joke sunao")],
    ["🎵", T3("Play music", "Gaana", "गाना"), () => { const i = $("#input"); i.value = "gaana chalao "; i.focus(); }],
    ["✅", T3("Tasks", "Tasks", "टास्क"), () => openSheet("t-tasks")],
    ["🎯", T3("Focus 25", "Focus 25", "फोकस 25"), () => submit("focus mode 25 minute")],
    ["🔎", T3("Search", "Search", "सर्च"), () => { const i = $("#input"); i.value = "search "; i.focus(); }],
    ["🔋", T3("Battery", "Battery", "बैटरी"), () => submit("battery kitni hai")],
  ];
  const box = $("#chips"); box.innerHTML = "";
  items.forEach(([ic, lab, fn]) => { const b = document.createElement("button"); b.type = "button"; b.textContent = ic + " " + lab.hinglish; b.onclick = () => { Brain.touched(); fn(); }; box.appendChild(b); });
}

/* ------------------------------------------------------------------ boot */
function wireUI() {
  $("#bar").addEventListener("submit", (e) => { e.preventDefault(); const v = $("#input").value; $("#input").value = ""; submit(v); });
  $("#micbtn").addEventListener("click", () => Voice.toggle());
  $("#menubtn").addEventListener("click", () => openSheet());
  $("#closesheet").addEventListener("click", () => { readSettings(); closeSheet(); });
  $("#savebtn").addEventListener("click", () => { readSettings(); closeSheet(); toast("Saved ✨"); });
  document.querySelectorAll(".tabs button").forEach((b) => b.addEventListener("click", () => {
    showTab(b.dataset.tab);
  }));
  $("#logbtn").addEventListener("click", () => openSheet("t-log"));
  $("#helpbtn").addEventListener("click", () => openSheet("t-help"));
  const addTaskFromBox = () => { const v = $("#taskin").value.trim(); if (!v) return; Store.addTask(v); $("#taskin").value = ""; renderTasks(); };
  $("#taskadd").addEventListener("click", addTaskFromBox); $("#taskin").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); addTaskFromBox(); } });
  $("#clearlog").addEventListener("click", () => { chatLog.length = 0; jset("haa_log", chatLog); renderLog(); });
  buildChips();
  $("#addchar").addEventListener("click", () => $("#file").click());
  $("#file").addEventListener("change", (e) => { const f = [...e.target.files]; e.target.value = ""; handleFiles(f); });
  $("#testvoice").addEventListener("click", () => { readSettings(); TTS.speak(tx(T3("Hello! This is how I sound.", "Hello! Main aisi sunai deti hoon.", "नमस्ते! मैं ऐसी सुनाई देती हूँ।"), detectLang(cfg.lang === "auto" ? "hello" : cfg.lang)), cfg.lang === "auto" ? "en" : cfg.lang); });
  $("#offdl").addEventListener("click", async () => {
    if (!navigator.onLine) { toast("Pehle internet chalu karo (Wi-Fi best hai)"); return; }
    offErr = ""; const bar = $("#offbar"), msg = $("#offmsg"); bar.hidden = false; bar.value = 0; $("#offdl").disabled = true; msg.textContent = "Download shuru… (~400 MB, app band mat karna)";
    try {
      await OffAI.load((p, got, tot) => { bar.value = p; msg.textContent = `Downloading… ${p}%  (${(got / 1048576).toFixed(0)} / ${(tot / 1048576).toFixed(0)} MB)`; });
      cfg.offReady = true; saveCfg(); toast("✨ Offline AI ready"); 
    } catch (e) { offErr = "❌ Download nahi hua: " + String(e.message || e).slice(0, 110) + " — internet check karke phir try karo."; }
    finally { bar.hidden = true; $("#offdl").disabled = false; offUi(); }
  });
  $("#offrm").addEventListener("click", async () => {
    if (!confirm("Offline AI hata dein? (storage khaali ho jayega)")) return;
    try { if (OffAI.w) { OffAI.w.terminate(); OffAI.w = null; OffAI.loaded = false; } (await caches.keys()).filter((k) => /transformers/i.test(k)).forEach((k) => caches.delete(k)); } catch (e) {}
    cfg.offReady = false; saveCfg(); offUi();
  });
  $("#bkexp").addEventListener("click", () => {
    const o = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k.startsWith("haa_")) o[k] = localStorage.getItem(k); }
    try { const c = JSON.parse(o.haa_cfg || "{}"); delete c.key; o.haa_cfg = JSON.stringify(c); } catch (e) {}        // never put your API key in a backup file
    const json = JSON.stringify({ app: "haa", v: APP_VERSION, data: o });
    if (NATIVE) { const r = String(Native.saveFile("anime-ai-buddy-backup.json", json)); toast(r === "ok" ? "Backup Downloads folder me save ho gayi ✅" : "Backup save nahi hui", 4000); return; }
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([json], { type: "application/json" }));
    a.download = "anime-ai-buddy-backup.json"; document.body.appendChild(a); a.click(); a.remove(); toast("Backup file ban gayi ✅");
  });
  $("#bkimp").addEventListener("click", () => $("#bkfile").click());
  $("#bkfile").addEventListener("change", async (e) => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    try {
      const j = JSON.parse(await f.text()); if (j.app !== "haa" || !j.data) throw new Error("bad");
      const keep = [cfg.key, cfg.okey, cfg.ckey]; Object.entries(j.data).forEach(([k, v]) => k.startsWith("haa_") && localStorage.setItem(k, v));
      try { const c = JSON.parse(localStorage.getItem("haa_cfg") || "{}"); c.key = keep[0] || c.key || ""; c.okey = keep[1] || c.okey || ""; c.ckey = keep[2] || c.ckey || ""; localStorage.setItem("haa_cfg", JSON.stringify(c)); } catch (e2) {}
      toast("Restore ho gaya ✅"); setTimeout(() => location.reload(), 900);
    } catch (err) { toast("Ye valid backup file nahi hai"); }
  });
  $("#installbtn").addEventListener("click", async () => { if (!deferredInstall) return; deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall = null; $("#installbtn").hidden = true; });
  const kbInfo = async () => { try { $("#kbinfo").textContent = (await KB.count()) + " hisse yaad hain."; } catch (e) {} };
  $("#kbadd").addEventListener("click", () => $("#kbfile").click());
  $("#kbfile").addEventListener("change", async (e) => { const fs = Array.from(e.target.files || []); e.target.value = ""; let n = 0; for (const f of fs) { try { n += await KB.add(f); } catch (er) {} } toast(n + " hisse add hue"); kbInfo(); });
  $("#kbclr").addEventListener("click", async () => { await KB.clear(); kbInfo(); });
  kbInfo();
  $("#askfile").addEventListener("change", async (e) => { const f = e.target.files && e.target.files[0]; e.target.value = ""; if (f) takeFile(f, f.name, f.type || "application/octet-stream", ""); });
  $("#updbtn").addEventListener("click", () => NATIVE ? checkApkUpdate(true) : window.__checkUpdate ? window.__checkUpdate() : toast("Updates need the installed app"));
  if (NATIVE) {
    $("#a-overlay").addEventListener("change", (e) => { const r = setOverlay(e.target.checked); if (r !== "ok" && r !== "off") e.target.checked = false; });
    $("#a-wander").addEventListener("change", (e) => { try { Native.setWander(e.target.checked); } catch (x) {} });
    $("#a-auto").addEventListener("change", (e) => { try { Native.setAutoStart(e.target.checked); } catch (x) {} });
    $("#a-clearerr").addEventListener("click", () => { try { Native.clearErr(); } catch (x) {} renderAndroid(); });
    $("#a-a11y").addEventListener("click", () => { nat("a11ysettings"); toast("Installed apps → Anime Buddy → ON. Na mile to: App info → ⋮ → Allow restricted settings", 7000); });
    [["a-details", "details"], ["a-mic", "mic"], ["a-notif", "notif"], ["a-contacts", "contacts"], ["a-batt", "battery"]].forEach(([id, w]) => $("#" + id).addEventListener("click", () => { try { Native.requestPerm(w); } catch (x) {} }));
    $("#installbtn").hidden = true;
  }
  $("#clearbtn").addEventListener("click", async () => { if (!confirm("Delete all settings, reminders, history and imported characters on this phone?")) return; try { localStorage.clear(); const rs = await navigator.serviceWorker.getRegistrations(); rs.forEach((r) => r.unregister()); (await caches.keys()).forEach((k) => caches.delete(k)); indexedDB.deleteDatabase("haa"); } catch (e) {} location.reload(); });
  window.addEventListener("online", updateStatus); window.addEventListener("offline", updateStatus);
  window.addEventListener("resize", () => { Pet.layout(); });
  window.addEventListener("orientationchange", () => setTimeout(() => Pet.layout(), 300));
}
async function boot() {
  await DB.open(); await loadChars();
  if (!NATIVE) TTS.init(); wireUI(); updateStatus(); skyForHour(); setInterval(skyForHour, 600000);
  if (OVERLAY) imgEl.addEventListener("load", () => { try { Native.overlayReady(); } catch (e) {} });     // tells the phone the pet is drawn
  setChar(cfg.char);
  Pet.layout(); requestAnimationFrame(loop);
  const missed = Reminders.init(); if (!NATIVE) setupSW();
  if (missed.length) setTimeout(() => deliver(tx(T3(`While the app was closed I missed: ${missed.map((r) => r.text || "alarm").join(", ")}.`, `App band tha isliye ye reminder chhoot gaye: ${missed.map((r) => r.text || "alarm").join(", ")}.`, `ऐप बंद था इसलिए ये रिमाइंडर छूट गए: ${missed.map((r) => r.text || "अलार्म").join(", ")}।`), lastLang), "sad", true), 3500);
  setInterval(() => Brain.tick(), 20000);
  const q = new URLSearchParams(location.search);
  if (OVERLAY) setTimeout(() => say(tx(T3("I'm here! Tap me to talk 💕", "Main yahin hoon! Mujhe tap karke bolo 💕"), lastLang), 4000), 1500);
  else if (!cfg.introduced) {
    setTimeout(async () => {
      await runWizard();
      say(`Hi ${you()}! ${tx(T3("Tap me to talk, or type below. Tap ❓ to see what I can do!", "Mujhe tap karke bolo ya neeche type karo. ❓ dabake dekho main kya-kya kar sakti hoon!"), "hinglish")}`, 8000);
    }, 700);
  } else setTimeout(() => Brain.greet(), 1200);
  const day = new Date().toDateString(); if (cfg.lastDay !== day) { cfg.lastDay = day; saveCfg(); addBond(5); }
  if (q.get("talk")) setTimeout(() => Voice.start(), 1500);
  if (NATIVE && !OVERLAY) {
    setTimeout(() => checkApkUpdate(false), 9000);
    setTimeout(() => window.__sharedPoll(), 2500);
    setTimeout(offerOverlay, 6500);
    setInterval(renderAndroid, 5000);
  }
  Brain.log("open", "app");
  window.__haa = { KB, PCLink, Plugins, Soul, weatherText, Store, parseClock, runWizard, OffAI, cfg, ask, chatLog, TTS, Pet, Brain, submit, localCommand, setChar, get CHAR() { return CHAR; }, CHARS: () => CHARS, detectLang, Reminders };
}
boot();

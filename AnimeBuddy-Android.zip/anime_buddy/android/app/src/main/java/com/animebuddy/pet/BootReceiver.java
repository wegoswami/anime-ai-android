package com.animebuddy.pet;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try {
            Remind.rearmAll(c);
            if (Prefs.autoStart(c) && Settings.canDrawOverlays(c)) {
                c.startForegroundService(new Intent(c, OverlayService.class));
            }
        } catch (Exception ignored) { }
    }
}

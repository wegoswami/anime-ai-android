package com.animebuddy.pet;

import android.Manifest;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Everything the web app can ask the phone to do. Exposed to JavaScript as window.Native. */
final class Bridge {
    private static boolean torchOn = false;

    private final Context ctx;
    private final WebView wv;
    private final boolean overlay;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private SpeechRecognizer sr;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final ArrayList<Runnable> ttsWaiting = new ArrayList<>();

    Bridge(Context ctx, WebView wv, boolean overlay) {
        this.ctx = ctx;
        this.wv = wv;
        this.overlay = overlay;
    }

    private void js(final String code) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                try {
                    wv.evaluateJavascript(code, null);
                } catch (Exception ignored) { }
            }
        });
    }

    void shutdown() {
        try { if (sr != null) sr.destroy(); } catch (Exception ignored) { }
        try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception ignored) { }
        sr = null;
        tts = null;
    }

    private boolean granted(String perm) {
        return ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean online() {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            return cm != null && cm.getActiveNetwork() != null;
        } catch (Exception e) {
            return true;
        }
    }

    /* ---------------------------------------------------------------- speech to text */

    private void sttEvent(String type, String text) {
        js("window.__nativeSTT&&__nativeSTT(" + JSONObject.quote(type) + "," + JSONObject.quote(text == null ? "" : text) + ")");
    }

    @JavascriptInterface
    public void startListening(final String lang) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                doListen(lang);
            }
        });
    }

    @JavascriptInterface
    public void stopListening() {
        ui.post(new Runnable() {
            @Override
            public void run() {
                try { if (sr != null) sr.stopListening(); } catch (Exception ignored) { }
            }
        });
    }

    private void doListen(String lang) {
        if (!granted(Manifest.permission.RECORD_AUDIO)) { sttEvent("error", "denied"); return; }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { sttEvent("error", "unavailable"); return; }
        try { if (sr != null) sr.destroy(); } catch (Exception ignored) { }
        sr = SpeechRecognizer.createSpeechRecognizer(ctx);
        sr.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { sttEvent("start", ""); }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onEvent(int eventType, Bundle params) { }

            @Override
            public void onError(int error) {
                String e;
                switch (error) {
                    case SpeechRecognizer.ERROR_NO_MATCH:
                    case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: e = "no-speech"; break;
                    case SpeechRecognizer.ERROR_NETWORK:
                    case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: e = "network"; break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: e = "denied"; break;
                    case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: e = "busy"; break;
                    case SpeechRecognizer.ERROR_CLIENT: e = "aborted"; break;
                    default: e = "error " + error;
                }
                sttEvent("error", e);
                sttEvent("end", "");
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) sttEvent("final", r.get(0));
                sttEvent("end", "");
            }

            @Override
            public void onPartialResults(Bundle partial) {
                ArrayList<String> r = partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) sttEvent("partial", r.get(0));
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang == null || lang.isEmpty() ? "hi-IN" : lang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.getPackageName());
        if (!online()) i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        try {
            sr.startListening(i);
        } catch (Exception e) {
            sttEvent("error", "busy");
        }
    }

    /* ---------------------------------------------------------------- text to speech */

    private void ttsEvent(String ev, int id) {
        js("window.__nativeTTS&&__nativeTTS(" + JSONObject.quote(ev) + "," + id + ")");
    }

    private void ensureTts() {
        if (tts != null) return;
        tts = new TextToSpeech(ctx.getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                ttsReady = status == TextToSpeech.SUCCESS;
                if (ttsReady) {
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override public void onStart(String utteranceId) { ttsEvent("start", num(utteranceId)); }
                        @Override public void onDone(String utteranceId) { ttsEvent("done", num(utteranceId)); }
                        @Override public void onError(String utteranceId) { ttsEvent("done", num(utteranceId)); }
                        @Override public void onStop(String utteranceId, boolean interrupted) { ttsEvent("done", num(utteranceId)); }
                    });
                }
                ArrayList<Runnable> w = new ArrayList<>(ttsWaiting);
                ttsWaiting.clear();
                for (Runnable r : w) ui.post(r);
            }
        });
    }

    private static int num(String s) {
        try { return Integer.parseInt(s); } catch (Exception e) { return -1; }
    }

    @JavascriptInterface
    public void speak(final String text, final String lang, final double pitch, final double rate, final int id) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                ensureTts();
                if (!ttsReady) {
                    if (tts != null) {
                        ttsWaiting.add(this);
                    }
                    return;
                }
                try {
                    Locale loc = "hi".equals(lang) ? new Locale("hi", "IN") : "hinglish".equals(lang) ? new Locale("en", "IN") : Locale.US;
                    int r = tts.setLanguage(loc);
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                        if ("hi".equals(lang)) tts.setLanguage(new Locale("en", "IN"));
                    }
                    tts.setPitch((float) pitch);
                    tts.setSpeechRate((float) rate);
                    tts.speak(text, TextToSpeech.QUEUE_ADD, null, String.valueOf(id));
                } catch (Exception e) {
                    ttsEvent("done", id);
                }
            }
        });
    }

    @JavascriptInterface
    public void stopSpeaking() {
        ui.post(new Runnable() {
            @Override
            public void run() {
                try { if (tts != null && ttsReady) tts.stop(); } catch (Exception ignored) { }
            }
        });
    }

    /* ---------------------------------------------------------------- reminders & notifications */

    @JavascriptInterface
    public void scheduleReminder(String id, double at, String text) {
        Remind.schedule(ctx.getApplicationContext(), id, (long) at, text);
    }

    @JavascriptInterface
    public void cancelReminder(String id) {
        Remind.cancel(ctx.getApplicationContext(), id);
    }

    @JavascriptInterface
    public void showNotification(String title, String body) {
        Notif.show(ctx.getApplicationContext(), title, body);
    }

    /* ---------------------------------------------------------------- the floating pet */

    @JavascriptInterface
    public void overlayBubble(final boolean show) {
        final OverlayService s = OverlayService.instance;
        if (s == null) return;
        ui.post(new Runnable() {
            @Override
            public void run() {
                s.setBubble(show);
            }
        });
    }

    @JavascriptInterface
    public void overlayReady() {
        final OverlayService s = OverlayService.instance;
        if (s == null) return;
        ui.post(new Runnable() {
            @Override
            public void run() {
                s.markReady();
            }
        });
    }

    @JavascriptInterface
    public void clearErr() {
        Prefs.sp(ctx.getApplicationContext()).edit().remove("err").apply();
    }

    @JavascriptInterface
    public void openApp() {
        Intent i = new Intent(ctx, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try { ctx.startActivity(i); } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public String setOverlay(final boolean on) {
        final Context app = ctx.getApplicationContext();
        if (on) {
            if (!Settings.canDrawOverlays(app)) {
                Prefs.sp(app).edit().putBoolean("want", true).apply();      // start by itself as soon as the permission is given
                ui.post(new Runnable() {
                    @Override
                    public void run() { openOverlaySettings(); }
                });
                return "perm";
            }
            if (!Prefs.sp(app).contains("autostart")) Prefs.setAutoStart(app, true);
            OverlayService.wanted = true;
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        app.startForegroundService(new Intent(app, OverlayService.class));
                    } catch (Exception e) {
                        OverlayService.wanted = false;
                    }
                }
            });
            return "ok";
        }
        OverlayService.wanted = false;
        ui.post(new Runnable() {
            @Override
            public void run() {
                app.stopService(new Intent(app, OverlayService.class));
            }
        });
        return "off";
    }

    private void openOverlaySettings() {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void setWander(boolean v) {
        Prefs.setWander(ctx.getApplicationContext(), v);
    }

    @JavascriptInterface
    public void goHome() {
        ui.post(new Runnable() {
            @Override
            public void run() {
                MainActivity a = MainActivity.current;
                if (a != null) a.moveTaskToBack(true);
            }
        });
    }

    @JavascriptInterface
    public void setAutoStart(boolean v) {
        Prefs.setAutoStart(ctx.getApplicationContext(), v);
    }

    @JavascriptInterface
    public void requestPerm(final String which) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                MainActivity a = MainActivity.current;
                if (a != null) a.requestFor(which);
            }
        });
    }

    @JavascriptInterface
    public String getState() {
        Context app = ctx.getApplicationContext();
        try {
            JSONObject o = new JSONObject();
            boolean perm = Settings.canDrawOverlays(app);
            o.put("overlay", perm && (OverlayService.wanted || OverlayService.instance != null));
            o.put("perm", perm);
            o.put("running", OverlayService.instance != null);
            o.put("wander", Prefs.wander(app));
            o.put("ready", OverlayService.ready);
            o.put("err", Prefs.sp(app).getString("err", ""));
            o.put("maker", Build.MANUFACTURER + " " + Build.MODEL + " (Android " + Build.VERSION.RELEASE + ")");
            o.put("autostart", Prefs.autoStart(app));
            o.put("mic", granted(Manifest.permission.RECORD_AUDIO));
            o.put("contacts", granted(Manifest.permission.READ_CONTACTS));
            o.put("notif", Build.VERSION.SDK_INT < 33 || granted("android.permission.POST_NOTIFICATIONS"));
            PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
            o.put("battery", pm != null && pm.isIgnoringBatteryOptimizations(app.getPackageName()));
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    /* ---------------------------------------------------------------- phone commands */

    @JavascriptInterface
    public String exec(String cmd, String arg) {
        try {
            if (arg == null) arg = "";
            switch (cmd) {
                case "url": return openUrl(arg);
                case "app": return launchByLabel(arg);
                case "dial": return start(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + arg)));
                case "call": return callContact(arg);
                case "torch": return torch(arg);
                case "volume": return volume(arg);
                case "settings": return settings(arg);
                case "vibrate": return vibrate(arg);
                case "battery": return battery();
                case "install": return installApk(arg);
                default: return "unknown";
            }
        } catch (Exception e) {
            return "err";
        }
    }

    private String start(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            ctx.startActivity(i);
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }

    private String openUrl(String url) {
        if (!(url.startsWith("https://") || url.startsWith("http://") || url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("geo:"))) return "err";
        return start(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private static String norm(String s) {
        return s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", "");
    }

    private String launchByLabel(String name) {
        String q = norm(name);
        if (q.isEmpty()) return "notfound";
        PackageManager pm = ctx.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        String bestPkg = null;
        int best = 0;
        for (ResolveInfo ri : apps) {
            String label = norm(String.valueOf(ri.loadLabel(pm)));
            if (label.isEmpty()) continue;
            int score = 0;
            if (label.equals(q)) score = 4;
            else if (label.startsWith(q) || (label.length() >= 3 && q.startsWith(label))) score = 3;
            else if (q.length() >= 3 && label.contains(q)) score = 2;
            else if (label.length() >= 4 && q.contains(label)) score = 1;
            if (score > best) {
                best = score;
                bestPkg = ri.activityInfo.packageName;
            }
        }
        if (bestPkg == null) return "notfound";
        Intent li = pm.getLaunchIntentForPackage(bestPkg);
        if (li == null) return "notfound";
        return start(li);
    }

    private String callContact(String name) {
        if (!granted(Manifest.permission.READ_CONTACTS)) return "perm";
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                    new String[]{"%" + name + "%"}, null);
            if (c != null && c.moveToFirst()) {
                String num = c.getString(0);
                return start(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))));
            }
        } finally {
            if (c != null) c.close();
        }
        return "notfound";
    }

    private String torch(String mode) {
        try {
            CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                Boolean flash = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (flash != null && flash) {
                    boolean on = "on".equals(mode) || ("toggle".equals(mode) && !torchOn);
                    cm.setTorchMode(id, on);
                    torchOn = on;
                    return "ok";
                }
            }
        } catch (Exception ignored) { }
        return "err";
    }

    private String volume(String mode) {
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return "err";
        if ("mute".equals(mode)) {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI);
        } else {
            int dir = "up".equals(mode) ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER;
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, 0);
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI);
        }
        return "ok";
    }

    private String settings(String what) {
        String action = "wifi".equals(what) ? Settings.ACTION_WIFI_SETTINGS : "bluetooth".equals(what) ? Settings.ACTION_BLUETOOTH_SETTINGS : Settings.ACTION_SETTINGS;
        return start(new Intent(action));
    }

    private String vibrate(String ms) {
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            long d = Math.max(5, Math.min(500, Long.parseLong(ms.trim())));
            if (v != null) v.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE));
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }

    private String battery() {
        Intent b = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b == null) return "err";
        int level = b.getIntExtra("level", -1), scale = b.getIntExtra("scale", 100);
        int plugged = b.getIntExtra("plugged", 0);
        if (level < 0) return "err";
        return (level * 100 / Math.max(1, scale)) + "|" + (plugged != 0 ? 1 : 0);
    }

    /* ---------------------------------------------------------------- self update (downloads the new APK from GitHub) */

    private String installApk(String url) {
        if (!url.startsWith("https://")) return "err";
        final Context app = ctx.getApplicationContext();
        if (!app.getPackageManager().canRequestPackageInstalls()) {
            Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + app.getPackageName()));
            start(i);
            return "perm";
        }
        final DownloadManager dm = (DownloadManager) app.getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request rq = new DownloadManager.Request(Uri.parse(url));
        rq.setTitle("Anime Buddy update");
        rq.setMimeType("application/vnd.android.package-archive");
        rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        rq.setDestinationInExternalFilesDir(app, Environment.DIRECTORY_DOWNLOADS, "AnimeBuddy-update.apk");
        final long id = dm.enqueue(rq);
        BroadcastReceiver done = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent in) {
                if (in.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != id) return;
                try { app.unregisterReceiver(this); } catch (Exception ignored) { }
                Uri apk = dm.getUriForDownloadedFile(id);
                if (apk == null) return;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(apk, "application/vnd.android.package-archive");
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { app.startActivity(i); } catch (Exception ignored) { }
            }
        };
        IntentFilter f = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(done, f, Context.RECEIVER_EXPORTED);
        else app.registerReceiver(done, f);
        return "ok";
    }

    /* ---------------------------------------------------------------- files */

    @JavascriptInterface
    public String saveFile(String name, String text) {
        try {
            byte[] data = text.getBytes(StandardCharsets.UTF_8);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) return "err";
                OutputStream os = ctx.getContentResolver().openOutputStream(u);
                if (os == null) return "err";
                os.write(data);
                os.close();
            } else {
                File dir = ctx.getExternalFilesDir(null);
                FileOutputStream os = new FileOutputStream(new File(dir, name));
                os.write(data);
                os.close();
            }
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }
}

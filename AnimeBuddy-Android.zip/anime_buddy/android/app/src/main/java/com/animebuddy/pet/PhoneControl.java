package com.animebuddy.pet;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Locale;

/** Lets the assistant see the screen and tap / type / scroll in any app or browser (only after the user enables it in Accessibility settings). */
public class PhoneControl extends AccessibilityService {
    static volatile PhoneControl instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    /* ---------------------------------------------------------------- reading */

    /** Visible text on screen, one item per line. null = service not enabled. */
    static String readScreen() {
        PhoneControl s = instance;
        if (s == null) return null;
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "";
        StringBuilder sb = new StringBuilder();
        walk(root, sb, 0);
        return sb.length() > 6000 ? sb.substring(0, 6000) : sb.toString();
    }

    private static void walk(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
        if (n == null || depth > 40 || sb.length() > 6000) return;
        if (!n.isVisibleToUser()) return;
        CharSequence t = n.getText(), d = n.getContentDescription();
        String line = null;
        if (t != null && t.length() > 0) line = t.toString();
        else if (d != null && d.length() > 0) line = d.toString();
        if (line != null) {
            line = line.replace('\n', ' ').trim();
            if (!line.isEmpty()) {
                String tag = n.isEditable() ? "[input] " : n.isClickable() ? "[tap] " : "";
                sb.append(tag).append(line.length() > 200 ? line.substring(0, 200) : line);
                if (!tag.isEmpty()) { Rect r = new Rect(); n.getBoundsInScreen(r); sb.append(" @").append(r.centerX()).append(",").append(r.centerY()); }
                sb.append('\n');
            }
        } else if (n.isEditable()) {
            CharSequence h = Build.VERSION.SDK_INT >= 26 ? n.getHintText() : null;
            sb.append("[input] ").append(h == null ? "" : h).append('\n');
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), sb, depth + 1);
    }

    /* ---------------------------------------------------------------- acting */

    private static boolean matches(AccessibilityNodeInfo n, String q) {
        CharSequence t = n.getText(), d = n.getContentDescription();
        return (t != null && t.toString().toLowerCase(Locale.ROOT).contains(q)) || (d != null && d.toString().toLowerCase(Locale.ROOT).contains(q));
    }

    private static boolean exact(AccessibilityNodeInfo n, String q) {
        CharSequence t = n.getText(), d = n.getContentDescription();
        return (t != null && t.toString().trim().equalsIgnoreCase(q)) || (d != null && d.toString().trim().equalsIgnoreCase(q));
    }

    private static AccessibilityNodeInfo find(AccessibilityNodeInfo n, String q, boolean wantExact, int depth) {
        if (n == null || depth > 40 || !n.isVisibleToUser()) return null;
        if (wantExact ? exact(n, q) : matches(n, q)) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = find(n.getChild(i), q, wantExact, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    static String click(String label) {
        PhoneControl s = instance;
        if (s == null) return "off";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "notfound";
        String q = label.toLowerCase(Locale.ROOT).trim();
        AccessibilityNodeInfo hit = find(root, q, true, 0);
        if (hit == null) hit = find(root, q, false, 0);
        if (hit == null) return "notfound";
        AccessibilityNodeInfo c = hit;
        for (int i = 0; i < 8 && c != null; i++) {
            if (c.isClickable() && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok";
            c = c.getParent();
        }
        Rect r = new Rect();
        hit.getBoundsInScreen(r);                                    // not clickable through the API (custom views, games, web pages): tap its position
        if (r.width() > 0 && r.height() > 0) return gesture(r.centerX(), r.centerY(), r.centerX(), r.centerY(), 60);
        return "notfound";
    }

    /** One finger touch / swipe at screen coordinates (works in any app, including ones that hide their UI tree). */
    static String gesture(float x1, float y1, float x2, float y2, long ms) {
        PhoneControl s = instance;
        if (s == null) return "off";
        if (Build.VERSION.SDK_INT < 24) return "err";
        try {
            Path p = new Path();
            p.moveTo(x1, y1);
            if (x1 != x2 || y1 != y2) p.lineTo(x2, y2);
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(new GestureDescription.StrokeDescription(p, 0, Math.max(40, ms)));
            return s.dispatchGesture(b.build(), null, null) ? "ok" : "err";
        } catch (Exception e) {
            return "err";
        }
    }

    static String tapXY(String arg) {
        String[] a = arg.replace(" ", "").split(",");
        if (a.length < 2) return "err";
        try { float x = Float.parseFloat(a[0]), y = Float.parseFloat(a[1]); return gesture(x, y, x, y, 60); } catch (Exception e) { return "err"; }
    }

    /** arg = "up|down|left|right" (finger direction) or "x1,y1,x2,y2". */
    static String swipe(String arg) {
        PhoneControl s = instance;
        if (s == null) return "off";
        android.util.DisplayMetrics m = s.getResources().getDisplayMetrics();
        float w = m.widthPixels, h = m.heightPixels;
        switch (arg) {
            case "up": return gesture(w / 2, h * 0.72f, w / 2, h * 0.28f, 320);
            case "down": return gesture(w / 2, h * 0.28f, w / 2, h * 0.72f, 320);
            case "left": return gesture(w * 0.8f, h / 2, w * 0.2f, h / 2, 320);
            case "right": return gesture(w * 0.2f, h / 2, w * 0.8f, h / 2, 320);
            default: break;
        }
        String[] a = arg.replace(" ", "").split(",");
        if (a.length < 4) return "err";
        try { return gesture(Float.parseFloat(a[0]), Float.parseFloat(a[1]), Float.parseFloat(a[2]), Float.parseFloat(a[3]), 350); } catch (Exception e) { return "err"; }
    }

    /** arg = on-screen text or "x,y". */
    static String longPress(String arg) {
        PhoneControl s = instance;
        if (s == null) return "off";
        if (arg.matches("\\s*\\d+\\s*,\\s*\\d+\\s*")) {
            String[] a = arg.replace(" ", "").split(",");
            float x = Float.parseFloat(a[0]), y = Float.parseFloat(a[1]);
            return gesture(x, y, x, y, 900);
        }
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "notfound";
        String q = arg.toLowerCase(Locale.ROOT).trim();
        AccessibilityNodeInfo hit = find(root, q, true, 0);
        if (hit == null) hit = find(root, q, false, 0);
        if (hit == null) return "notfound";
        AccessibilityNodeInfo c = hit;
        for (int i = 0; i < 8 && c != null; i++) {
            if (c.isLongClickable() && c.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return "ok";
            c = c.getParent();
        }
        Rect r = new Rect();
        hit.getBoundsInScreen(r);
        return gesture(r.centerX(), r.centerY(), r.centerX(), r.centerY(), 900);
    }

    static String paste() {
        PhoneControl s = instance;
        if (s == null) return "off";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        AccessibilityNodeInfo f = root == null ? null : root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null && root != null) f = findInput(root, 0);
        return f != null && f.performAction(AccessibilityNodeInfo.ACTION_PASTE) ? "ok" : "nofield";
    }

    private static AccessibilityNodeInfo findInput(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 40) return null;
        if (n.isEditable() && n.isVisibleToUser()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findInput(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    static String type(String text) {
        PhoneControl s = instance;
        if (s == null) return "off";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "nofield";
        AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null || !f.isEditable()) f = findInput(root, 0);
        if (f == null) return "nofield";
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b) ? "ok" : "nofield";
    }

    static String enter() {
        PhoneControl s = instance;
        if (s == null) return "off";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "nofield";
        AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null) f = findInput(root, 0);
        if (f != null && Build.VERSION.SDK_INT >= 30 && f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId())) return "ok";
        for (String k : new String[]{"search", "go", "खोजें", "सर्च"}) {
            if ("ok".equals(click(k))) return "ok";
        }
        return "nofield";
    }

    private static AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 40) return null;
        if (n.isScrollable() && n.isVisibleToUser()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findScrollable(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    static String scroll(String dir) {
        PhoneControl s = instance;
        if (s == null) return "off";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        AccessibilityNodeInfo sc = root == null ? null : findScrollable(root, 0);
        if (sc == null) return swipe("up".equals(dir) ? "down" : "up");          // no scrollable view reported: drag the page with a finger gesture
        int act = "up".equals(dir) ? AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD : AccessibilityNodeInfo.ACTION_SCROLL_FORWARD;
        return sc.performAction(act) ? "ok" : "notfound";
    }

    static String global(String what) {
        PhoneControl s = instance;
        if (s == null) return "off";
        int a;
        switch (what) {
            case "home": a = GLOBAL_ACTION_HOME; break;
            case "back": a = GLOBAL_ACTION_BACK; break;
            case "recents": a = GLOBAL_ACTION_RECENTS; break;
            case "notifications": a = GLOBAL_ACTION_NOTIFICATIONS; break;
            case "quick": a = GLOBAL_ACTION_QUICK_SETTINGS; break;
            case "lock": if (Build.VERSION.SDK_INT < 28) return "err"; a = GLOBAL_ACTION_LOCK_SCREEN; break;
            case "shot": if (Build.VERSION.SDK_INT < 28) return "err"; a = GLOBAL_ACTION_TAKE_SCREENSHOT; break;
            default: return "err";
        }
        return s.performGlobalAction(a) ? "ok" : "err";
    }
}

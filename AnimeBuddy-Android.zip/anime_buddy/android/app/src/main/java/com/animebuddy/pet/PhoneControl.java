package com.animebuddy.pet;

import android.accessibilityservice.AccessibilityService;
import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Locale;

/** Lets the assistant see the screen and tap / type / scroll in any app or browser (only after the user enables it in Accessibility settings). */
public class PhoneControl extends AccessibilityService {
    static volatile PhoneControl instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    /* ---------------------------------------------------------------- reading */

    /** Visible text on screen, one item per line. null = service not enabled. */
    static String readScreen() {
        PhoneControl s = instance;
        if (s == null) return null;
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "";
        StringBuilder sb = new StringBuilder();
        walk(root, sb, 0);
        return sb.length() > 6000 ? sb.substring(0, 6000) : sb.toString();
    }

    private static void walk(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
        if (n == null || depth > 40 || sb.length() > 6000) return;
        if (!n.isVisibleToUser()) return;
        CharSequence t = n.getText(), d = n.getContentDescription();
        String line = null;
        if (t != null && t.length() > 0) line = t.toString();
        else if (d != null && d.length() > 0) line = d.toString();
        if (line != null) {
            line = line.replace('\n', ' ').trim();
            if (!line.isEmpty()) {
                String tag = n.isEditable() ? "[input] " : n.isClickable() ? "[tap] " : "";
                sb.append(tag).append(line.length() > 200 ? line.substring(0, 200) : line).append('\n');
            }
        } else if (n.isEditable()) {
            CharSequence h = Build.VERSION.SDK_INT >= 26 ? n.getHintText() : null;
            sb.append("[input] ").append(h == null ? "" : h).append('\n');
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), sb, depth + 1);
    }

    /* ---------------------------------------------------------------- acting */

    private static boolean matches(AccessibilityNodeInfo n, String q) {
        CharSequence t = n.getText(), d = n.getContentDescription();
        return (t != null && t.toString().toLowerCase(Locale.ROOT).contains(q)) || (d != null && d.toString().toLowerCase(Locale.ROOT).contains(q));
    }

    private static boolean exact(AccessibilityNodeInfo n, String q) {
        CharSequence t = n.getText(), d = n.getContentDescription();
        return (t != null && t.toString().trim().equalsIgnoreCase(q)) || (d != null && d.toString().trim().equalsIgnoreCase(q));
    }

    private static AccessibilityNodeInfo find(AccessibilityNodeInfo n, String q, boolean wantExact, int depth) {
        if (n == null || depth > 40 || !n.isVisibleToUser()) return null;
        if (wantExact ? exact(n, q) : matches(n, q)) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = find(n.getChild(i), q, wantExact, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    static String click(String label) {
        PhoneControl s = instance;
        if (s == null) return "off";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "notfound";
        String q = label.toLowerCase(Locale.ROOT).trim();
        AccessibilityNodeInfo hit = find(root, q, true, 0);
        if (hit == null) hit = find(root, q, false, 0);
        if (hit == null) return "notfound";
        AccessibilityNodeInfo c = hit;
        for (int i = 0; i < 8 && c != null; i++) {
            if (c.isClickable() && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok";
            c = c.getParent();
        }
        return "notfound";
    }

    private static AccessibilityNodeInfo findInput(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 40) return null;
        if (n.isEditable() && n.isVisibleToUser()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findInput(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    static String type(String text) {
        PhoneControl s = instance;
        if (s == null) return "off";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "nofield";
        AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null || !f.isEditable()) f = findInput(root, 0);
        if (f == null) return "nofield";
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b) ? "ok" : "nofield";
    }

    static String enter() {
        PhoneControl s = instance;
        if (s == null) return "off";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "nofield";
        AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null) f = findInput(root, 0);
        if (f != null && Build.VERSION.SDK_INT >= 30 && f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId())) return "ok";
        for (String k : new String[]{"search", "go", "खोजें", "सर्च"}) {
            if ("ok".equals(click(k))) return "ok";
        }
        return "nofield";
    }

    private static AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 40) return null;
        if (n.isScrollable() && n.isVisibleToUser()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findScrollable(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    static String scroll(String dir) {
        PhoneControl s = instance;
        if (s == null) return "off";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        AccessibilityNodeInfo sc = root == null ? null : findScrollable(root, 0);
        if (sc == null) return "notfound";
        int act = "up".equals(dir) ? AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD : AccessibilityNodeInfo.ACTION_SCROLL_FORWARD;
        return sc.performAction(act) ? "ok" : "notfound";
    }

    static String global(String what) {
        PhoneControl s = instance;
        if (s == null) return "off";
        int a;
        switch (what) {
            case "home": a = GLOBAL_ACTION_HOME; break;
            case "back": a = GLOBAL_ACTION_BACK; break;
            case "recents": a = GLOBAL_ACTION_RECENTS; break;
            case "notifications": a = GLOBAL_ACTION_NOTIFICATIONS; break;
            case "quick": a = GLOBAL_ACTION_QUICK_SETTINGS; break;
            case "lock": if (Build.VERSION.SDK_INT < 28) return "err"; a = GLOBAL_ACTION_LOCK_SCREEN; break;
            case "shot": if (Build.VERSION.SDK_INT < 28) return "err"; a = GLOBAL_ACTION_TAKE_SCREENSHOT; break;
            default: return "err";
        }
        return s.performGlobalAction(a) ? "ok" : "err";
    }
}

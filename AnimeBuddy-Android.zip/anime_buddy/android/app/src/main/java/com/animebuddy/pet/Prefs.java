package com.animebuddy.pet;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    private Prefs() {}

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("buddy", Context.MODE_PRIVATE);
    }

    static boolean autoStart(Context c) { return sp(c).getBoolean("autostart", false); }

    static void setAutoStart(Context c, boolean v) { sp(c).edit().putBoolean("autostart", v).apply(); }
}

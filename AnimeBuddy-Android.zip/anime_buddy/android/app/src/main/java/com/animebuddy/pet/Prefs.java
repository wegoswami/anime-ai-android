package com.animebuddy.pet;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    private Prefs() {}

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("buddy", Context.MODE_PRIVATE);
    }

    static boolean autoStart(Context c) { return sp(c).getBoolean("autostart", false); }

    static void setAutoStart(Context c, boolean v) { sp(c).edit().putBoolean("autostart", v).apply(); }

    /** Remembers the last problem so the app can show it in Settings (no computer needed to see what went wrong). */
    static void err(Context c, String what, Throwable t) {
        String msg = what + (t == null ? "" : ": " + t);
        if (t != null) {
            StackTraceElement[] st = t.getStackTrace();
            for (int i = 0; i < Math.min(3, st.length); i++) msg += " @" + st[i].getClassName().replace("com.animebuddy.pet.", "") + "." + st[i].getMethodName() + ":" + st[i].getLineNumber();
        }
        sp(c).edit().putString("err", msg).apply();
    }

    static boolean wander(Context c) { return sp(c).getBoolean("wander", true); }

    static void setWander(Context c, boolean v) { sp(c).edit().putBoolean("wander", v).apply(); }
}

package com.animebuddy.pet;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

/** Keeps the anime pet floating above every app. The pet itself is the web app running in overlay mode. */
public class OverlayService extends Service {
    static volatile OverlayService instance;
    static volatile boolean wanted = false;
    static volatile boolean ready = false;      // the web page inside the window has drawn the pet
    static final String ACTION_STOP = "com.animebuddy.pet.STOP";

    private static final int PET_DP = 200, EXTRA_DP = 120, W_SMALL_DP = 150, W_BIG_DP = 210;

    WebView web;
    private Bridge bridge;
    private FrameLayout root;
    private View shield;
    private ImageView face;
    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private float density = 3f;
    private int screenW, screenH, bottomPx;
    private boolean bubble = false;
    private final Handler main = new Handler(Looper.getMainLooper());
    private Runnable longPress;
    private final java.util.Random rnd = new java.util.Random();
    private boolean walking = false, dragging = false;
    private long lastInteract = 0;
    private int walkTarget = 0, walkDir = 1;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            wanted = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            wanted = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            startAsForeground();
        } catch (Exception e) {
            Prefs.err(this, "startForeground", e);
            wanted = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        wanted = true;
        instance = this;
        if (root == null) {
            try {
                addOverlay();
            } catch (Throwable e) {
                Prefs.err(this, "addOverlay", e);
                wanted = false;
                stopSelf();
                return START_NOT_STICKY;
            }
            Toast.makeText(this, "Anime Buddy chalu \u2665 Home dabao", Toast.LENGTH_LONG).show();
        }
        if (MainActivity.visible) setHidden(true);
        return START_STICKY;
    }

    private void startAsForeground() {
        Notif.channels(this);
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 3, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 4, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, Notif.CH_PET)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Anime Buddy aapke saath hai")
                .setContentText("Tap karke app kholo")
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Pet band karo", stopPi).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(7, n);
        }
    }

    private int dp(int v) { return Math.round(v * density); }

    private void addOverlay() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        density = getResources().getDisplayMetrics().density;
        screenW = getResources().getDisplayMetrics().widthPixels;
        screenH = getResources().getDisplayMetrics().heightPixels;

        web = new WebView(this);
        Web.setup(this, web);
        web.setBackgroundColor(Color.TRANSPARENT);
        bridge = new Bridge(this, web, true);
        web.addJavascriptInterface(bridge, "Native");
        web.loadUrl(Web.BASE + "index.html?overlay=1");

        root = new FrameLayout(this);
        face = new ImageView(this);                  // little stand-in while the pet loads (and a clue if it never does)
        face.setImageResource(R.mipmap.ic_launcher);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        fl.bottomMargin = dp(8);
        root.addView(face, fl);
        ready = false;
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        shield = new View(this);
        root.addView(shield, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        shield.setOnTouchListener(touch);

        lp = new WindowManager.LayoutParams(
                dp(W_SMALL_DP), dp(PET_DP),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = Prefs.sp(this).getInt("ox", screenW - dp(W_SMALL_DP) - dp(6));
        bottomPx = Prefs.sp(this).getInt("ob", (int) (screenH * 0.86f));
        applyLayout(false);
        try {
            wm.addView(root, lp);
        } catch (Exception e) {
            Prefs.err(this, "addView", e);
            stopSelf();
            return;
        }
        main.postDelayed(wanderRun, 6000);
    }

    private void applyLayout(boolean update) {
        lp.width = dp(bubble ? W_BIG_DP : W_SMALL_DP);
        lp.height = dp(PET_DP + (bubble ? EXTRA_DP : 0));
        lp.x = Math.max(0, Math.min(screenW - lp.width, lp.x));
        bottomPx = Math.max(lp.height, Math.min(screenH, bottomPx));
        lp.y = bottomPx - lp.height;
        if (update && root != null) {
            try { wm.updateViewLayout(root, lp); } catch (Exception ignored) { }
        }
    }

    /** The speech bubble needs more room above the pet; give it only while it is showing. */
    void setBubble(boolean show) {
        if (bubble == show || root == null) return;
        int oldW = lp.width;
        bubble = show;
        lp.x -= (dp(show ? W_BIG_DP : W_SMALL_DP) - oldW) / 2;      // grow / shrink around the pet's centre
        if (show) stopWalking();
        applyLayout(true);
    }

    /* the pet strolls along the bottom of the screen by itself, like it does on the PC taskbar */
    private final Runnable wanderRun = new Runnable() {
        @Override
        public void run() {
            if (root == null) return;
            long now = SystemClock.uptimeMillis();
            boolean ok = Prefs.wander(OverlayService.this) && !walking && !dragging && !bubble
                    && root.getVisibility() == View.VISIBLE && now - lastInteract > 8000;
            if (ok) {
                int maxX = Math.max(0, screenW - lp.width);
                int target = rnd.nextInt(maxX + 1);
                if (Math.abs(target - lp.x) < dp(80)) target = lp.x < maxX / 2 ? maxX : 0;
                walkTarget = target;
                walkDir = target > lp.x ? 1 : -1;
                walking = true;
                try { web.evaluateJavascript("window.__petWalk&&__petWalk(" + walkDir + ")", null); } catch (Exception ignored) { }
                main.post(stepRun);
            }
            main.postDelayed(this, 7000 + rnd.nextInt(9000));
        }
    };

    private final Runnable stepRun = new Runnable() {
        @Override
        public void run() {
            if (!walking || root == null) return;
            int step = Math.max(2, dp(2));
            int d = walkTarget - lp.x;
            if (Math.abs(d) <= step) {
                lp.x = walkTarget;
                applyLayout(true);
                stopWalking();
                return;
            }
            lp.x += d > 0 ? step : -step;
            applyLayout(true);
            main.postDelayed(this, 33);
        }
    };

    private void stopWalking() {
        if (!walking) return;
        walking = false;
        main.removeCallbacks(stepRun);
        try { web.evaluateJavascript("window.__petWalk&&__petWalk(0)", null); } catch (Exception ignored) { }
        if (root != null) Prefs.sp(this).edit().putInt("ox", lp.x).apply();
    }

    void markReady() {
        ready = true;
        if (face != null) face.setVisibility(View.GONE);
    }

    void setHidden(boolean hidden) {
        if (root == null) return;
        if (hidden) stopWalking();
        root.setVisibility(hidden ? View.GONE : View.VISIBLE);
        try { web.evaluateJavascript("window.__hidden&&__hidden(" + hidden + ")", null); } catch (Exception ignored) { }
        if (!hidden) {
            main.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try { web.evaluateJavascript("window.__resync&&__resync()", null); } catch (Exception ignored) { }
                }
            }, 400);
        }
    }

    private final View.OnTouchListener touch = new View.OnTouchListener() {
        float downX, downY;
        int startX, startBottom;
        boolean moved, longDone;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            int slop = ViewConfiguration.get(OverlayService.this).getScaledTouchSlop();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastInteract = SystemClock.uptimeMillis();
                    stopWalking();
                    downX = e.getRawX();
                    downY = e.getRawY();
                    startX = lp.x;
                    startBottom = bottomPx;
                    moved = false;
                    longDone = false;
                    longPress = new Runnable() {
                        @Override
                        public void run() {
                            if (!moved) {
                                longDone = true;
                                bridge.openApp();
                            }
                        }
                    };
                    main.postDelayed(longPress, 750);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    if (!moved && Math.hypot(dx, dy) > slop * 1.5f && !longDone) {
                        moved = true;
                        dragging = true;
                        main.removeCallbacks(longPress);
                        web.evaluateJavascript("window.__petHeld&&__petHeld(true)", null);
                    }
                    if (moved) {
                        lp.x = (int) (startX + dx);
                        bottomPx = (int) (startBottom + dy);
                        applyLayout(true);
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    main.removeCallbacks(longPress);
                    dragging = false;
                    lastInteract = SystemClock.uptimeMillis();
                    if (moved) {
                        web.evaluateJavascript("window.__petHeld&&__petHeld(false)", null);
                        Prefs.sp(OverlayService.this).edit().putInt("ox", lp.x).putInt("ob", bottomPx).apply();
                    } else if (!longDone && e.getActionMasked() == MotionEvent.ACTION_UP) {
                        web.evaluateJavascript("window.__petTap&&__petTap()", null);
                    }
                    return true;
                default:
                    return true;
            }
        }
    };

    @Override
    public void onDestroy() {
        instance = null;
        ready = false;
        main.removeCallbacksAndMessages(null);
        try { if (root != null && wm != null) wm.removeView(root); } catch (Exception ignored) { }
        root = null;
        if (bridge != null) bridge.shutdown();
        if (web != null) {
            try { web.destroy(); } catch (Exception ignored) { }
            web = null;
        }
        super.onDestroy();
    }
}

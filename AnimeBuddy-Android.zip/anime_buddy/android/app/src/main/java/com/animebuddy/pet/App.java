package com.animebuddy.pet;

import android.app.Application;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    Prefs.err(App.this, "CRASH", e);
                } catch (Throwable ignored) { }
                if (old != null) old.uncaughtException(t, e);
            }
        });
    }
}
